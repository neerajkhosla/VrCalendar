<?php
error_reporting(E_ALL);
//1
$your_booking_is_removed_subject = __("Your booking is removed", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$your_booking_is_removed_body =  __("Hi %booking_user_fname% %booking_user_lname%,
<p>Your Booking is removed by the admin, following were your booking details for reference:</p>
<p>Booking ID: %booking_id%</p>
<p>Booking Date: %booking_created_on%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>", VRCALENDAR_PLUGIN_TEXT_DOMAIN);;

//2
$your_booking_is_approved_subject = __("Your booking is approved", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$your_booking_is_approved_body = __("Hi %booking_user_fname% %booking_user_lname%,
<br/>
Your Booking is confirmed.", VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//3.
$your_booking_is_approved_make_payment_subject = __("Your booking is approved", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$your_booking_is_approved_make_payment_body = __("Hi %booking_user_fname% %booking_user_lname%,
<br/>
Your Booking is confirmed, now you can make payment for your booking by following this link %booking_payment_link%.", VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//4.
$conflict_aroused_while_synchronizing_calendar_subject = __("Conflict aroused while synchronizing calendar: %calendar_name%", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$conflict_aroused_while_synchronizing_calendar_body = __("Conflict aroused while synchronizing calendar: %calendar_name%<br>
 Conflicting Source: %booking_source%<br>
 Event Start Date: %booking_date_from%<br>
 Event End Date: %booking_date_to%<br>
 Event Summary: %booking_summary%<br>", VRCALENDAR_PLUGIN_TEXT_DOMAIN);;

//5.
$approval_needed_on_new_booking_on_subject = __("Your booking is received on %blogname% and is pending for approval", VRCALENDAR_PLUGIN_TEXT_DOMAIN);;
$approval_needed_on_new_booking_on_body = __("Hi %booking_user_fname% %booking_user_lname%,
<p>Your booking is received on %blogname% and is pending for approval</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>", VRCALENDAR_PLUGIN_TEXT_DOMAIN);;

//6
$your_booking_is_received_is_pending_for_approval_subject = __("Your booking is received on %blogname% and is pending for approval", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$your_booking_is_received_is_pending_for_approval_body = __("Hi %booking_user_fname% %booking_user_lname%,
<p>Your booking is received on %blogname% and is pending for approval</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
//7
$new_booking_subject = __("New booking on %blogname%", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$new_booking_body = __('Hi,
<p>New booking is received on %blogname%</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>
<p><a href="%booking_admin_link%">Click here to view booking</a></p>
', VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//8
$your_booking_is_received_subject = __("Your booking is received on %blogname%", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$your_booking_is_received_body = __("Hi %booking_user_fname% %booking_user_lname%,
<p>Your booking is received on %blogname%</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>", VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//9
$new_booking_payment_received_subject  = __("New booking payment received on %blogname%", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$new_booking_payment_received_body  = __('Hi,
<p>New booking payment is received on %blogname%</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>Transaction ID: %booking_payment_data_txn_id%</p>
<p>Amount: %booking_total_price%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>
<p><a href="%booking_admin_link%">Click here to view booking</a></p>', VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//10
$your_bookingpayment_is_received_subject = __("Your booking payment is received on %blogname%", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$your_bookingpayment_is_received_body = __("Hi %booking_user_fname% %booking_user_lname%,
<p>Your booking payment is received on %blogname%</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>Transaction ID: %booking_payment_data_txn_id%</p>
<p>Amount : %booking_total_price%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>", VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//11
$approval_needed_on_new_booking_subject = __("Approval needed on new booking on %blogname%", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$approval_needed_on_new_booking_body = __('Hi,
<p>New booking is received on %blogname% and is pending for approval</p>
<p>Booking Details:</p>
<p>Booking ID: %booking_id%</p>
<p>From: %booking_date_from%</p>
<p>To: %booking_date_to%</p>
<p>Guests: %booking_guests%</p>
<p>Summary: %booking_summary%</p>
<p><a href="%booking_admin_link%">Click here to view booking</a></p>', VRCALENDAR_PLUGIN_TEXT_DOMAIN);

//12.
$if_deposit_payment_enable_subject = __("Your booking is approved", VRCALENDAR_PLUGIN_TEXT_DOMAIN);
$if_deposit_payment_enable_body = __("Hi %booking_user_fname% %booking_user_lname%,
<br/>
Your Booking is confirmed, now you can make payment for your booking by following this link %booking_payment_link%.", VRCALENDAR_PLUGIN_TEXT_DOMAIN);

if(count($cdata->email_template) > 0)
{
    foreach ($cdata->email_template[$cdata->calendar_id] as $key => $value) {
        # code...
        if($key == 'your_booking_is_removed')
        {
            //1
            $your_booking_is_removed_subject = $value['subject'];
            $your_booking_is_removed_body = $value['body'];
        }
        if($key == 'your_booking_is_approved')
        {
            //2
            $your_booking_is_approved_subject = $value['subject'];
            $your_booking_is_approved_body = $value['body'];
        }
        if($key == 'your_booking_is_approved_make_payment')
        {
            //3
            $your_booking_is_approved_make_payment_subject = $value['subject'];
            $your_booking_is_approved_make_payment_body = $value['body'];
        }
        if($key == 'conflict_aroused_while_synchronizing_calendar')
        {
            //4
            $conflict_aroused_while_synchronizing_calendar_subject = $value['subject'];
            $conflict_aroused_while_synchronizing_calendar_body = $value['body'];
        }
        if($key == 'approval_needed_on_new_booking_on')
        {
            //5
            $approval_needed_on_new_booking_on_subject = $value['subject'];
            $approval_needed_on_new_booking_on_body = $value['body'];
        }
        if($key == 'your_booking_is_received_is_pending_for_approval')
        {
            //6
            $your_booking_is_received_is_pending_for_approval_subject = $value['subject'];
            $your_booking_is_received_is_pending_for_approval_body = $value['body'];
        }
        if($key == 'new_booking')
        {
            //7
            $new_booking_subject = $value['subject'];
            $new_booking_body = $value['body'];
        }
        if($key == 'your_booking_is_received')
        {
            //8
            $your_booking_is_received_subject = $value['subject'];
            $your_booking_is_received_body = $value['body'];
        }
        if($key == 'new_booking_payment_received')
        {
            //7
            $new_booking_payment_received_subject = $value['subject'];
            $new_booking_payment_received_body = $value['body'];
        }

        if($key == 'your_bookingpayment_is_received')
        {
            //7
            $your_bookingpayment_is_received_subject = $value['subject'];
            $your_bookingpayment_is_received_body = $value['body'];
        }

        if($key == 'approval_needed_on_new_booking')
        {
            //7
            $approval_needed_on_new_booking_subject = $value['subject'];
            $approval_needed_on_new_booking_body = $value['body'];
        }
        
        if($key == 'if_deposit_payment_enable')
        {
            //12
            $if_deposit_payment_enable_subject = $value['subject'];
            $if_deposit_payment_enable_body = $value['body'];
        }
    }
}

//$template_object(subject, body)
global $wpdb;
$server = $_SERVER['REQUEST_URI'];
$explode = explode('=',$server);
$calendar_id_email = $explode[2];
$this->table_name = $wpdb->prefix.'vrcalandar';
$sql = "select email_address_template, email_send_to,your_booking_approved, email_booking_approved, booking_approved1, email_booking_approved1, synchronizing_calendar, email_synchronizing_calendar, approval_new_booking, email_approval_new_booking, booking_received, email_booking_received, new_booking, email_new_booking, your_booking_received, email_your_booking_received, new_booking_payment, email_new_booking_payment, your_booking_payment, email_your_booking_payment, your_booking_recieved, email_your_booking_recieved, deposit_mode_enable, email_deposit_mode_enable from {$this->table_name} WHERE calendar_id =".$calendar_id_email;
$cals = $wpdb->get_results($sql);
//echo '<pre>';
//print_r($cals);
foreach($cals as $cal) {
	$emailaddress = $cal->email_address_template;
	$email_send_to = $cal->email_send_to;
	$your_booking_approved = $cal->your_booking_approved;
	$email_booking_approved = $cal->email_booking_approved;
	$booking_approved1 = $cal->booking_approved1;
	$email_booking_approved1 = $cal->email_booking_approved1;
	$synchronizing_calendar = $cal->synchronizing_calendar;
	$email_synchronizing_calendar = $cal->email_synchronizing_calendar;
	$approval_new_booking = $cal->approval_new_booking;
	$email_approval_new_booking = $cal->email_approval_new_booking;
	$booking_received = $cal->booking_received;
	$email_booking_received = $cal->email_booking_received;
	$new_booking = $cal->new_booking;
	$email_new_booking = $cal->email_new_booking;
	$your_booking_received = $cal->your_booking_received;
	$email_your_booking_received = $cal->email_your_booking_received;
	$new_booking_payment = $cal->new_booking_payment;
	$email_new_booking_payment = $cal->email_new_booking_payment;
	$your_booking_payment = $cal->your_booking_payment;
	$email_your_booking_payment = $cal->email_your_booking_payment;
	$your_booking_recieved = $cal->your_booking_recieved;
	$email_your_booking_recieved = $cal->email_your_booking_recieved;
	$deposit_mode_enable = $cal->deposit_mode_enable;
	$email_deposit_mode_enable = $cal->email_deposit_mode_enable;
}

//print_r($cal_data);

?>





<table class="form-table">
    <tbody>
       <tr valign="top">
           <th><?php _e('1. Your booking is removed', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<!--<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($email_send_to)){ echo $email_send_to; } ?>'>
									<input type="radio" name="email_send_to" value="admin" <?php if(isset($email_send_to) && $email_send_to == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="email_send_to" value="both" <?php if(isset($email_send_to) && $email_send_to == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="email_send_to" value="single" <?php if(isset($email_send_to) && $email_send_to == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_address_template" value="<?php if(isset($emailaddress)){ echo $emailaddress; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>-->
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[your_booking_is_removed][subject]" value="<?php echo $your_booking_is_removed_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>     
                            <?php
                                $editor_id = "emailtemplate[your_booking_is_removed][body]";
                                $content = $your_booking_is_removed_body;
                                wp_editor($content,$editor_id,array());
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_created_on% = Booking Creation Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_guests% = Booked No Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('2. Your booking is approved', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<!--<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($your_booking_approved)){ echo $your_booking_approved; } ?>'>
									<input type="radio" name="your_booking_approved" value="admin" <?php if(isset($your_booking_approved) && $your_booking_approved == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="your_booking_approved" value="both" <?php if(isset($your_booking_approved) && $your_booking_approved == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="booking_approved" value="single" <?php if(isset($your_booking_approved) && $your_booking_approved == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_booking_approved" value="<?php if(isset($email_booking_approved)){ echo $email_booking_approved; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>-->
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[your_booking_is_approved][subject]" value="<?php echo $your_booking_is_approved_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>   
                        <?php
                                $editor_id = "emailtemplate[your_booking_is_approved][body]";
                                $content = $your_booking_is_approved_body;
                                wp_editor($content,$editor_id,array());
                            ?>  

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('3. Your booking is approved', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<!--<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($booking_approved1)){ echo $booking_approved1; } ?>'>
									<input type="radio" name="booking_approved1" value="admin" <?php if(isset($booking_approved1) && $booking_approved1 == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="booking_approved1" value="both" <?php if(isset($booking_approved1) && $booking_approved1 == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="booking_approved1" value="single" <?php if(isset($booking_approved1) && $booking_approved1 == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_booking_approved1" value="<?php if(isset($email_booking_approved1)){ echo $email_booking_approved1; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>-->
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[your_booking_is_approved_make_payment][subject]" value="<?php echo $your_booking_is_approved_make_payment_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>     
                            <?php
                                $editor_id = "emailtemplate[your_booking_is_approved_make_payment][body]";
                                $content = $your_booking_is_approved_make_payment_body;
                                wp_editor($content,$editor_id,array());
                            ?>  

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_payment_link% = Booking link (if booking approved by admin, than system send payment link via email to user).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


         <tr valign="top">
           <th><?php _e('4. Conflict aroused while synchronizing calendar', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($synchronizing_calendar)){ echo $synchronizing_calendar; } ?>'>
									<input type="radio" name="synchronizing_calendar" value="admin" <?php if(isset($synchronizing_calendar) && $synchronizing_calendar == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="synchronizing_calendar" value="both" <?php if(isset($synchronizing_calendar) && $synchronizing_calendar == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="synchronizing_calendar" value="single" <?php if(isset($synchronizing_calendar) && $synchronizing_calendar == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_synchronizing_calendar" value="<?php if(isset($email_synchronizing_calendar)){ echo $email_synchronizing_calendar; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[conflict_aroused_while_synchronizing_calendar][subject]" value="<?php echo $conflict_aroused_while_synchronizing_calendar_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>     
                             <?php
                                $editor_id = "emailtemplate[conflict_aroused_while_synchronizing_calendar][body]";
                                $content = $conflict_aroused_while_synchronizing_calendar_body;
                                wp_editor($content,$editor_id,array());
                            ?>  

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%calendar_name% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_source% = Booking source type (website / Calendar Links).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_summary% = Booking Summary (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('5. Approval needed on new booking on', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<!--<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($approval_new_booking)){ echo $approval_new_booking; } ?>'>
									<input type="radio" name="approval_new_booking" value="admin" <?php if(isset($approval_new_booking) && $approval_new_booking == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="approval_new_booking" value="both" <?php if(isset($approval_new_booking) && $approval_new_booking == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="approval_new_booking" value="single" <?php if(isset($approval_new_booking) && $approval_new_booking == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_approval_new_booking" value="<?php if(isset($email_approval_new_booking)){ echo $email_approval_new_booking; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>-->
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>   
                            <input type="text" name="emailtemplate[approval_needed_on_new_booking_on][subject]" value="<?php echo $approval_needed_on_new_booking_on_subject; ?>" class="large-text" />  
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>   
                        <?php
                                $editor_id = "emailtemplate[approval_needed_on_new_booking_on][body]";
                                $content = $approval_needed_on_new_booking_on_body;
                                wp_editor($content,$editor_id,array());
                            ?>    

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            
                            <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_guests% = Number Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('6. Your booking is received on " " and is pending for approval', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($booking_received)){ echo $booking_received; } ?>'>
									<input type="radio" name="booking_received" value="admin" <?php if(isset($booking_received) && $booking_received == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="booking_received" value="both" <?php if(isset($booking_received) && $booking_received == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="booking_received" value="single" <?php if(isset($booking_received) && $booking_received == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_booking_received" value="<?php if(isset($email_booking_received)) { echo $email_booking_received; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[your_booking_is_received_is_pending_for_approval][subject]" value="<?php echo $your_booking_is_received_is_pending_for_approval_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>    
                        <?php
                                $editor_id = "emailtemplate[your_booking_is_received_is_pending_for_approval][body]";
                                $content = $your_booking_is_received_is_pending_for_approval_body;
                                wp_editor($content,$editor_id,array());
                            ?>     

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            
                            
                            <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_guests% = Number Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('7. New booking', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($new_booking)){  echo $new_booking; } ?>'>
									<input type="radio" name="new_booking" value="admin" <?php if(isset($new_booking) && $new_booking == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="new_booking" value="both" <?php if(isset($new_booking) && $new_booking == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="new_booking" value="single" <?php if(isset($new_booking) && $new_booking == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_new_booking" value="<?php if(isset($email_new_booking)){ echo $email_new_booking; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[new_booking][subject]" value="<?php echo $new_booking_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>    
                         <?php
                                $editor_id = "emailtemplate[new_booking][body]";
                                $content = $new_booking_body;
                                wp_editor($content,$editor_id,array());
                            ?>     
                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                             <?php _e('%booking_guests% = Number Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_admin_link% = Manage Booking page link.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('8. Your booking is received', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($your_booking_received)){ echo $your_booking_received; } ?>'>
									<input type="radio" name="your_booking_received" value="admin" <?php if(isset($your_booking_received) && $your_booking_received == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';}  ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="your_booking_received" value="both" <?php if(isset($your_booking_received) && $your_booking_received == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="your_booking_received" value="single" <?php if(isset($your_booking_received) && $your_booking_received == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_your_booking_received" value="<?php if(isset($email_your_booking_received)){ echo $email_your_booking_received; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                           <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[your_booking_is_received][subject]" value="<?php echo $your_booking_is_received_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>    
                          <?php
                                $editor_id = "emailtemplate[your_booking_is_received][body]";
                                $content = $your_booking_is_received_body;
                                wp_editor($content,$editor_id,array());
                            ?>      

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                             <?php _e('%booking_guests% = Number Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('9. New booking payment received', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($new_booking_payment)){ echo $new_booking_payment; } ?>'>
									<input type="radio" name="new_booking_payment" value="admin" <?php if(isset($new_booking_payment) && $new_booking_payment == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';}  ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="new_booking_payment" value="both" <?php if(isset($new_booking_payment) && $new_booking_payment == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="new_booking_payment" value="single" <?php if(isset($new_booking_payment) && $new_booking_payment == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_new_booking_payment" value="<?php if(isset($email_new_booking_payment)) { echo $email_new_booking_payment; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[new_booking_payment_received][subject]" value="<?php echo $new_booking_payment_received_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>     
                             <?php
                                $editor_id = "emailtemplate[new_booking_payment_received][body]";
                                $content = $new_booking_payment_received_body;
                                wp_editor($content,$editor_id,array());
                            ?> 

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>
                            <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_payment_data_txn_id% = Booking Payment Transaction ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_total_price% = Booking Total Amount.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_guests% = Number Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_admin_link% = Manage Booking page link.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                     </tr>
                </table>
            </td>
        </tr>


        <tr valign="top">
           <th><?php _e('10. Your booking payment is received', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($your_booking_payment)){ echo $your_booking_payment; } ?>'>
									<input type="radio" name="your_booking_payment" value="admin" <?php if(isset($your_booking_payment) && $your_booking_payment == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';}  ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="your_booking_payment" value="both" <?php if(isset($your_booking_payment) && $your_booking_payment == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="your_booking_payment" value="single" <?php if(isset($your_booking_payment) && $your_booking_payment == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_your_booking_payment" value="<?php if(isset($email_your_booking_payment)){ echo $email_your_booking_payment; } ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[your_bookingpayment_is_received][subject]" value="<?php echo $your_bookingpayment_is_received_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>   
                          <?php
                                $editor_id = "emailtemplate[your_bookingpayment_is_received][body]";
                                $content = $your_bookingpayment_is_received_body;
                                wp_editor($content,$editor_id,array());
                            ?>   

                        </td>
                    </tr>
                    <tr>
                        <th>&nbsp;</th>
                        <td>
                            <?php _e('%booking_user_fname% =  Booking User First name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% =  Booking User Last name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                           <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_payment_data_txn_id% = Booking Payment Transaction ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_total_price% = Booking Total Amount.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_guests% = Number of guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>

        <tr valign="top">
           <th><?php _e('11. Your booking is received on " " and is pending for approval', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($your_booking_recieved)){  echo $your_booking_recieved; } ?>'>
									<input type="radio" name="your_booking_recieved" value="admin" <?php if(isset($your_booking_recieved) && $your_booking_recieved == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';}  ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="your_booking_recieved" value="both" <?php if(isset($your_booking_recieved) && $your_booking_recieved == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="your_booking_recieved" value="single" <?php if(isset($your_booking_recieved) && $your_booking_recieved == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_your_booking_recieved" value="<?php if(isset($email_your_booking_recieved)){  echo $email_your_booking_recieved;} ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[approval_needed_on_new_booking][subject]" value="<?php echo $approval_needed_on_new_booking_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>     
                              <?php
                                $editor_id = "emailtemplate[approval_needed_on_new_booking][body]";
                                $content = $approval_needed_on_new_booking_body;
                                wp_editor($content,$editor_id,array());
                            ?>   

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>     
                             <?php _e('%blogname% = Booking received User Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                             <br />
                            <?php _e('%booking_id% = System Generated Booking ID.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                             <br />
                             <?php _e('%booking_date_from% = Booking From Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                             <br />
                             <?php _e('%booking_date_to% = Booking To Date.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                             <br />
                             <?php _e('%booking_guests% = Number Of Guests.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                             <br />
                             <?php _e('%booking_summary% = Booking Summary Note (Note To Host).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                             <br />
                             <?php _e('%booking_admin_link% = Manage Booking page link.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr valign="top">
           <th><?php _e('12. If Deposit mode enable', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?></th>
        </tr>
        <tr>
            <td>
                <table class="form-table">
					<tr>
						<th>
							<?php _e('To :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
						</th> 
						<td>
							<fieldset>
								<label title='<?php if(isset($deposit_mode_enable)){  echo $deposit_mode_enable; } ?>'>
									<input type="radio" name="deposit_mode_enable" value="admin" <?php if(isset($deposit_mode_enable) && $deposit_mode_enable == 'admin'){ echo 'checked="checked"';}else {echo 'checked="checked"';} ?> /><span><?php echo 'Admin'; ?></span><br>
									<input type="radio" name="deposit_mode_enable" value="both" <?php if(isset($deposit_mode_enable) && $deposit_mode_enable == 'both'){ echo 'checked="checked"';} ?> /><span><?php echo 'Both'; ?></span><br>
									<input type="radio" name="deposit_mode_enable" value="single" <?php if(isset($deposit_mode_enable) && $deposit_mode_enable == 'single'){ echo 'checked="checked"';} ?> /><span><?php echo 'Custom'; ?></span><br>
									<input type="text" name="email_deposit_mode_enable" value="<?php if(isset($email_deposit_mode_enable)){ echo $email_deposit_mode_enable;} ?>" class="large-text" placeholder="Email Address"/>
								</label> &nbsp;
								
							</fieldset>
						</td>
					</tr>
                    <tr>
                        <th>
                            <?php _e('Subject :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </th> 
                        <td>     
                            <input type="text" name="emailtemplate[if_deposit_payment_enable][subject]" value="<?php echo $if_deposit_payment_enable_subject; ?>" class="large-text" />
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php _e('Body :', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?> 
                        </th>
                        <td>     
                              <?php
                                $editor_id = "emailtemplate[if_deposit_payment_enable][body]";
                                $content = $if_deposit_payment_enable_body;
                                wp_editor($content,$editor_id,array());
                            ?>   

                        </td>
                    </tr>
                    <tr>
                        <th>
                            &nbsp;
                        </th>
                        <td>     
                             <?php _e('%booking_user_fname% = Booking User First Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_user_lname% = Booking User Last Name.', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                            <br />
                            <?php _e('%booking_payment_link% = Booking link (if booking approved by admin, than system send payment link via email to user).', VRCALENDAR_PLUGIN_TEXT_DOMAIN); ?>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </tbody>
</table>
