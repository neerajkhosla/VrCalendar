<?php
/*
Template Name: Search Listings Template
*/
?>

<?php get_header(); ?>
<div class="page-background" style="background-color:<?php echo of_get_option( 'colorpicker', '#000' ); ?>;"></div>	
</div>
<div class="container">
<div id="content" class="clearfix row">
			
				<div id="main" class="col-sm-12 clearfix" role="main">
					<div class="search">

<?php global $wp;
  $current_url = add_query_arg( $wp->query_string, '', home_url( $wp->request ) ); ?>					

					  <form action="<?php echo $current_url; ?>" class="form-search"  method="POST">
					  <div class="col-sm-2 no-pad">	
						  <select name="property">
							<option value="">Any Property Type</option>
							<option value="House">House</option>
							<option value="Apartment">Apartment</option>
							<option value="Bed &amp; Breakfast">Bed &amp; Breakfast</option>
							<option value="Loft">Loft</option>
							<option value="Cabin">Cabin</option>
							<option value="Villa">Villa</option>
							<option value="Dorm">Dorm</option>

						  </select> 
					  </div>
					  <div class="col-sm-2 no-pad">	
					    <input type="text" name="address" placeholder="Address" value="" />
					   </div>	
					  <div class="col-sm-3 no-pad">	
					    <select name="bedroom">
							<option value="">Any No. Of Bedrooms</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							<option value="6">6</option>
							<option value="7">7</option>
							<option value="8">8</option>
							<option value="9">9</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
							<option value="13">13</option>
							<option value="14">14</option>
							<option value="15">15</option>
						</select> 
					  </div>
					   <div class="col-sm-3 no-pad">	
						<select name="guest">
							<option value="">Any No. of Guest</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							<option value="6">6</option>
							<option value="7">7</option>
							<option value="8">8</option>
							<option value="9">9</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
							<option value="13">13</option>
							<option value="14">14</option>
							<option value="15">15</option>
						</select> 
					   </div>
					   <div class="col-sm-2 no-pad">	
							<input class="submit-search" type="submit" value="search" name="submit" />
					   </div>
					    </form>
					</div> 
					<br style="clear:both;" />
					
				
				<?php
				
				
				
				$args = array( 'posts_per_page' => 10, 'post_type' => 'listing' , 'order' => 'ASC' , 
					 'meta_query' => array(
						array(
							'key'     => 'address',
							'value'   => $_POST['address'],
							'compare' => 'LIKE'
						),
						array(
							'key'     => 'home_type',
							'value'   => $_POST['property'],
							'compare' => 'LIKE'
						),
						array(
							'key'     => 'bedroom_text',
							'value'   => $_POST['bedroom'],
							'compare' => 'LIKE'
						),
						array(
							'key'     => 'guest_text',
							'value'   => $_POST['guest'],
							'compare' => 'LIKE'
						),
					 ),
			
				);

				$myposts = get_posts( $args );
				foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
				
					
					<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article">
						<div class="col-sm-3 listingimage">
								<?php if ( has_post_thumbnail() ) {
											
												?><a href="<?php  the_permalink(); ?>"> <?php	the_post_thumbnail('thumbnail'); ?> </a> <?php
											
										} 	
										
									  else {
											if(get_the_title() == "Amazing 2 Bed in Waikiki") {
												?>
												<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/9-rs31.jpg" alt="" title="" />			
												<?php
											} if (get_the_title() == "Great Cabin in the Woods") {
												?>
												<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/enlighted-65961_400-1.jpg" alt="" title="" />			
												<?php
											} if (get_the_title() == "Modern Lakefront Home") {
												?>
												<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/beach-house-349670_400-1.jpg" alt="" title="" />			
												<?php
											}
									 }  		
								?>				
						</div>
						
						<div class="col-sm-5 listingbg">
							<header>
									<div class="page-header"><h1 class="page-title" itemprop="headline"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1></div>
									<p><?php echo $address = get_post_meta( $post->ID, 'address', true ); ?></p>
									<p><strong>Property Type</strong> <?php echo $home_type = get_post_meta( $post->ID, 'home_type', true ); ?></p>
							</header> <!-- end article header -->
						
							<section class="post_content clearfix">
								<?php the_excerpt(); ?>
							</section> <!-- end article section -->
							
							<footer>
								<p class="tags"><?php the_tags('<span class="tags-title">' . __("Tags","wpbootstrap") . ':</span> ', ' ', ''); ?></p>	
							</footer> <!-- end article footer -->
						</div>
						<div class="col-sm-4 listinglist">	
							<section class="post_content clearfix">
								<big><strong>Daily Price</strong> : $ <?php echo $price_text = get_post_meta( $post->ID, 'price_text', true ); ?></big><br/>
								<strong>Weekly Price</strong> : $ <?php echo $weeklyprice_text = get_post_meta( $post->ID, 'weeklyprice_text', true ); ?><br/>
								<strong>Monthly Price</strong> : $ <?php echo $monthlyprice_text = get_post_meta( $post->ID, 'monthlyprice_text', true ); ?><br/>
								<strong>Extra people</strong> : $ <?php echo $extrapeople_text = get_post_meta( $post->ID, 'extrapeople_text', true ); ?><br/>
								<strong>Security deposit</strong> :  $ <?php echo $deposit_text = get_post_meta( $post->ID, 'deposit_text', true ); ?><br/>
								
								<br/>
								<p><strong>Bedrooms</strong> <?php echo $bedroom_text = get_post_meta( $post->ID, 'bedroom_text', true ); ?> </p>
								<p><strong>Beds</strong> <?php echo $bed_text = get_post_meta( $post->ID, 'bed_text', true ); ?> </p>
								<br/>
								<a class="booknow" href="<?php the_permalink() ?>">Book Now</a>
							</section> <!-- end article section -->
						</div>
					</article> <!-- end article -->
					
					<br style="clear:both;" />
					
					<?php endforeach; 
					wp_reset_postdata();?>
					
					<?php if (function_exists('wp_bootstrap_page_navi')) { // if expirimental feature is active ?>
						
						<?php wp_bootstrap_page_navi(); // use the page navi function ?>
						
					<?php } else { // if it is disabled, display regular wp prev & next links ?>
						<nav class="wp-prev-next">
							<ul class="pager">
								<li class="previous"><?php next_posts_link(_e('&laquo; Older Entries', "wpbootstrap")) ?></li>
								<li class="next"><?php previous_posts_link(_e('Newer Entries &raquo;', "wpbootstrap")) ?></li>
							</ul>
						</nav>
					<?php } ?>		

			
				</div> <!-- end #main -->
				
				
				<div class="clearfix"></div>
			</div> <!-- end #content -->
</div>
<?php get_footer(); ?>

