<?php get_header(); ?>
<?php global $post; ?>
<?php echo do_shortcode('[postimage]') ?>		
</div>
<div class="container">
<div id="content" class="clearfix row">
<br/><br/>


<div class="page-header"><h1 style="text-align:center;" class="single-title" itemprop="headline"><?php the_title(); ?></h1></div>
	<?php  
	$meta = get_post_meta($post->ID,'_my_meta',TRUE);	
	?>
	<p style="text-align:center;" class="address"><?php echo $address = get_post_meta( $post->ID, 'address', true ); ?>
	<?php 	?>
	
	</p>
	<br/><br/>
	<div id="main" class="col-sm-8 clearfix" role="main">

		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">
				<header>
				<div class="col-sm-3 top-cat-img">
					<img src="<?php echo get_template_directory_uri(); ?>/images/home_48.png" alt="home type" title="home type" />
					<br/><p><?php echo $home_type = get_post_meta( $post->ID, 'home_type', true ); ?></p>
				</div>
				
				<div class="col-sm-3 top-cat-img">
					<img src="<?php echo get_template_directory_uri(); ?>/images/Guest-48.png" alt="guest" title="guest" />
					<br/><p><?php echo $guest_text = get_post_meta( $post->ID, 'guest_text', true ); ?> Guests</p>
				</div>
				
				
				<div class="col-sm-3 top-cat-img">
					<img src="<?php echo get_template_directory_uri(); ?>/images/Hotel-48.png" alt="bedroom" title="bedroom" />
					<br/><p><?php echo $bedroom_text = get_post_meta( $post->ID, 'bedroom_text', true ); ?> Bedrooms</p>
				</div>
					
					
				<div class="col-sm-3 top-cat-img"><img src="<?php echo get_template_directory_uri(); ?>/images/Bed-48.png" alt="bed" title="bed" />
				<br/><p><?php echo $bed_text = get_post_meta( $post->ID, 'bed_text', true ); ?> Beds</p>
				</div>
						
				</header> <!-- end article header -->
					
						<section class="post_content clearfix" itemprop="articleBody">
							<?php the_content(); ?>
							<?php wp_link_pages(); ?>
							
						<br/><br/>
						<hr/>
						<div class="types">
							<div class="col-sm-2">
								The Space 
							</div>
							<div class="col-sm-10">
								<strong>Property type: </strong><?php echo $home_type; ?><br/>
								<strong>Accommodates: </strong><?php echo $guest_text; ?><br/>
								<strong>Bedrooms: </strong><?php echo $bedroom_text; ?><br/>
							</div>
							<br style="clear:both;" />
						</div>
						<br/><br/>
						<hr/>
						<div class="types">
							<div class="col-sm-2">
								Amenities 
							</div>
							<div class="col-sm-10">
							<?php  $amenities_multicheckbox = get_post_meta( $post->ID, 'amenities_multicheckbox', true );
								$count = count($amenities_multicheckbox); ?>
								<div class="col-sm-12">
								<?php for($i = 0; $i < $count; $i++) { ?>
										<img class="check" src=" <?php echo get_template_directory_uri(); ?>/images/check.png" /><?php echo $amenities_multicheckbox[$i] ?><br/>
								<?php }   ?>
								</div>

							</div>
							<br style="clear:both;" />
						</div>
						<br/><br/>
						<hr/>
						<div class="types">
							<div class="col-sm-2">
								Prices
							</div>
							<div class="col-sm-5">
								<strong>Extra people</strong> : $ <?php echo $extrapeople_text = get_post_meta( $post->ID, 'extrapeople_text', true ); ?></strong><br/>
								<strong>Security deposit</strong> :  $ <?php echo $deposit_text = get_post_meta( $post->ID, 'deposit_text', true ); ?><br/>
								<strong>Daily Price</strong> : $  <?php echo $price_text = get_post_meta( $post->ID, 'price_text', true ); ?><br/>
								<strong>Weekly Price</strong> : $  <?php echo $weeklyprice_text = get_post_meta( $post->ID, 'weeklyprice_text', true ); ?><br/>
								<strong>Monthly Price</strong> : $  <?php echo $monthlyprice_text = get_post_meta( $post->ID, 'monthlyprice_text', true ); ?><br/>
								
							</div>
							<div class="col-sm-5">
								
								<strong>Permit Number</strong> : <?php echo $permitno_text = get_post_meta( $post->ID, 'permitno_text', true ); ?><br/>
							</div>
							<br style="clear:both;" />
						</div>
						</section> <!-- end article section -->
						
						<footer>
			
							<?php the_tags('<p class="tags"><span class="tags-title">' . __("Tags","wpbootstrap") . ':</span> ', ' ', '</p>'); ?>
							<?php 
							// only show edit button if user has permission to edit posts
							if( $user_level > 0 ) { 
							?>
							<a href="<?php echo get_edit_post_link(); ?>" class="btn btn-success edit-post"><i class="icon-pencil icon-white"></i> <?php _e("Edit post","wpbootstrap"); ?></a>
							<?php } ?>
							
						</footer> <!-- end article footer -->
					
					</article> <!-- end article -->
					
					<?php comments_template('',true); ?>
					
					<?php endwhile; ?>			
					
					<?php else : ?>
					
					<article id="post-not-found">
					    <header>
					    	<h1><?php _e("Not Found", "wpbootstrap"); ?></h1>
					    </header>
					    <section class="post_content">
					    	<p><?php _e("Sorry, but the requested resource was not found on this site.", "wpbootstrap"); ?></p>
					    </section>
					    <footer>
					    </footer>
					</article>
					
					<?php endif; ?>
			
				</div> <!-- end #main -->
				
				<div id="main" class="col-sm-4">
				
				<?php 
				
				$address = str_replace(' ', ',+', $address);
				
				$url = "http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false";
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				$response = curl_exec($ch);
				curl_close($ch);
				$response_a = json_decode($response);
				 $lat = $response_a->results[0]->geometry->location->lat;
				 $long = $response_a->results[0]->geometry->location->lng;

				?>
				<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
				<div style="overflow:hidden;height:300px;width:100%;">
				<div id="gmap_canvas" style="height:300px;width:100%;"></div>
					<style>#gmap_canvas img{max-width:none!important;background:none!important}</style>
				</div>
				<script type="text/javascript"> function init_map(){var myOptions = {zoom:14,center:new google.maps.LatLng(<?php echo $lat; ?> , <?php echo $long; ?>),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(<?php echo $lat; ?> , <?php echo $long; ?>)});infowindow = new google.maps.InfoWindow({content:"<?php echo $address; ?>" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
				
				<a target="blank" class="map" href="https://www.google.com.ph/maps/place/<?php echo $address; ?>/@<?php echo $lat; ?>,<?php echo $long; ?>">View Large Map</a>
				
				<h2 style="text-align:center;">Check Out Other Listings</h2>	
				
				<?php 
					global $post;
				
					$args = array(
					
					'post_type' => 'listing',
								  'order' => 'ASC',
								  'post__not_in'   => array($post->ID)
					);
					
				query_posts( $args );
				
				if (have_posts() ) : while ( have_posts() ) : the_post(); ?>
					
	
					<?php 
					
					endwhile; else: ?>
					 <!-- REALLY stop The Loop. -->
				<?php endif; 

				if (have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<a style="color:#565a5c;" href="<?php  the_permalink(); ?>">
								<?php	echo '<p ><strong><center>';
								the_title();
								echo '</center></strong></p></a>';
								if ( has_post_thumbnail() ) {
								?><a href="<?php  the_permalink(); ?>"> <?php	the_post_thumbnail('large'); ?> </a> <?php
								} else {
									if(get_the_title() == "Amazing 2 Bed in Waikiki") {
										?>
										<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/9-rs31.jpg" alt="" title="" />			
										<?php
									} if (get_the_title() == "Great Cabin in the Woods") {
										?>
										<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/enlighted-65961_400-1.jpg" alt="" title="" />			
										<?php
									} if (get_the_title() == "Modern Lakefront Home") {
										?>
										<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/beach-house-349670_400-1.jpg" alt="" title="" />			
										<?php
									}
								} 	
					?>
					<!-- Stop The Loop (but note the "else:" - see next line). -->
					
				 <?php endwhile; else: ?>
					<p>Sorry, no other listings matched your criteria.</p>

				 <!-- REALLY stop The Loop. -->
				 <?php endif; ?>
				

				<br/><br/>
				</div>

			</div> <!-- end #content -->
</div>
<?php  get_footer(); ?>