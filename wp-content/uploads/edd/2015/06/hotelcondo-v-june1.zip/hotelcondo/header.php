<!doctype html>  

<!--[if IEMobile 7 ]> <html <?php language_attributes(); ?>class="no-js iem7"> <![endif]-->
<!--[if lt IE 7 ]> <html <?php language_attributes(); ?> class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html <?php language_attributes(); ?> class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html <?php language_attributes(); ?> class="no-js ie8"> <![endif]-->
<!--[if (gte IE 9)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!--><html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->
	
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<title><?php wp_title( '|', true, 'right' ); ?></title>	
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
  		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">

		<!-- wordpress head functions -->
		<?php wp_head(); ?>
		<!-- end of wordpress head -->
		<!-- IE8 fallback moved below head to work properly. Added respond as well. Tested to work. -->
			<!-- media-queries.js (fallback) -->
		<!--[if lt IE 9]>
			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>			
		<![endif]-->

		<!-- html5.js -->
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->	
		
			<!-- respond.js -->
		<!--[if lt IE 9]>
		          <script type='text/javascript' src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.js"></script>
		<![endif]-->	
		
		   <!-- get jQuery from the google apis -->
		   		
		<!-- CSS STYLE-->
		<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/style.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/style.css" media="screen" />
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300' rel='stylesheet' type='text/css'>
	</head>
	
	<body <?php body_class(); ?> style="background-color:<?php echo of_get_option( 'bodybg', '' ); ?>;">
		<header role="banner" class="top-header">
				
			<div class="navbar navbar-default">
				<div class="container" style="background-color:<?php echo of_get_option( 'colorpicker', '#000' ); ?>;">
          
				<div class="col-sm-6">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

						<a class="navbar-brand" title="<?php bloginfo('name'); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" alt="<?php bloginfo('name'); ?>"  />
						<?php
						 $logotext = of_get_option( 'img_logo_or_not', '' ); 
						 $logo_image = of_get_option( 'logo', '' ); 
						if ($logotext == NULL && $logo_image == NULL) {   ?>
							<h1 class="logo-title"><?php bloginfo('name'); ?></h1>
						<?php } ?>

						<?php $logo = of_get_option( 'img_logo_or_not', '' ); 
						if($logo == "text") {  ?>
							<h1 class="logo-title"><?php echo of_get_option( 'logo_text', 'Logo Here' );  ?></h1>
						<?php }  else if ($logo == "image") { ?>
							<img src="<?php echo of_get_option( 'logo', 'Logo Here' ); ?>" alt="Logo" title="Logo" />
						<?php } ?>
						</a>
					</div>
				</div>	
				<div class="col-sm-6">
					<div class="collapse navbar-collapse navbar-responsive-collapse">
						
						 <?php
						if ( has_nav_menu( "main_nav" ) ) {
							
						} else {
						?>	
							<ul id="menu-main-menu" class="nav navbar-nav">
							 <?php
									wp_list_pages( array(
										'title_li' => ''
									));
							 ?>
							 </ul>	
						<?php	
						}  
					 
						wp_bootstrap_main_nav(); // Adjust using Menus in Wordpress Admin ?>
					</div>
					
					<?php $phoneselect = of_get_option( 'phone_select', 'yes' ); 
					if($phoneselect == "yes") { ?>
					<p><a class="phone-no" href="tel:<?php echo of_get_option( 'phone', '#' ); ?>"><?php echo of_get_option( 'phone', '555-555-5555' ); ?></a></p>
					<?php } ?>
				</div>	
					<br style="clear:both;" />

				</div> <!-- end .container -->
			</div> <!-- end .navbar -->
		
		</header> <!-- end header -->

 