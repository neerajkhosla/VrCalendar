			<footer id="footermax" role="contentinfo">
			
				<div style="max-width:1108px; margin:0px auto 0 auto; padding:20px 0; display:block;" id="inner-footer" class="clearfix">
					
		          <div id="widget-footer" class="clearfix row">
					  <?php if ( is_active_sidebar( 'footer1' ) ) { ?>
							<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer1') ) : ?>
							<?php endif; ?>
					  <?php } else { ?>
					  <div id="sidebar1" class="col-sm-4" role="complementary">
						<h4 class="widgettitle"> Like Us on Facebook!</h4>
						<div style="  margin: 0 auto;  width: 300px;  background-color: white;  height: 289px;">
						
						<div id="fb-root"></div>
						<script>(function(d, s, id) {
						  var js, fjs = d.getElementsByTagName(s)[0];
						  if (d.getElementById(id)) return;
						  js = d.createElement(s); js.id = id;
						  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3&appId=120522671443506";
						  fjs.parentNode.insertBefore(js, fjs);
						}(document, 'script', 'facebook-jssdk'));</script>
						<div class="fb-page" data-href="https://www.facebook.com/vrfrontdesk" data-width="300" data-height="289" data-hide-cover="false" data-show-facepile="true" data-show-posts="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/vrfrontdesk"><a href="https://www.facebook.com/vrfrontdesk">VR Front Desk - Airbnb and Homeaway Management</a></blockquote></div></div>
						</div>						 
					  </div>	  
					<?php } ?>	
					<?php if ( is_active_sidebar( 'footer2' ) ) { ?>
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer2') ) : ?>
		            <?php endif; ?>
					<?php } else { ?>
					  <div id="sidebar1" class="col-sm-4" role="complementary">
					  <h4 class="widgettitle">Recent Post</h4>
					    <ul>
							<?php $the_query = new WP_Query( 'showposts=5' ); ?>
							<?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
							<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
							<?php endwhile;?>
						</ul>
					  </div>
					<?php } ?>	
					<?php if ( is_active_sidebar( 'footer3' ) ) { ?>
		            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer3') ) : ?>
		            <?php endif; ?>
					<?php } else { ?>
					  <div id="sidebar1" class="col-sm-4" role="complementary">
					  <h4 class="widgettitle">Pages</h4>
					    <ul>
							 <?php
									wp_list_pages( array(
										'title_li' => ''
									));
							 ?>
							 </ul>	
					  </div>
					<?php } ?>	
		          </div>
					
					<nav class="clearfix">
						<?php wp_bootstrap_footer_links(); // Adjust using Menus in Wordpress Admin ?>
					</nav>
					
					<hr/>
					
					<?php $socialyesno = of_get_option( 'social_footer', 'yes' );  
					if ($socialyesno == "yes") {
					?>
					
					<p class="social">Join Us On</p>
					
					
					
					<p class="socialicons"><a href="<?php echo of_get_option( 'facebook_text', 'http://www.facebook.com' ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/Facebook-32.png" alt="fb" title="fb" /></a>
					<a href="<?php echo of_get_option( 'google_text', 'http://www.google.com' ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/Google-32.png" alt="fb" title="fb" /></a>
					<a href="<?php echo of_get_option( 'twitter_text', 'http://www.twitter.com' ); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/Twitter-32.png" alt="fb" title="fb" /></a>
					</p>
					<?php } 
					$phoneselect = of_get_option( 'phone_select', 'yes' ); 
					if($phoneselect == "yes") { ?>
						<p><a class="phone-no-footer" href="tel:<?php echo of_get_option( 'phone', '#' ); ?>"><?php echo of_get_option( 'phone', 'Text for phone no.' ); ?></a></p>
					<?php } ?>
					<p class="copyright"><?php echo of_get_option( 'copy_right', 'Text for copyright' ); ?></p>
			
					
				
				</div> <!-- end #inner-footer -->
				
			</footer> <!-- end footer -->
				
		<!--[if lt IE 7 ]>
  			<script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.3/CFInstall.min.js"></script>
  			<script>window.attachEvent('onload',function(){CFInstall.check({mode:'overlay'})})</script>
		<![endif]-->
		
		<?php wp_footer(); // js scripts are inserted using this function ?>

		<!-- remove this for production -->

		<script src="//localhost:35729/livereload.js"></script>
<style>
.navbar-nav > li > a { color:<?php echo of_get_option( 'nav-color', '' ); ?>!important; font-size:<?php echo of_get_option( 'naviation_size', '' ); ?>!important; }
p , .title-home, .title-homea , .page-title { color:<?php echo of_get_option( 'content-color', '' ); ?>!important;  }
.phone-no { color:<?php echo of_get_option( 'phone-color', '' ); ?>!important;  }
.logo-title { color:<?php echo of_get_option( 'logo-title', '' ); ?>!important; }
</style>
	</body>

</html>