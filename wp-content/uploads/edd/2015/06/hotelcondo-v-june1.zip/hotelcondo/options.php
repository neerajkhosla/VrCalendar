<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 */
function optionsframework_option_name() {
	// Change this to use your theme slug
	return 'options-framework-theme';
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'theme-textdomain'
 * with the actual text domain for your theme.  Read more:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
 */

function optionsframework_options() {

	// Test data
	$test_array = array(
		'yes' => __( 'yes', 'theme-textdomain' ),
		'no' => __( 'no', 'theme-textdomain' )
	);
	
	$upload_array = array(
		'image' => __( 'image', 'theme-textdomain' ),
		'text' => __( 'text', 'theme-textdomain' )
	);

	// Multicheck Array
	$fontsize_array = array(
		'10px' => __( '10px', 'theme-textdomain' ),
		'11px' => __( '11px', 'theme-textdomain' ),
		'12px' => __( '12px', 'theme-textdomain' ),
		'13px' => __( '13px', 'theme-textdomain' ),
		'14px' => __( '14px', 'theme-textdomain' ),
		'15px' => __( '15px', 'theme-textdomain' ),
		'16px' => __( '16px', 'theme-textdomain' ),
		'17px' => __( '17px', 'theme-textdomain' ),
		'18px' => __( '18px', 'theme-textdomain' ),
		'19px' => __( '19px', 'theme-textdomain' ),
		'19px' => __( '19px', 'theme-textdomain' ),
		'18px' => __( '18px', 'theme-textdomain' ),
		'19px' => __( '19px', 'theme-textdomain' ),
		'20px' => __( '20px', 'theme-textdomain' ),
		'21px' => __( '21px', 'theme-textdomain' ),
		'22px' => __( '22px', 'theme-textdomain' ),
		'23px' => __( '23px', 'theme-textdomain' ),
		'24px' => __( '24px', 'theme-textdomain' ),
		'25px' => __( '25px', 'theme-textdomain' ),
		'26px' => __( '26px', 'theme-textdomain' ),
		'27px' => __( '27px', 'theme-textdomain' ),
		'28px' => __( '28px', 'theme-textdomain' ),
		'29px' => __( '29px', 'theme-textdomain' ),
		'30px' => __( '30px', 'theme-textdomain' )
	);

	// Multicheck Defaults
	$multicheck_defaults = array(
		'one' => '1',
		'five' => '1'
	);

	// Background Defaults
	$background_defaults = array(
		'color' => '',
		'image' => '',
		'repeat' => 'repeat',
		'position' => 'top center',
		'attachment'=>'scroll' );

	// Typography Defaults
	$typography_defaults = array(
		'size' => '15px',
		'face' => 'georgia',
		'style' => 'bold',
		'color' => 'black' );

	// Typography Options
	$typography_options = array(
		'sizes' => array( '6','12','14','16','20' ),
		'faces' => array( 'Helvetica Neue' => 'Helvetica Neue','Arial' => 'Arial' ),
		'styles' => array( 'normal' => 'Normal','bold' => 'Bold' ),
		'color' => false
	);

	// Pull all the categories into an array
	$options_categories = array();
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	// Pull all tags into an array
	$options_tags = array();
	$options_tags_obj = get_tags();
	foreach ( $options_tags_obj as $tag ) {
		$options_tags[$tag->term_id] = $tag->name;
	}


	// Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages( 'sort_column=post_parent,menu_order' );
	$options_pages[''] = 'Select a page:';
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}
	
	$wp_editor_settings = array(
		'wpautop' => true, // Default
		'textarea_rows' => 10,
		'quicktags' => true,
		'teeny' => true,
		'media_buttons' => true,
		'tinymce' => true,
		'quicktags' => true,
		'teeny' => true
	);


	// If using image radio buttons, define a directory path
	$imagepath =  get_template_directory_uri() . '/images/';

	$options = array();

	$options[] = array(
		'name' => __( 'Settings', 'theme-textdomain' ),
		'type' => 'heading'
	);
	

	$options[] = array(
		'name' => __( 'Logo Upload here', 'theme-textdomain' ),
		'desc' => __( 'Upload logo 150x150', 'theme-textdomain' ),
		'id' => 'logo',
		'type' => 'upload'
	);
	
	$options[] = array(
		'name' => __( 'Text Logo here', 'theme-textdomain' ),
		'desc' => __( 'Add Text Logo here', 'theme-textdomain' ),
		'id' => 'logo_text',
		'std' => 'Title Here',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Select image or text', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'img_logo_or_not',
		'std' => 'image',
		'type' => 'radio',
		'options' => $upload_array
	);

	
	$options[] = array(
		'name' => __( 'Facebook Link', 'theme-textdomain' ),
		'desc' => __( 'Link for facebook', 'theme-textdomain' ),
		'id' => 'facebook_text',
		'std' => 'https://www.facebook.com/',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Google Plus Link', 'theme-textdomain' ),
		'desc' => __( 'Link for google plus', 'theme-textdomain' ),
		'id' => 'google_text',
		'std' => 'https://www.google.com',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Twitter Plus Link', 'theme-textdomain' ),
		'desc' => __( 'Link for twitter', 'theme-textdomain' ),
		'id' => 'twitter_text',
		'std' => 'https://twitter.com/',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Option for social link on footer', 'theme-textdomain' ),
		'desc' => __( 'Option for social link on footer', 'theme-textdomain' ),
		'id' => 'social_footer',
		'std' => 'yes',
		'type' => 'radio',
		'options' => $test_array
	);
	
	$options[] = array(
		'name' => __( 'Text for copyright', 'theme-textdomain' ),
		'desc' => __( 'Text for copyright', 'theme-textdomain' ),
		'id' => 'copy_right',
		'std' => 'All rights reserved &copy; http://example.com',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Text for phone no.', 'theme-textdomain' ),
		'desc' => __( 'phone number', 'theme-textdomain' ),
		'id' => 'phone',
		'std' => '123-456',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Phone link on / off', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'phone_select',
		'std' => 'yes',
		'type' => 'radio',
		'options' => $test_array
	);


	
	$options[] = array(
		'name' => __( 'Home Page Settings', 'theme-textdomain' ),
		'type' => 'heading'
	);
	
	
	
	$options[] = array(
		'name' => __( 'Top Text Title', 'theme-textdomain' ),
		'desc' => __( 'Top text Title home page', 'theme-textdomain' ),
		'id' => 'top_text',
		'std' => 'Default',
		'class' => 'text',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Top sub text title', 'theme-textdomain' ),
		'desc' => __( 'Top sub text title home page', 'theme-textdomain' ),
		'id' => 'top_sub',
		'std' => 'Default',
		'class' => 'text',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'First image for popular image here', 'theme-textdomain' ),
		'desc' => __( 'First image for popular image here', 'theme-textdomain' ),
		'id' => 'logo-image-popular1',
		'type' => 'upload'
	);
	
	$options[] = array(
		'name' => __( 'First image for popular link here', 'theme-textdomain' ),
		'desc' => __( 'First image for popular link here', 'theme-textdomain' ),
		'id' => 'logo-popular-link1',
		'std' => 'http://waikikivacationscondo.com',
		'class' => 'text',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Second image for popular image here', 'theme-textdomain' ),
		'desc' => __( 'Second image for popular image here', 'theme-textdomain' ),
		'id' => 'logo-image-popular2',
		'type' => 'upload'
	);
	
	$options[] = array(
		'name' => __( 'Second image for popular link here', 'theme-textdomain' ),
		'desc' => __( 'Second image for popular link here', 'theme-textdomain' ),
		'id' => 'logo-popular-link2',
		'std' => 'http://waikikivacationscondo.com',
		'class' => 'text',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Third image for popular image here', 'theme-textdomain' ),
		'desc' => __( 'Third image for popular image here', 'theme-textdomain' ),
		'id' => 'logo-image-popular3',
		'type' => 'upload'
	);
	
	$options[] = array(
		'name' => __( 'Third image for popular link here', 'theme-textdomain' ),
		'desc' => __( 'Third image for popular link here', 'theme-textdomain' ),
		'id' => 'logo-popular-link3',
		'std' => 'http://waikikivacationscondo.com',
		'class' => 'text',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Mid Text Title', 'theme-textdomain' ),
		'desc' => __( 'Mid text Title home page', 'theme-textdomain' ),
		'id' => 'mid_text',
		'std' => 'Default',
		'class' => 'text',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Mid sub text title', 'theme-textdomain' ),
		'desc' => __( 'Mid sub text title home page', 'theme-textdomain' ),
		'id' => 'mid_sub',
		'std' => 'Default',
		'class' => 'text',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Mid Text Editor', 'theme-textdomain' ),
		'desc' => sprintf( __( '', 'theme-textdomain' ), 'http://codex.wordpress.org/Function_Reference/wp_editor' ),
		'id' => 'mid_editor',
		'std' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel egestas est. Quisque odio orci, porttitor et felis vel, facilisis ultricies ante. Donec eget lacus posuere, convallis purus eu, vestibulum dui. Suspendisse luctus tortor lacus, ut porttitor metus accumsan ac. Nam non laoreet libero. Etiam eu nulla in sem scelerisque pharetra. Curabitur congue elit eget dignissim interdum. Quisque id turpis mattis est bibendum iaculis. Nulla nisi tortor, mattis vel nisl sit amet, fermentum tempus erat. Cras dignissim, ipsum vel vehicula euismod, mi tellus viverra felis, quis volutpat dui ligula nec nunc. ',
		'type' => 'editor',
		'settings' => $wp_editor_settings
	);
	
	
	$options[] = array(
		'name' => __( 'Bottom Text Title', 'theme-textdomain' ),
		'desc' => __( 'Bottom text Title home page', 'theme-textdomain' ),
		'id' => 'bottom_text',
		'std' => 'Listing',
		'class' => 'text',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Bottom Sub Text Title', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'bottom_sub',
		'std' => 'See All Listings Here',
		'type' => 'editor',
		'settings' => $wp_editor_settings
	);
	
	$options[] = array(
		'name' => __( 'Style Website Settings', 'theme-textdomain' ),
		'type' => 'heading'
	);
	
	$options[] = array(
		'name' => __( 'Text logo title color ', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'logo-title',
		'std' => '',
		'type' => 'color'
	);
	
	$options[] = array(
		'name' => __( 'Body color background', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'bodybg',
		'std' => '',
		'type' => 'color'
	);
	
	$options[] = array(
		'name' => __( 'Header background', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'colorpicker',
		'std' => '',
		'type' => 'color'
	);
	
	$options[] = array(
		'name' => __( 'Header navigation color', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'nav-color',
		'std' => '',
		'type' => 'color'
	);
	
	$options[] = array(
		'name' => __( 'Header navigation size', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'naviation_size',
		'std' => 'three',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $fontsize_array
	);
	
	$options[] = array(
		'name' => __( 'Header phone no. color', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'phone-color',
		'std' => '',
		'type' => 'color'
	);
	

	$options[] = array(
		'name' => __( 'Content text color', 'theme-textdomain' ),
		'desc' => __( '', 'theme-textdomain' ),
		'id' => 'content-color',
		'std' => '',
		'type' => 'color'
	);
	
	


	return $options;
}