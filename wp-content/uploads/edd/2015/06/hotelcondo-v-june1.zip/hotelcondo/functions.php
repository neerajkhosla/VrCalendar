<?php
add_action('after_switch_theme', 'my_theme_activation');



function my_theme_activation () {
 global $wp_rewrite;
 $wp_rewrite->flush_rules();
}

// Add Translation Option
load_theme_textdomain( 'wpbootstrap', TEMPLATEPATH.'/languages' );
$locale = get_locale();
$locale_file = TEMPLATEPATH . "/languages/$locale.php";
if ( is_readable( $locale_file ) ) require_once( $locale_file );

// Clean up the WordPress Head
if( !function_exists( "wp_bootstrap_head_cleanup" ) ) {  
  function wp_bootstrap_head_cleanup() {
    // remove header links
    remove_action( 'wp_head', 'feed_links_extra', 3 );                    // Category Feeds
    remove_action( 'wp_head', 'feed_links', 2 );                          // Post and Comment Feeds
    remove_action( 'wp_head', 'rsd_link' );                               // EditURI link
    remove_action( 'wp_head', 'wlwmanifest_link' );                       // Windows Live Writer
    remove_action( 'wp_head', 'index_rel_link' );                         // index link
    remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 );            // previous link
    remove_action( 'wp_head', 'start_post_rel_link', 10, 0 );             // start link
    remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 ); // Links for Adjacent Posts
    remove_action( 'wp_head', 'wp_generator' );                           // WP version
  }
}
// Launch operation cleanup
add_action( 'init', 'wp_bootstrap_head_cleanup' );

// remove WP version from RSS
if( !function_exists( "wp_bootstrap_rss_version" ) ) {  
  function wp_bootstrap_rss_version() { return ''; }
}
add_filter( 'the_generator', 'wp_bootstrap_rss_version' );

// Remove the […] in a Read More link
if( !function_exists( "wp_bootstrap_excerpt_more" ) ) {  
  function wp_bootstrap_excerpt_more( $more ) {
    global $post;
    return '...  <a href="'. get_permalink($post->ID) . '" class="more-link" title="Read '.get_the_title($post->ID).'">Read more &raquo;</a>';
  }
}
add_filter('excerpt_more', 'wp_bootstrap_excerpt_more');

// Add WP 3+ Functions & Theme Support
if( !function_exists( "wp_bootstrap_theme_support" ) ) {  
  function wp_bootstrap_theme_support() {
    add_theme_support( 'post-thumbnails' );      // wp thumbnails (sizes handled in functions.php)
    set_post_thumbnail_size( 350, 250, true );   // default thumb size
    add_theme_support( 'custom-background' );  // wp custom background
    add_theme_support( 'automatic-feed-links' ); // rss

    // Add post format support - if these are not needed, comment them out
    add_theme_support( 'post-formats',      // post formats
      array( 
        'aside',   // title less blurb
        'gallery', // gallery of images
        'link',    // quick link to other site
        'image',   // an image
        'quote',   // a quick quote
        'status',  // a Facebook like status update
        'video',   // video 
        'audio',   // audio
        'chat'     // chat transcript 
      )
    );  

    add_theme_support( 'menus' );            // wp menus
    
    register_nav_menus(                      // wp3+ menus
      array( 
        'main_nav' => 'The Main Menu',   // main nav in header
        'footer_links' => 'Footer Links' // secondary nav in footer
      )
    );  
  }
}
// launching this stuff after theme setup
add_action( 'after_setup_theme','wp_bootstrap_theme_support' );

function wp_bootstrap_main_nav() {
  // Display the WordPress menu if available
  wp_nav_menu( 
    array( 
      'menu' => 'main_nav', /* menu name */
      'menu_class' => 'nav navbar-nav',
      'theme_location' => 'main_nav', /* where in the theme it's assigned */
      'container' => 'false', /* container class */
      'fallback_cb' => 'wp_bootstrap_main_nav_fallback', /* menu fallback */
      'walker' => new Bootstrap_walker()
    )
  );
}

function wp_bootstrap_footer_links() { 
  // Display the WordPress menu if available
  wp_nav_menu(
    array(
      'menu' => 'footer_links', /* menu name */
      'theme_location' => 'footer_links', /* where in the theme it's assigned */
      'container_class' => 'footer-links clearfix', /* container class */
      'fallback_cb' => 'wp_bootstrap_footer_links_fallback' /* menu fallback */
    )
  );
}

// this is the fallback for header menu
function wp_bootstrap_main_nav_fallback() { 
  /* you can put a default here if you like */ 
}

// this is the fallback for footer menu
function wp_bootstrap_footer_links_fallback() { 
  /* you can put a default here if you like */ 
}

// Shortcodes
require_once('library/shortcodes.php');

// Admin Functions (commented out by default)
// require_once('library/admin.php');         // custom admin functions

// Custom Backend Footer
add_filter('admin_footer_text', 'wp_bootstrap_custom_admin_footer');
function wp_bootstrap_custom_admin_footer() {
	echo '<span id="footer-thankyou">Developed by Innate Images LLC</span>';
}

// adding it to the admin area
add_filter('admin_footer_text', 'wp_bootstrap_custom_admin_footer');

// Set content width
if ( ! isset( $content_width ) ) $content_width = 580;

/************* THUMBNAIL SIZE OPTIONS *************/

// Thumbnail sizes
add_image_size( 'wpbs-featured', 780, 300, true );
add_image_size( 'wpbs-featured-home', 970, 311, true);
add_image_size( 'wpbs-featured-carousel', 970, 400, true);

/* 
to add more sizes, simply copy a line from above 
and change the dimensions & name. As long as you
upload a "featured image" as large as the biggest
set width or height, all the other sizes will be
auto-cropped.

To call a different size, simply change the text
inside the thumbnail function.

For example, to call the 300 x 300 sized image, 
we would use the function:
<?php the_post_thumbnail( 'bones-thumb-300' ); ?>
for the 600 x 100 image:
<?php the_post_thumbnail( 'bones-thumb-600' ); ?>

You can change the names and dimensions to whatever
you like. Enjoy!
*/

/************* ACTIVE SIDEBARS ********************/

// Sidebars & Widgetizes Areas
function wp_bootstrap_register_sidebars() {
  register_sidebar(array(
  	'id' => 'sidebar1',
  	'name' => 'Main Sidebar',
  	'description' => 'Used on every page BUT the homepage page template.',
  	'before_widget' => '<div id="%1$s" class="widget %2$s">',
  	'after_widget' => '</div>',
  	'before_title' => '<h4 class="widgettitle">',
  	'after_title' => '</h4>',
  ));
    
  register_sidebar(array(
  	'id' => 'sidebar2',
  	'name' => 'Homepage Sidebar',
  	'description' => 'Used only on the homepage page template.',
  	'before_widget' => '<div id="%1$s" class="widget %2$s">',
  	'after_widget' => '</div>',
  	'before_title' => '<h4 class="widgettitle">',
  	'after_title' => '</h4>',
  ));
    
  register_sidebar(array(
    'id' => 'footer1',
    'name' => 'Footer 1',
    'before_widget' => '<div id="%1$s" class="widget col-sm-4 %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h4 class="widgettitle">',
    'after_title' => '</h4>',
  ));

  register_sidebar(array(
    'id' => 'footer2',
    'name' => 'Footer 2',
    'before_widget' => '<div id="%1$s" class="widget col-sm-4 %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h4 class="widgettitle">',
    'after_title' => '</h4>',
  ));

  register_sidebar(array(
    'id' => 'footer3',
    'name' => 'Footer 3',
    'before_widget' => '<div id="%1$s" class="widget col-sm-4 %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h4 class="widgettitle">',
    'after_title' => '</h4>',
  ));
    
    
  /* 
  to add more sidebars or widgetized areas, just copy
  and edit the above sidebar code. In order to call 
  your new sidebar just use the following code:
  
  Just change the name to whatever your new
  sidebar's id is, for example:
  
  To call the sidebar in your template, you can just copy
  the sidebar.php file and rename it to your sidebar's name.
  So using the above example, it would be:
  sidebar-sidebar2.php
  
  */
} // don't remove this bracket!
add_action( 'widgets_init', 'wp_bootstrap_register_sidebars' );

/************* COMMENT LAYOUT *********************/
		
// Comment Layout
function wp_bootstrap_comments($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?>>
		<article id="comment-<?php comment_ID(); ?>" class="clearfix">
			<div class="comment-author vcard clearfix">
				<div class="avatar col-sm-3">
					<?php echo get_avatar( $comment, $size='75' ); ?>
				</div>
				<div class="col-sm-9 comment-text">
					<?php printf('<h4>%s</h4>', get_comment_author_link()) ?>
					<?php edit_comment_link(__('Edit','wpbootstrap'),'<span class="edit-comment btn btn-sm btn-info"><i class="glyphicon-white glyphicon-pencil"></i>','</span>') ?>
                    
                    <?php if ($comment->comment_approved == '0') : ?>
       					<div class="alert-message success">
          				<p><?php _e('Your comment is awaiting moderation.','wpbootstrap') ?></p>
          				</div>
					<?php endif; ?>
                    
                    <?php comment_text() ?>
                    
                    <time datetime="<?php echo comment_time('Y-m-j'); ?>"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php comment_time('F jS, Y'); ?> </a></time>
                    
					<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                </div>
			</div>
		</article>
    <!-- </li> is added by wordpress automatically -->
<?php
} // don't remove this bracket!

// Display trackbacks/pings callback function
function list_pings($comment, $args, $depth) {
       $GLOBALS['comment'] = $comment;
?>
        <li id="comment-<?php comment_ID(); ?>"><i class="icon icon-share-alt"></i>&nbsp;<?php comment_author_link(); ?>
<?php 

}

/************* SEARCH FORM LAYOUT *****************/

/****************** password protected post form *****/

add_filter( 'the_password_form', 'wp_bootstrap_custom_password_form' );

function wp_bootstrap_custom_password_form() {
	global $post;
	$label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
	$o = '<div class="clearfix"><form class="protected-post-form" action="' . get_option('siteurl') . '/wp-login.php?action=postpass" method="post">
	' . '<p>' . __( "This post is password protected. To view it please enter your password below:" ,'wpbootstrap') . '</p>' . '
	<label for="' . $label . '">' . __( "Password:" ,'wpbootstrap') . ' </label><div class="input-append"><input name="post_password" id="' . $label . '" type="password" size="20" /><input type="submit" name="Submit" class="btn btn-primary" value="' . esc_attr__( "Submit",'wpbootstrap' ) . '" /></div>
	</form></div>
	';
	return $o;
}

/*********** update standard wp tag cloud widget so it looks better ************/

add_filter( 'widget_tag_cloud_args', 'wp_bootstrap_my_widget_tag_cloud_args' );

function wp_bootstrap_my_widget_tag_cloud_args( $args ) {
	$args['number'] = 20; // show less tags
	$args['largest'] = 9.75; // make largest and smallest the same - i don't like the varying font-size look
	$args['smallest'] = 9.75;
	$args['unit'] = 'px';
	return $args;
}

// filter tag clould output so that it can be styled by CSS
function wp_bootstrap_add_tag_class( $taglinks ) {
    $tags = explode('</a>', $taglinks);
    $regex = "#(.*tag-link[-])(.*)(' title.*)#e";

    foreach( $tags as $tag ) {
    	$tagn[] = preg_replace($regex, "('$1$2 label tag-'.get_tag($2)->slug.'$3')", $tag );
    }

    $taglinks = implode('</a>', $tagn);

    return $taglinks;
}

add_action( 'wp_tag_cloud', 'wp_bootstrap_add_tag_class' );

add_filter( 'wp_tag_cloud','wp_bootstrap_wp_tag_cloud_filter', 10, 2) ;

function wp_bootstrap_wp_tag_cloud_filter( $return, $args )
{
  return '<div id="tag-cloud">' . $return . '</div>';
}

// Enable shortcodes in widgets
add_filter( 'widget_text', 'do_shortcode' );

// Disable jump in 'read more' link
function wp_bootstrap_remove_more_jump_link( $link ) {
	$offset = strpos($link, '#more-');
	if ( $offset ) {
		$end = strpos( $link, '"',$offset );
	}
	if ( $end ) {
		$link = substr_replace( $link, '', $offset, $end-$offset );
	}
	return $link;
}
add_filter( 'the_content_more_link', 'wp_bootstrap_remove_more_jump_link' );

// Remove height/width attributes on images so they can be responsive
add_filter( 'post_thumbnail_html', 'wp_bootstrap_remove_thumbnail_dimensions', 10 );
add_filter( 'image_send_to_editor', 'wp_bootstrap_remove_thumbnail_dimensions', 10 );

function wp_bootstrap_remove_thumbnail_dimensions( $html ) {
    $html = preg_replace( '/(width|height)=\"\d*\"\s/', "", $html );
    return $html;
}

// Add the Meta Box to the homepage template
function wp_bootstrap_add_homepage_meta_box() {  
	global $post;

	// Only add homepage meta box if template being used is the homepage template
	// $post_id = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post_ID']) ? $_POST['post_ID'] : "");
	$post_id = $post->ID;
	$template_file = get_post_meta($post_id,'_wp_page_template',TRUE);

	if ( $template_file == 'page-homepage.php' ){
	    add_meta_box(  
	        'homepage_meta_box', // $id  
	        'Optional Homepage Tagline', // $title  
	        'wp_bootstrap_show_homepage_meta_box', // $callback  
	        'page', // $page  
	        'normal', // $context  
	        'high'); // $priority  
    }
}

add_action( 'add_meta_boxes', 'wp_bootstrap_add_homepage_meta_box' );

// Field Array  
$prefix = 'custom_';  
$custom_meta_fields = array(  
    array(  
        'label'=> 'Homepage tagline area',  
        'desc'  => 'Displayed underneath page title. Only used on homepage template. HTML can be used.',  
        'id'    => 'tagline',  
        'type'  => 'textarea' 
    )  
);  

// The Homepage Meta Box Callback  
function wp_bootstrap_show_homepage_meta_box() {  
  global $custom_meta_fields, $post;

  // Use nonce for verification
  wp_nonce_field( basename( __FILE__ ), 'wpbs_nonce' );
    
  // Begin the field table and loop
  echo '<table class="form-table">';

  foreach ( $custom_meta_fields as $field ) {
      // get value of this field if it exists for this post  
      $meta = get_post_meta($post->ID, $field['id'], true);  
      // begin a table row with  
      echo '<tr> 
              <th><label for="'.$field['id'].'">'.$field['label'].'</label></th> 
              <td>';  
              switch($field['type']) {  
                  // text  
                  case 'text':  
                      echo '<input type="text" name="'.$field['id'].'" id="'.$field['id'].'" value="'.$meta.'" size="60" /> 
                          <br /><span class="description">'.$field['desc'].'</span>';  
                  break;
                  
                  // textarea  
                  case 'textarea':  
                      echo '<textarea name="'.$field['id'].'" id="'.$field['id'].'" cols="80" rows="4">'.$meta.'</textarea> 
                          <br /><span class="description">'.$field['desc'].'</span>';  
                  break;  
              } //end switch  
      echo '</td></tr>';  
  } // end foreach  
  echo '</table>'; // end table  
}  

// Save the Data  
function wp_bootstrap_save_homepage_meta( $post_id ) {  

    global $custom_meta_fields;  
  
    // verify nonce  
    if ( !isset( $_POST['wpbs_nonce'] ) || !wp_verify_nonce($_POST['wpbs_nonce'], basename(__FILE__)) )  
        return $post_id;

    // check autosave
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE )
        return $post_id;

    // check permissions
    if ( 'page' == $_POST['post_type'] ) {
        if ( !current_user_can( 'edit_page', $post_id ) )
            return $post_id;
        } elseif ( !current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
    }
  
    // loop through fields and save the data  
    foreach ( $custom_meta_fields as $field ) {
        $old = get_post_meta( $post_id, $field['id'], true );
        $new = $_POST[$field['id']];

        if ($new && $new != $old) {
            update_post_meta( $post_id, $field['id'], $new );
        } elseif ( '' == $new && $old ) {
            delete_post_meta( $post_id, $field['id'], $old );
        }
    } // end foreach
}
add_action( 'save_post', 'wp_bootstrap_save_homepage_meta' );

// Add thumbnail class to thumbnail links
function wp_bootstrap_add_class_attachment_link( $html ) {
    $postid = get_the_ID();
    $html = str_replace( '<a','<a class="thumbnail"',$html );
    return $html;
}
add_filter( 'wp_get_attachment_link', 'wp_bootstrap_add_class_attachment_link', 10, 1 );

// Add lead class to first paragraph
function wp_bootstrap_first_paragraph( $content ){
    global $post;

    // if we're on the homepage, don't add the lead class to the first paragraph of text
    if( is_page_template( 'page-homepage.php' ) )
        return $content;
    else
        return preg_replace('/<p([^>]+)?>/', '<p$1 class="lead">', $content, 1);
}
add_filter( 'the_content', 'wp_bootstrap_first_paragraph' );

// Menu output mods
class Bootstrap_walker extends Walker_Nav_Menu{

  function start_el(&$output, $object, $depth = 0, $args = Array(), $current_object_id = 0){

	 global $wp_query;
	 $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
	
	 $class_names = $value = '';
	
		// If the item has children, add the dropdown class for bootstrap
		if ( $args->has_children ) {
			$class_names = "dropdown ";
		}
	
		$classes = empty( $object->classes ) ? array() : (array) $object->classes;
		
		$class_names .= join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $object ) );
		$class_names = ' class="'. esc_attr( $class_names ) . '"';
       
   	$output .= $indent . '<li id="menu-item-'. $object->ID . '"' . $value . $class_names .'>';

   	$attributes  = ! empty( $object->attr_title ) ? ' title="'  . esc_attr( $object->attr_title ) .'"' : '';
   	$attributes .= ! empty( $object->target )     ? ' target="' . esc_attr( $object->target     ) .'"' : '';
   	$attributes .= ! empty( $object->xfn )        ? ' rel="'    . esc_attr( $object->xfn        ) .'"' : '';
   	$attributes .= ! empty( $object->url )        ? ' href="'   . esc_attr( $object->url        ) .'"' : '';

   	// if the item has children add these two attributes to the anchor tag
   	if ( $args->has_children ) {
		  $attributes .= ' class="dropdown-toggle" data-toggle="dropdown"';
    }

    $item_output = $args->before;
    $item_output .= '<a'. $attributes .'>';
    $item_output .= $args->link_before .apply_filters( 'the_title', $object->title, $object->ID );
    $item_output .= $args->link_after;

    // if the item has children add the caret just before closing the anchor tag
    if ( $args->has_children ) {
    	$item_output .= '<b class="caret"></b></a>';
    }
    else {
    	$item_output .= '</a>';
    }

    $item_output .= $args->after;

    $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $object, $depth, $args );
  } // end start_el function
        
  function start_lvl(&$output, $depth = 0, $args = Array()) {
    $indent = str_repeat("\t", $depth);
    $output .= "\n$indent<ul class=\"dropdown-menu\">\n";
  }
      
	function display_element( $element, &$children_elements, $max_depth, $depth=0, $args, &$output ){
    $id_field = $this->db_fields['id'];
    if ( is_object( $args[0] ) ) {
        $args[0]->has_children = ! empty( $children_elements[$element->$id_field] );
    }
    return parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
  }        
}

add_editor_style('editor-style.css');

function wp_bootstrap_add_active_class($classes, $item) {
	if( $item->menu_item_parent == 0 && in_array('current-menu-item', $classes) ) {
    $classes[] = "active";
	}
  
  return $classes;
}

// Add Twitter Bootstrap's standard 'active' class name to the active nav link item
add_filter('nav_menu_css_class', 'wp_bootstrap_add_active_class', 10, 2 );

// enqueue styles
if( !function_exists("wp_bootstrap_theme_styles") ) {  
    function wp_bootstrap_theme_styles() { 
        // This is the compiled css file from LESS - this means you compile the LESS file locally and put it in the appropriate directory if you want to make any changes to the master bootstrap.css.
        wp_register_style( 'wpbs', get_template_directory_uri() . '/library/dist/css/styles.f6413c85.min.css', array(), '1.0', 'all' );
        wp_enqueue_style( 'wpbs' );

        // For child themes
        wp_register_style( 'wpbs-style', get_stylesheet_directory_uri() . '/style.css', array(), '1.0', 'all' );
        wp_enqueue_style( 'wpbs-style' );
    }
}
add_action( 'wp_enqueue_scripts', 'wp_bootstrap_theme_styles' );

// enqueue javascript
if( !function_exists( "wp_bootstrap_theme_js" ) ) {  
  function wp_bootstrap_theme_js(){

    if ( !is_admin() ){
      if ( is_singular() AND comments_open() AND ( get_option( 'thread_comments' ) == 1) ) 
        wp_enqueue_script( 'comment-reply' );
    }

    // This is the full Bootstrap js distribution file. If you only use a few components that require the js files consider loading them individually instead
    wp_register_script( 'bootstrap', 
      get_template_directory_uri() . '/bower_components/bootstrap/dist/js/bootstrap.js', 
      array('jquery'), 
      '1.2' );

    wp_register_script( 'wpbs-js', 
      get_template_directory_uri() . '/library/dist/js/scripts.d1e3d952.min.js',
      array('bootstrap'), 
      '1.2' );
  
    wp_register_script( 'modernizr', 
      get_template_directory_uri() . '/bower_components/modernizer/modernizr.js', 
      array('jquery'), 
      '1.2' );
  
    wp_enqueue_script( 'bootstrap' );
    wp_enqueue_script( 'wpbs-js' );
    wp_enqueue_script( 'modernizr' );
    
  }
}
add_action( 'wp_enqueue_scripts', 'wp_bootstrap_theme_js' );

// Get <head> <title> to behave like other themes
function wp_bootstrap_wp_title( $title, $sep ) {
  global $paged, $page;

  if ( is_feed() ) {
    return $title;
  }

  // Add the site name.
  $title .= get_bloginfo( 'name' );

  // Add the site description for the home/front page.
  $site_description = get_bloginfo( 'description', 'display' );
  if ( $site_description && ( is_home() || is_front_page() ) ) {
    $title = "$title $sep $site_description";
  }

  // Add a page number if necessary.
  if ( $paged >= 2 || $page >= 2 ) {
    $title = "$title $sep " . sprintf( __( 'Page %s', 'wpbootstrap' ), max( $paged, $page ) );
  }

  return $title;
}
add_filter( 'wp_title', 'wp_bootstrap_wp_title', 10, 2 );

// Related Posts Function (call using wp_bootstrap_related_posts(); )
function wp_bootstrap_related_posts() {
  echo '<ul id="bones-related-posts">';
  global $post;
  $tags = wp_get_post_tags($post->ID);
  if($tags) {
    foreach($tags as $tag) { $tag_arr .= $tag->slug . ','; }
        $args = array(
          'tag' => $tag_arr,
          'numberposts' => 5, /* you can change this to show more */
          'post__not_in' => array($post->ID)
      );
        $related_posts = get_posts($args);
        if($related_posts) {
          foreach ($related_posts as $post) : setup_postdata($post); ?>
              <li class="related_post"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
          <?php endforeach; } 
      else { ?>
            <li class="no_related_post">No Related Posts Yet!</li>
    <?php }
  }
  wp_reset_query();
  echo '</ul>';
}

// Numeric Page Navi (built into the theme by default)
function wp_bootstrap_page_navi($before = '', $after = '') {
  global $wpdb, $wp_query;
  $request = $wp_query->request;
  $posts_per_page = intval(get_query_var('posts_per_page'));
  $paged = intval(get_query_var('paged'));
  $numposts = $wp_query->found_posts;
  $max_page = $wp_query->max_num_pages;
  if ( $numposts <= $posts_per_page ) { return; }
  if(empty($paged) || $paged == 0) {
    $paged = 1;
  }
  $pages_to_show = 7;
  $pages_to_show_minus_1 = $pages_to_show-1;
  $half_page_start = floor($pages_to_show_minus_1/2);
  $half_page_end = ceil($pages_to_show_minus_1/2);
  $start_page = $paged - $half_page_start;
  if($start_page <= 0) {
    $start_page = 1;
  }
  $end_page = $paged + $half_page_end;
  if(($end_page - $start_page) != $pages_to_show_minus_1) {
    $end_page = $start_page + $pages_to_show_minus_1;
  }
  if($end_page > $max_page) {
    $start_page = $max_page - $pages_to_show_minus_1;
    $end_page = $max_page;
  }
  if($start_page <= 0) {
    $start_page = 1;
  }
    
  echo $before.'<ul class="pagination">'."";
  if ($paged > 1) {
    $first_page_text = "&laquo";
    echo '<li class="prev"><a href="'.get_pagenum_link().'" title="' . __('First','wpbootstrap') . '">'.$first_page_text.'</a></li>';
  }
    
  $prevposts = get_previous_posts_link( __('&larr; Previous','wpbootstrap') );
  if($prevposts) { echo '<li>' . $prevposts  . '</li>'; }
  else { echo '<li class="disabled"><a href="#">' . __('&larr; Previous','wpbootstrap') . '</a></li>'; }
  
  for($i = $start_page; $i  <= $end_page; $i++) {
    if($i == $paged) {
      echo '<li class="active"><a href="#">'.$i.'</a></li>';
    } else {
      echo '<li><a href="'.get_pagenum_link($i).'">'.$i.'</a></li>';
    }
  }
  echo '<li class="">';
  next_posts_link( __('Next &rarr;','wpbootstrap') );
  echo '</li>';
  if ($end_page < $max_page) {
    $last_page_text = "&raquo;";
    echo '<li class="next"><a href="'.get_pagenum_link($max_page).'" title="' . __('Last','wpbootstrap') . '">'.$last_page_text.'</a></li>';
  }
  echo '</ul>'.$after."";
}

// Remove <p> tags from around images
function wp_bootstrap_filter_ptags_on_images( $content ){
  return preg_replace( '/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content );
}
add_filter( 'the_content', 'wp_bootstrap_filter_ptags_on_images' );



// Register Custom Post Type
function listing_post_type() {

	$labels = array(
		'name'                => __( 'Listing', 'Post Type General Name', 'text_domain' ),
		'singular_name'       => __( 'Listing', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'           => __( 'Listing', 'text_domain' ),
		'parent_item_colon'   => __( 'Parent listing:', 'text_domain' ),
		'all_items'           => __( 'All listing', 'text_domain' ),
		'view_item'           => __( 'View listing', 'text_domain' ),
		'add_new_item'        => __( 'Add New listing', 'text_domain' ),
		'add_new'             => __( 'New listing', 'text_domain' ),
		'edit_item'           => __( 'Edit listing', 'text_domain' ),
		'update_item'         => __( 'Update listing', 'text_domain' ),
		'search_items'        => __( 'Search listing', 'text_domain' ),
		'not_found'           => __( 'No listing found', 'text_domain' ),
		'not_found_in_trash'  => __( 'No listing found in Trash', 'text_domain' ),
	);
	$args = array(
		'label'               => __( 'listing', 'text_domain' ),
		'description'         => __( 'Listing information pages', 'text_domain' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor' , 'thumbnail' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
	);
	register_post_type( 'listing', $args );

}


// Hook into the 'init' action
add_action( 'init', 'listing_post_type', 0 );



add_image_size( 'admin-list-thumb', 80, 80, true); //admin thumbnail


//----------------------------------------------
//----------register and label gallery post type
//----------------------------------------------
$gallery_labels = array(
    'name' => _x('Home Top Slider', 'post type general name'),
    'singular_name' => _x('Slider', 'post type singular name'),
    'add_new' => _x('Add Slider', 'gallery'),
    'add_new_item' => __("Add New Slider"),
    'edit_item' => __("Edit Slider"),
    'new_item' => __("New Slider"),
    'view_item' => __("View Slider"),
    'search_items' => __("Search Slider"),
    'not_found' =>  __('No Slider found'),
    'not_found_in_trash' => __('No Slider found in Trash'), 
    'parent_item_colon' => ''
        
);
$gallery_args = array(
    'labels' => $gallery_labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'query_var' => true,
    'rewrite' => true,
    'hierarchical' => false,
    'menu_position' => null,
    'capability_type' => 'post',
    'supports' => array('title',  'thumbnail'),
    'menu_icon' => get_bloginfo('template_directory') . '/images/photo-album.png' //16x16 png if you want an icon
); 
register_post_type('gallery', $gallery_args);

add_action( 'init', 'jss_create_gallery_taxonomies', 0);
 
function jss_create_gallery_taxonomies(){
     
}

add_action('manage_posts_custom_column', 'jss_custom_columns');
add_filter('manage_edit-gallery_columns', 'jss_add_new_gallery_columns');
 
function jss_add_new_gallery_columns( $columns ){
    $columns = array(
        'cb'                =>        '<input type="checkbox">',
        'title'             =>        'Photo Title',
        'author'            =>        'Author',
        'date'              =>        'Date'
        
    );
    return $columns;
}
 
function jss_custom_columns( $column ){
    global $post;
    
    switch ($column) {
        case 'jss_post_thumb' : echo the_post_thumbnail('admin-list-thumb'); break;
        case 'description' : the_excerpt(); break;
    }
}
 

 
// Add the column
function jss_add_post_thumbnail_column($cols){
    $cols['jss_post_thumb'] = __('Thumbnail');
    return $cols;
}
 
function jss_display_post_thumbnail_column($col, $id){
  switch($col){
    case 'jss_post_thumb':
      if( function_exists('the_post_thumbnail') )
        echo the_post_thumbnail( 'admin-list-thumb' );
      else
        echo 'Not supported in this theme';
      break;
  }
}

// ******************************************************************

function homepageslider_func() { ?>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/rs-plugin/js/jquery.themepunch.tools.min.js"></script>   
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/extralayers.css" media="screen" />	
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/rs-plugin/css/settings.css" media="screen" />
			
<style>
.tp-rightarrow { display:none; }
.tp-leftarrow { display:none; }
.tp-banner-container .tp-rightarrow, .tp-banner-container .tp-leftarrow { display:block!important; }
</style>	
	
<?php global $query_string;
query_posts('order=ASC&showposts=10&post_type=gallery'); ?>
<div class="tp-banner-container">
<div class="tp-banner" >


<ul>

<?php if (have_posts()) :  

while ( have_posts() ) : the_post();
	global $post;
	$videotitle = get_post_meta($post->ID,'videomp4',TRUE);  
	$url = $videotitle;
	parse_str( parse_url( $url, PHP_URL_QUERY ), $url_vars );
	$url_vars['v'];
?> 
<?php  if (preg_match("/^.*\.(jpg|jpeg|png|gif)$/i", get_post_meta($post->ID,'videomp4',TRUE)) == 1) { ?>

<li data-transition="fade" data-slotamount="1" data-masterspeed="1500" data-thumb="<?php echo $repeat_group[$i]['image']; ?>" data-delay="13000"  data-saveperformance="off"  data-title="Next">
	<img src="<?php echo $videotitle; ?>"  alt="kenburns1"  data-bgposition="left center" data-kenburns="on" data-duration="14000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="130" data-bgpositionend="right center">
	 <div class="tp-caption black_thin_whitebg_30 customin ltl tp-resizeme" data-x="730" data-y="600"  data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;" data-speed="1500" data-start="2100" data-easing="Power4.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.1" data-endspeed="1000" data-endeasing="Power4.easeIn" style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;"><?php echo $videotitle = get_post_meta($post->ID,'video_title',TRUE); ?></div>
 
</li>

<?php } else { ?>	

<li data-transition="slidehorizontal" data-slotamount="1" data-masterspeed="1000" data-thumb=""  data-fstransition="fade" data-fsmasterspeed="1000" data-fsslotamount="7" data-saveperformance="off"  data-title="<?php echo $videotitle = get_post_meta($post->ID,'video_title',TRUE); ?>">
<?php   if (preg_match("/^(http(s)?:\/\/|www\.).*(\.mp4|\.mkv)$/", get_post_meta($post->ID,'videomp4',TRUE)) == 1) { ?>	
	<div class="tp-caption tp-fade fadeout fullscreenvideo tp-videolayer"	data-x="0"	data-y="0"	data-speed="1000"	data-start="1100"	data-easing="Power4.easeOut"	data-elementdelay="0.01"	data-endelementdelay="0.1"	data-endspeed="1500"	data-endeasing="Power4.easeIn"	data-autoplay="true"	data-autoplayonlyfirsttime="false"	data-nextslideatend="true"	data-videowidth="100%"
			data-videoheight="100%"
			data-videoattributes=""
			data-videopreload="meta"
			data-videoloop="none"
			data-videomp4="<?php echo get_post_meta($post->ID,'videomp4',TRUE);  ?>"
			data-videoogv=""
			data-videocontrols="none"
			data-forcecover="1"
			data-forcerewind="on"
			data-aspectratio="16:9"
			data-volume="mute"
			data-videoposter="" >
	</div>	
<?php } if (preg_match("/((http\:\/\/){0,}(www\.){0,}(youtube\.com){1} || (youtu\.be){1}(\/watch\?v\=[^\s]){1})/", $videotitle) == 1) { ?>
	<div class="tp-caption tp-fade fadeout fullscreenvideo tp-videolayer" data-x="0" data-y="0"	data-speed="1000" data-start="1100" data-easing="Power4.easeOut" data-elementdelay="0.01"	data-endelementdelay="0.1"  data-endspeed="1500"  data-endeasing="Power4.easeIn"  data-autoplay="true" 	data-autoplayonlyfirsttime="false"  data-nextslideatend="true"  data-videowidth="100%" 	data-videoheight="100%"  data-ytid="<?php echo $url_vars['v']; ?>"  data-videoattributes=""  data-videopreload="meta" 	data-videocontrols="" 	data-forcecover="1"  data-forcerewind="on"  data-aspectratio="16:9" 	data-volume="mute"  data-videoposter="" > </div>			
<?php } if (preg_match("/https?:\/\/(?:www\.)?vimeo\.com\/\d{8}/", $videotitle) == 1) {	?>

	<div class="tp-caption tp-fade fadeout fullscreenvideo tp-videolayer"
			data-x="0"
			data-y="0"
			data-speed="1000"
			data-start="1100"
			data-easing="Power4.easeOut"
			data-elementdelay="0.01"
			data-endelementdelay="0.1"
			data-endspeed="1500"
			data-endeasing="Power4.easeIn"
			data-autoplay="true"
			data-autoplayonlyfirsttime="false"
			data-nextslideatend="true"
			data-videowidth="100%"
			data-videoheight="100%"	
			data-vimeoid="<?php echo (int) substr(parse_url($videotitle, PHP_URL_PATH), 1); ?>"
			data-videoattributes=""
			data-videopreload="meta"			
			data-videoogv=""
			data-videocontrols=""
			data-forcecover="1"
			data-forcerewind="on"
			data-aspectratio="16:9"
			data-volume="mute"
			data-videoposter="" >
	</div>

	<?php } 
}
?>
		
		
 <div class="tp-caption black_thin_whitebg_30 customin ltl tp-resizeme" data-x="730" data-y="600"  data-customin="x:0;y:0;z:0;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;" data-speed="1500" data-start="2100" data-easing="Power4.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.1" data-endspeed="1000" data-endeasing="Power4.easeIn" style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;"><?php echo $videotitle = get_post_meta($post->ID,'video_title',TRUE); ?></div>
 
 </li>


<?php endwhile;  else : ?>
<?php endif;  ?>



</ul>	


</div>

<?php wp_reset_query();	 ?>
<div class="tp-bannertimer"></div>	
</div>
</div>	
		<script type="text/javascript">
				jQuery(document).ready(function() {
					jQuery('.tp-banner').show().revolution(
					{
						dottedOverlay:"none",
						delay:9000,
						startwidth:1170,
						startheight:700,
						hideThumbs:200,

						thumbWidth:100,
						thumbHeight:50,
						thumbAmount:3,

						navigationType:"none",
						navigationArrows:"solo",
						navigationStyle:"preview4",

						touchenabled:"on",
						onHoverStop:"on",

						swipe_velocity: 0.7,
						swipe_min_touches: 1,
						swipe_max_touches: 1,
						drag_block_vertical: false,


						keyboardNavigation:"on",

						navigationHAlign:"center",
						navigationVAlign:"bottom",
						navigationHOffset:0,
						navigationVOffset:20,

						soloArrowLeftHalign:"left",
						soloArrowLeftValign:"center",
						soloArrowLeftHOffset:20,
						soloArrowLeftVOffset:0,

						soloArrowRightHalign:"right",
						soloArrowRightValign:"center",
						soloArrowRightHOffset:20,
						soloArrowRightVOffset:0,

						shadow:0,
						fullWidth:"off",
						fullScreen:"off",

						spinner:"spinner0",

						stopLoop:"off",
						stopAfterLoops:-1,
						stopAtSlide:-1,

						shuffle:"off",


						forceFullWidth:"off",
						fullScreenAlignForce:"off",
						minFullScreenHeight:"400",

						hideThumbsOnMobile:"off",
						hideNavDelayOnMobile:1500,
						hideBulletsOnMobile:"off",
						hideArrowsOnMobile:"off",
						hideThumbsUnderResolution:0,

						hideSliderAtLimit:0,
						hideCaptionAtLimit:0,
						hideAllCaptionAtLilmit:0,
						startWithSlide:0
					});




				});	//ready

			</script>
<?php	
}

add_shortcode( 'homepageslider', 'homepageslider_func' );


function postimage_func() {
	global $post;
 	$repeat_group = get_post_meta( $post->ID, 'repeat_group', true );
    $counter =  count($repeat_group)
	
?>

<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/rs-plugin/js/jquery.themepunch.tools.min.js"></script>   
	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
<!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/extralayers.css" media="screen" />	
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/rs-plugin/css/settings.css" media="screen" />
	
		<script type="text/javascript">
				jQuery(document).ready(function() {
					jQuery('.tp-banner').show().revolution(
					{
						dottedOverlay:"none",
						delay:9000,
						startwidth:1170,
						startheight:700,
						hideThumbs:200,

						thumbWidth:100,
						thumbHeight:50,
						thumbAmount:3,

						navigationType:"none",
						navigationArrows:"solo",
						navigationStyle:"preview4",

						touchenabled:"on",
						onHoverStop:"on",

						swipe_velocity: 0.7,
						swipe_min_touches: 1,
						swipe_max_touches: 1,
						drag_block_vertical: false,


						keyboardNavigation:"on",

						navigationHAlign:"center",
						navigationVAlign:"bottom",
						navigationHOffset:0,
						navigationVOffset:20,

						soloArrowLeftHalign:"left",
						soloArrowLeftValign:"center",
						soloArrowLeftHOffset:20,
						soloArrowLeftVOffset:0,

						soloArrowRightHalign:"right",
						soloArrowRightValign:"center",
						soloArrowRightHOffset:20,
						soloArrowRightVOffset:0,

						shadow:0,
						fullWidth:"off",
						fullScreen:"off",

						spinner:"spinner0",

						stopLoop:"off",
						stopAfterLoops:-1,
						stopAtSlide:-1,

						shuffle:"off",


						forceFullWidth:"off",
						fullScreenAlignForce:"off",
						minFullScreenHeight:"400",

						hideThumbsOnMobile:"off",
						hideNavDelayOnMobile:1500,
						hideBulletsOnMobile:"off",
						hideArrowsOnMobile:"off",
						hideThumbsUnderResolution:0,

						hideSliderAtLimit:0,
						hideCaptionAtLimit:0,
						hideAllCaptionAtLilmit:0,
						startWithSlide:0
					});




				});	//ready

			</script>

<div class="tp-banner" >
<ul>	

<?php
if($repeat_group != null) {
 for($i = 0; $i < $counter; $i++) { ?>
	<li data-transition="slidehorizontal" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo $repeat_group[$i]['image']; ?>"  data-fstransition="fade" data-fsmasterspeed="1000" data-fsslotamount="7" data-saveperformance="off"  data-title="<?php echo $repeat_group[$i]['title']; ?>">
		<img src="<?php echo $repeat_group[$i]['image']; ?>"  alt="kenburns1"  data-bgposition="left center" data-kenburns="on" data-duration="14000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="130" data-bgpositionend="right center">
		<div class="tp-caption reddishbg_heavy_70 lfb fadeout tp-resizeme" data-x="center" data-hoffset="0" data-y="center" data-voffset="0" data-speed="600" data-start="500" data-easing="Power4.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.05" data-endelementdelay="0.1" data-endspeed="1000" data-endeasing="Power1.easeOut" style="z-index: 2; max-width: auto; max-height: auto;  white-space: nowrap;"><?php echo $repeat_group[$i]['title']; ?></div>
		<div class="tp-caption  tp-fade fadeout tp-resizeme" data-x="center" data-hoffset="0" data-y="center" data-voffset="0" data-speed="600" data-start="800" data-easing="Power4.easeInOut" data-splitin="none" data-splitout="none" data-elementdelay="0.1" data-endelementdelay="0.1" data-endspeed="1000" data-endeasing="Power1.easeOut" style="z-index: 3; max-width: auto; max-height: auto; white-space: nowrap;">
		</div>
	</li>
<?php  } 

} else {	?>
	<li data-transition="fade" data-slotamount="1" data-masterspeed="1500" data-thumb="Pls Add Images" data-delay="13000"  data-saveperformance="off"  data-title="Next">
	<img src="<?php echo get_template_directory_uri(); ?>/images/default.jpg"  alt="kenburns1"  data-bgposition="left center" data-kenburns="on" data-duration="14000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="130" data-bgpositionend="right center">
	</li>

<?php } ?>
</ul>
<div class="tp-bannertimer"></div>	
</div>
<?php
}

add_shortcode( 'postimage', 'postimage_func' );


/*
 * Loads the Options Panel
 *
 * If you're loading from a child theme use stylesheet_directory
 * instead of template_directory
 */

define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/' );
require_once dirname( __FILE__ ) . '/inc/options-framework.php';

// Loads options.php from child or parent theme
$optionsfile = locate_template( 'options.php' );
load_template( $optionsfile );

/*
 * This is an example of how to add custom scripts to the options panel.
 * This one shows/hides the an option when a checkbox is clicked.
 *
 * You can delete it if you not using that option
 */
add_action( 'optionsframework_custom_scripts', 'optionsframework_custom_scripts' );

function optionsframework_custom_scripts() { ?>

<script type="text/javascript">
jQuery(document).ready(function() {

	jQuery('#example_showhidden').click(function() {
  		jQuery('#section-example_text_hidden').fadeToggle(400);
	});

	if (jQuery('#example_showhidden:checked').val() !== undefined) {
		jQuery('#section-example_text_hidden').show();
	}

});
</script>

<?php
}


add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );

function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'listing_';
	
	/**
	 * Repeatable Field Groups
	 */
	$meta_boxes['field_group'] = array(
		'id'         => 'field_group',
		'title'      => __( 'Top header slider', 'cmb' ),
		'pages'      => array( 'listing', ),
		'fields'     => array(
			array(
				'id'          => 'repeat_group',
				'type'        => 'group',
				'description' => __( 'Generates slider on top', 'cmb' ),
				'options'     => array(
					'group_title'   => __( 'Header Slider {#}', 'cmb' ), // {#} gets replaced by row number
					'add_button'    => __( 'Add Another Slider', 'cmb' ),
					'remove_button' => __( 'Remove Slider', 'cmb' ),
					'sortable'      => true, // beta
				),
				// Fields array works the same, except id's only need to be unique for this group. Prefix is not needed.
				'fields'      => array(
					array(
						'name' => 'Title',
						'id'   => 'title',
						'type' => 'text',
						// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
					),
					array(
						'name' => __( 'Image', 'cmb' ),
						'desc' => __( 'Upload an image or enter a URL.', 'cmb' ),
						'id'   => 'image',
						'type' => 'file',
					),
				),
			),
		),
	);

	
	$meta_boxes['slider'] = array(
		'id'         => 'slider',
		'title'      => __( 'Top header slider', 'cmb' ),
		'pages'      => array( 'gallery', ),
		'fields'     => array(
			array(
				'name'       => __( 'Title', 'cmb' ),
				'desc'       => __( 'Video TItle', 'cmb' ),
				'id'         => 'video_title',
				'type'       => 'text',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			array(
				'name' => __( 'Video / Images', 'cmb' ),
				'desc' => __( 'Upload an video mp4, jpeg, png or enter a URL for vimeo or youtube.', 'cmb' ),
				'id'   => 'videomp4',
				'type' => 'file',
			),
		),
	);

	

	$meta_boxes['listing_metabox'] = array(
		'id'         => 'listing_metabox',
		'title'      => __( 'Listing Metabox', 'cmb' ),
		'pages'      => array( 'listing', ), // Post type
		'context'    => 'normal',
		'priority'   => 'high',
		'show_names' => true, // Show field names on the left
		// 'cmb_styles' => true, // Enqueue the CMB stylesheet on the frontend
		'fields'     => array(
			
			

			array(
				'name'       => __( 'Address', 'cmb' ),
				'desc'       => __( 'field description (optional)', 'cmb' ),
				'id'         => 'address',
				'type'       => 'text',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			
			array(
				'name'    => __( 'Home Type', 'cmb' ),
				'desc'    => __( 'Select in a home type', 'cmb' ),
				'id'      => 'home_type',
				'type'    => 'radio_inline',
				'options' => array(
					'House' => __( 'House', 'cmb' ),
					'Apartment'   => __( 'Apartment', 'cmb' ),
					'Bed & Breakfast'     => __( 'Bed & Breakfast', 'cmb' ),
					'Loft'     => __( 'Loft', 'cmb' ),
					'Cabin'     => __( 'Cabin', 'cmb' ),
					'Villa'     => __( 'Villa', 'cmb' ),
					'Dorm'     => __( 'Dorm', 'cmb' ),
				),
			),
			
			array(
				'name'       => __( 'Guest', 'cmb' ),
				'desc'       => __( 'Enter no. of guest', 'cmb' ),
				'id'         => 'guest_text',
				'type'       => 'text',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			
			array(
				'name'       => __( 'Bedrooms', 'cmb' ),
				'desc'       => __( 'Enter no. of bedrooms', 'cmb' ),
				'id'         => 'bedroom_text',
				'type'       => 'text',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			
			array(
				'name'       => __( 'Bed', 'cmb' ),
				'desc'       => __( 'Enter no. of bed', 'cmb' ),
				'id'         => 'bed_text',
				'type'       => 'text',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			
			array(
				'name'    => __( 'Amenities', 'cmb' ),
				'desc'    => __( 'Select in a Amenities', 'cmb' ),
				'id'      => 'amenities_multicheckbox',
				'type'    => 'multicheck',
				'options' => array(
					'Kitchen' => __( 'Kitchen', 'cmb' ),
					'Internet' => __( 'Internet', 'cmb' ),
					'Essentials' => __( 'Essentials', 'cmb' ),
					'Shampoo' => __( 'Shampoo', 'cmb' ),
					'Heating' => __( 'Heating', 'cmb' ),
					'Air Conditioning' => __( 'Air Conditioning', 'cmb' ),
					'Washer' => __( 'Washer', 'cmb' ),
					'Dryer' => __( 'Dryer', 'cmb' ),
					'Free Parking on Premises' => __( 'Free Parking on Premises', 'cmb' ),
					'Wireless Internet' => __( 'Wireless Internet', 'cmb' ),
					'Cable TV' => __( 'Cable TV', 'cmb' ),
					'Breakfast' => __( 'Breakfast', 'cmb' ),
					'Pets Allowed' => __( 'Pets Allowed', 'cmb' ),
					'Family/Kid Friendly' => __( 'Family/Kid Friendly', 'cmb' ),
					'Suitable for Events' => __( 'Suitable for Events', 'cmb' ),
					'Smoking Allowed' => __( 'Smoking Allowed', 'cmb' ),
					'Wheelchair Accessible' => __( 'Wheelchair Accessible', 'cmb' ),
					'Elevator in Building' => __( 'Elevator in Building', 'cmb' ),
					'Indoor Fireplace' => __( 'Indoor Fireplace', 'cmb' ),
					'Buzzer/Wireless Intercom' => __( 'Buzzer/Wireless Intercom', 'cmb' ),
					'Doorman' => __( 'Doorman', 'cmb' ),
					'Pool' => __( 'Pool', 'cmb' ),
					'Hot Tub' => __( 'Hot Tub', 'cmb' ),
					'Gym' => __( 'Gym', 'cmb' ),
					'Smoke Detector' => __( 'Smoke Detector', 'cmb' ),
					'Carbon Monoxide Detector' => __( 'Carbon Monoxide Detector', 'cmb' ),
					'First Aid Kit' => __( 'First Aid Kit', 'cmb' ),
					'Safety Card' => __( 'Safety Card', 'cmb' ),
					'Fire Extinguisher' => __( 'Fire Extinguisher', 'cmb' ),
				),
				// 'inline'  => true, // Toggles display to inline
			),
			
			
			
			array(
				'name'       => __( 'Price for extra people', 'cmb' ),
				'desc'       => __( 'Enter price for extra people', 'cmb' ),
				'id'         => 'extrapeople_text',
				'type'       => 'text_money',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value		
			),
			
			array(
				'name'       => __( 'Price for security deposit', 'cmb' ),
				'desc'       => __( 'Enter price for security deposit', 'cmb' ),
				'id'         => 'deposit_text',
				'type'       => 'text_money',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			
			array(
				'name'       => __( 'Price for daily price', 'cmb' ),
				'desc'       => __( 'Enter price for daily price', 'cmb' ),
				'id'         => 'price_text',
				'type'       => 'text_money',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
			),
			
			array(
				'name'       => __( 'Price for weekly price', 'cmb' ),
				'desc'       => __( 'Enter price for weekly price', 'cmb' ),
				'id'         => 'weeklyprice_text',
				'type'       => 'text_money',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
			),
			
			array(
				'name'       => __( 'Price for monthly price', 'cmb' ),
				'desc'       => __( 'Enter price for monthly price', 'cmb' ),
				'id'         => 'monthlyprice_text',
				'type'       => 'text_money',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
			),
			
			array(
				'name'       => __( 'Permit No.', 'cmb' ),
				'desc'       => __( 'Enter your permit no.', 'cmb' ),
				'id'         => 'permitno_text',
				'type'       => 'text',
				'show_on_cb' => 'cmb_test_text_show_on_cb', // function should return a bool value
				
			),
			
		),
	);

	return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

}





// Creating the widget
class wpb_widget extends WP_Widget {
 
function __construct() {
parent::__construct(
// Base ID of your widget
'wpb_widget',
	 
// Widget name will appear in UI
__('Recent Listing', 'wpb_widget_domain'),
 
// Widget description
array( 'description' => __( 'Your site’s most recent listings. ', 'wpb_widget_domain' ), )
);
}
 
// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
 

	global $query_string;
	query_posts('order=ASC&showposts=5&post_type=listing');
							
	?> <ul id="menu-main-menu-1" class="menu"> <?php
	while ( have_posts() ) : the_post();
	?> 
	
<li><a href="<?php  the_permalink(); ?>"><?php	
		the_title();
		echo '</a>'; ?></li>
	
	 <?php	
		endwhile;
	?> </ul> <?php
echo $args['after_widget'];
}
	         
// Widget Backend
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'New title', 'wpb_widget_domain' );
}
// Widget admin form
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php
}
    
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
return $instance;
}
} // Class wpb_widget ends here
 
// Register and load the widget
function wpb_load_widget() {
    register_widget( 'wpb_widget' );
}

add_action( 'widgets_init', 'wpb_load_widget' );






// Creating the widget
class fb_widget extends WP_Widget {
 
function __construct() {
parent::__construct(
// Base ID of your widget
'fb_widget',
	 
// Widget name will appear in UI
__('Facebook Like Box', 'wpb_widget_domain'),
 
// Widget description
array( 'description' => __( 'Facebook Like Box', 'wpb_widget_domain' ), )
);
}
 
// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$fbid = apply_filters( 'facebook_title', $instance['fbid'] );
// before and after widget arguments are defined by themes
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
 
?>
	
	<div style="  margin: 0 auto;  width: 300px;  background-color: white;  height: 289px;">
		<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2F<?php echo $fbid; ?>&amp;width&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=120522671443506" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true"></iframe>
	</div>
	
	 <?php	
		
echo $args['after_widget'];
}
	         
// Widget Backend
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'New title', 'wpb_widget_domain' );
}
// Widget admin form
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>

<?php

if ( isset( $instance[ 'fbid' ] ) ) {
$fbid = $instance[ 'fbid' ];
}
else {
$fbid = __( 'Facebook Id', 'wpb_widget_domain' );
}
// Widget admin form
?>
<p>
<label for="<?php echo $this->get_field_id( 'fbid' ); ?>"><?php _e( 'Facebook Id:' ); ?></label>
<input class="widefat" id="<?php echo $this->get_field_id( 'fbid' ); ?>" name="<?php echo $this->get_field_name( 'fbid' ); ?>" type="text" value="<?php echo esc_attr( $fbid ); ?>" />
</p>

<?php
}
    
// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['fbid'] = ( ! empty( $new_instance['fbid'] ) ) ? strip_tags( $new_instance['fbid'] ) : '';
return $instance;
}
} // Class wpb_widget ends here
 
// Register and load the widget
function fb_load_widget() {
    register_widget( 'fb_widget' );
}

add_action( 'widgets_init', 'fb_load_widget' );



if (isset($_GET['activated']) && is_admin()){

        $new_page_title = 'Default Slider';
        $new_page_content = 'This is the page content';
	    $new_page_template = ''; //ex. template-custom.php. Leave blank if you don't want a custom page template.
	        //don't change the code bellow, unless you know what you're doing
	    $page_check = get_page_by_title($new_page_title);
	    $new_page = array(
	                'post_type' => 'gallery',
	                'post_title' => $new_page_title,
	                'post_content' => $new_page_content,
	                'post_status' => 'publish',
	                'post_author' => 1,
	        );

	        if(!isset($page_check->ID)){
	                $new_page_id = wp_insert_post($new_page);
	                if(!empty($new_page_template)){
	                        update_post_meta($new_page_id, '_wp_page_template', $new_page_template);
	                }
					
					update_post_meta($new_page_id, 'videomp4', ''.get_template_directory_uri().'/images/default.jpg');
					update_post_meta($new_page_id, 'video_title', 'Default Slider');
					
	        }
}


add_action('after_setup_theme', 'mytheme_setup');

function mytheme_setup() {

	 if(!get_page_by_title('Listings', 'OBJECT', 'page')) {

		 if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
				
				$listing = array(
					'post_type'    => 'page',
					'post_title'    => 'Listings',
					'post_content'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel odio nunc. Quisque lacinia congue risus, eu suscipit nibh feugiat sit amet. Fusce tempor porta ipsum, eu porta turpis finibus eu. Suspendisse erat eros, aliquam a purus ac, eleifend semper odio. Sed nec lectus at eros facilisis faucibus. Mauris commodo at risus sed tempor. Aliquam et nisl pellentesque, condimentum lectus at, blandit nisi. Sed at vehicula ex. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque at aliquet tortor, at vehicula dolor. Aenean lobortis velit aliquet velit luctus, ac semper ipsum egestas. Integer at elit eget elit cursus consectetur.<br/><br/>
										Aliquam in nunc vel urna tempor ultrices in nec ipsum. Nunc ac velit ut augue venenatis tempus. Ut dictum ex a tellus fringilla lacinia. Ut quis orci arcu. Praesent interdum neque posuere, lacinia augue sit amet, semper nulla. Proin vitae lobortis arcu. Suspendisse feugiat interdum venenatis. In pretium, tellus sit amet blandit porttitor, diam mauris blandit velit, a congue dui enim ac urna.<br/><br/>
										Vivamus maximus, metus vitae mattis sodales, mauris enim eleifend eros, auctor viverra nunc velit fermentum turpis. Donec mattis ultrices imperdiet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer sit amet tortor rutrum, vestibulum ipsum ac, vehicula erat. Maecenas vel mattis nisl. Nullam sit amet neque tellus. Morbi et gravida mauris. Etiam pellentesque nunc ligula, sed porttitor lectus finibus non. Integer blandit pretium leo, vitae egestas mi scelerisque sed. Proin enim sem, mollis sed nulla sit amet, commodo dapibus tellus',
					'post_status'   => 'publish',
					'post_author'   => 1
				); 
				
				$search_id =  wp_insert_post( $listing );
			
				update_post_meta($search_id, '_wp_page_template', 'page-search.php');
		  }
			
	 }
	 
	
	 
	 
	  if(!get_page_by_title('Amazing 2 Bed in Waikiki', 'OBJECT', 'listing')) {

		 if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
				
				$listing = array(
					'post_type'    => 'listing',
					'post_title'    => 'Amazing 2 Bed in Waikiki',
					'post_content'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel odio nunc. Quisque lacinia congue risus, eu suscipit nibh feugiat sit amet. Fusce tempor porta ipsum, eu porta turpis finibus eu. Suspendisse erat eros, aliquam a purus ac, eleifend semper odio. Sed nec lectus at eros facilisis faucibus. Mauris commodo at risus sed tempor. Aliquam et nisl pellentesque, condimentum lectus at, blandit nisi. Sed at vehicula ex. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque at aliquet tortor, at vehicula dolor. Aenean lobortis velit aliquet velit luctus, ac semper ipsum egestas. Integer at elit eget elit cursus consectetur.<br/><br/>
										Aliquam in nunc vel urna tempor ultrices in nec ipsum. Nunc ac velit ut augue venenatis tempus. Ut dictum ex a tellus fringilla lacinia. Ut quis orci arcu. Praesent interdum neque posuere, lacinia augue sit amet, semper nulla. Proin vitae lobortis arcu. Suspendisse feugiat interdum venenatis. In pretium, tellus sit amet blandit porttitor, diam mauris blandit velit, a congue dui enim ac urna.<br/><br/>
										Vivamus maximus, metus vitae mattis sodales, mauris enim eleifend eros, auctor viverra nunc velit fermentum turpis. Donec mattis ultrices imperdiet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer sit amet tortor rutrum, vestibulum ipsum ac, vehicula erat. Maecenas vel mattis nisl. Nullam sit amet neque tellus. Morbi et gravida mauris. Etiam pellentesque nunc ligula, sed porttitor lectus finibus non. Integer blandit pretium leo, vitae egestas mi scelerisque sed. Proin enim sem, mollis sed nulla sit amet, commodo dapibus tellus',
					'post_status'   => 'publish',
					'post_author'   => 1
				); 
				
				
				
				$listing_id =  wp_insert_post( $listing );
				update_post_meta($listing_id, '_wp_page_template', '');
				update_post_meta($listing_id, 'home_type', 'Apartment');
				update_post_meta($listing_id, 'guest_text', '6');
				update_post_meta($listing_id, 'address', '2452 Tusitala St Honolulu HI ');
				update_post_meta($listing_id, 'bedroom_text', '2');
				update_post_meta($listing_id, 'bed_text', '3');
				update_post_meta($listing_id, 'extrapeople_text', '10.00');
				update_post_meta($listing_id, 'deposit_text', '250.00');
				update_post_meta($listing_id, 'price_text', '250.00');
				update_post_meta($listing_id, 'weeklyprice_text', '250.00');
				update_post_meta($listing_id, 'monthlyprice_text', '250.00');
				update_post_meta($listing_id, 'permitno_text', 'HI Tax ID W83763441-01');
		  }
			
	 }
	 
	 if(!get_page_by_title('Great Cabin in the Woods', 'OBJECT', 'listing')) {

		 if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
				
				$listing1 = array(
					'post_type'    => 'listing',
					'post_title'    => 'Great Cabin in the Woods',
					'post_content'  => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel odio nunc. Quisque lacinia congue risus, eu suscipit nibh feugiat sit amet. Fusce tempor porta ipsum, eu porta turpis finibus eu. Suspendisse erat eros, aliquam a purus ac, eleifend semper odio. Sed nec lectus at eros facilisis faucibus. Mauris commodo at risus sed tempor. Aliquam et nisl pellentesque, condimentum lectus at, blandit nisi. Sed at vehicula ex. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Pellentesque at aliquet tortor, at vehicula dolor. Aenean lobortis velit aliquet velit luctus, ac semper ipsum egestas. Integer at elit eget elit cursus consectetur.<br/><br/>
										Aliquam in nunc vel urna tempor ultrices in nec ipsum. Nunc ac velit ut augue venenatis tempus. Ut dictum ex a tellus fringilla lacinia. Ut quis orci arcu. Praesent interdum neque posuere, lacinia augue sit amet, semper nulla. Proin vitae lobortis arcu. Suspendisse feugiat interdum venenatis. In pretium, tellus sit amet blandit porttitor, diam mauris blandit velit, a congue dui enim ac urna.<br/><br/>
										Vivamus maximus, metus vitae mattis sodales, mauris enim eleifend eros, auctor viverra nunc velit fermentum turpis. Donec mattis ultrices imperdiet. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer sit amet tortor rutrum, vestibulum ipsum ac, vehicula erat. Maecenas vel mattis nisl. Nullam sit amet neque tellus. Morbi et gravida mauris. Etiam pellentesque nunc ligula, sed porttitor lectus finibus non. Integer blandit pretium leo, vitae egestas mi scelerisque sed. Proin enim sem, mollis sed nulla sit amet, commodo dapibus tellus',
					'post_status'   => 'publish',
					'post_author'   => 1
				); 
				
				$listing1_id =  wp_insert_post( $listing1 );
				update_post_meta($listing1_id, '_wp_page_template', '');
				update_post_meta($listing1_id, 'home_type', 'Cabin');
				update_post_meta($listing1_id, 'guest_text', '6');
				update_post_meta($listing1_id, 'address', 'Weare, New Hampshire');
				update_post_meta($listing1_id, 'bedroom_text', '2');
				update_post_meta($listing1_id, 'bed_text', '3');
				update_post_meta($listing1_id, 'extrapeople_text', '10.00');
				update_post_meta($listing1_id, 'deposit_text', '250.00');
				update_post_meta($listing1_id, 'price_text', '250.00');
				update_post_meta($listing1_id, 'weeklyprice_text', '250.00');
				update_post_meta($listing1_id, 'monthlyprice_text', '250.00');
				update_post_meta($listing1_id, 'permitno_text', 'HI Tax ID W83763441-01');
				
		  }
			
	 }
	 
	 if(!get_page_by_title('Modern Lakefront Home', 'OBJECT', 'listing')) {

		 if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
				
				$listing2 = array(
					'post_type'    => 'listing',
					'post_title'    => 'Modern Lakefront Home',
					'post_content'  => '',
					'post_status'   => 'publish',
					'post_author'   => 1
				); 
				
				$listing2_id =  wp_insert_post( $listing2 );
				update_post_meta($listing2_id, '_wp_page_template', '');
				update_post_meta($listing2_id, 'home_type', 'Apartment');
				update_post_meta($listing2_id, 'guest_text', '6');
				update_post_meta($listing2_id, 'address', 'North Carolina ');
				update_post_meta($listing2_id, 'bedroom_text', '2');
				update_post_meta($listing2_id, 'bed_text', '3');
				update_post_meta($listing2_id, 'extrapeople_text', '10.00');
				update_post_meta($listing2_id, 'deposit_text', '250.00');
				update_post_meta($listing2_id, 'price_text', '250.00');
				update_post_meta($listing2_id, 'weeklyprice_text', '250.00');
				update_post_meta($listing2_id, 'monthlyprice_text', '250.00');
				update_post_meta($listing2_id, 'permitno_text', 'HI Tax ID W83763441-01');
				
		  }
			
	 }
	 

	 
	  if(!get_page_by_title('Blog', 'OBJECT', 'page')) {

		 if(get_option('page_on_front')=='0' && get_option('show_on_front')=='posts'){
				
				$search = array(
					'post_type'    => 'page',
					'post_title'    => 'Blog',
					'post_content'  => '',
					'post_status'   => 'publish',
					'post_author'   => 1
				); 
				
				$search_id =  wp_insert_post( $search );
				
				$theme_url = get_template_directory_uri();
				
				
				
				$filename = ''.ABSPATH.'/wp-content/uploads/background3.jpg';
								
				$filetype = wp_check_filetype( basename( $filename ), null );
				
				$wp_upload_dir = wp_upload_dir();

				$attachment = array(
					'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
					'post_mime_type' => $filetype['type'],
					'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
					'post_content'   => '',
					'post_status'    => 'inherit'
				);

				
				 $attach_id = wp_insert_attachment( $attachment, $filename, $search_id );
				 
				 add_post_meta($search_id, '_thumbnail_id', $attach_id, true);
			
				 update_post_meta($search_id, '_wp_page_template', 'page-blogs.php');
		  }
			
	 }
	 
	
	
	
	
}	