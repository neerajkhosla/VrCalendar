<?php get_header(); ?>
<?php echo do_shortcode('[homepageslider]') ?>

	<div class="container">
		
			<div id="content" class="clearfix row">
			
				<div id="main" class="col-sm-12 clearfix" role="main">


					
					<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article">
					
						<header>		
								<div class="padd">
									<h1 class="title-home"><?php echo of_get_option( 'top_text', 'Top Text Title' ); ?></h1>
									<p class="title-homea"><?php echo of_get_option( 'top_sub', 'Top sub text title' ); ?></p>
								</div>					
						</header>
					
					<?php $image1 =  get_template_directory_uri().'/images/1-rs31.jpg'; ?>
					<?php $image2 =  get_template_directory_uri().'/images/3-rs31.jpg'; ?>
					<?php $image3 =  get_template_directory_uri().'/images/4-rs31.jpg'; ?>
						
					<section class="row post_content">					
						<div class="col-sm-12">
							<div class="col-sm-4"><a href="<?php echo of_get_option( 'logo-popular-link1', '#' ); ?>"><img src="<?php echo of_get_option( 'logo-image-popular1', $image1 ); ?>" alt="" title="" /></a></div>
							<div class="col-sm-4"><a href="<?php echo of_get_option( 'logo-popular-link2', '#' ); ?>"><img src="<?php echo of_get_option( 'logo-image-popular2', $image2 ); ?>" alt="" title="" /></a></div>
							<div class="col-sm-4"><a href="<?php echo of_get_option( 'logo-popular-link3', '#' ); ?>"><img src="<?php echo of_get_option( 'logo-image-popular3', $image3 ); ?>" alt="" title="" /></a></div>
						</div>
					</section> 

					<div class="padd">
						<h2 class="title-home"><?php echo of_get_option( 'mid_text', 'Mid Text Title' ); ?></h2>
						<p class="title-homea"><?php echo of_get_option( 'mid_sub', 'Mid sub text title' ); ?></p>
						<p><?php echo of_get_option( 'mid_editor', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel egestas est. Quisque odio orci, porttitor et felis vel, facilisis ultricies ante. Donec eget lacus posuere, convallis purus eu, vestibulum dui. Suspendisse luctus tortor lacus, ut porttitor metus accumsan ac. Nam non laoreet libero. Etiam eu nulla in sem scelerisque pharetra. Curabitur congue elit eget dignissim interdum. Quisque id turpis mattis est bibendum iaculis. Nulla nisi tortor, mattis vel nisl sit amet, fermentum tempus erat. Cras dignissim, ipsum vel vehicula euismod, mi tellus viverra felis, quis volutpat dui ligula nec nunc.' ); ?></p>
					</div>		

	
					<header>		
						<div class="padd">
							<h2 class="title-home"><?php echo of_get_option( 'bottom_text', 'Listings' ); ?></h2>	
							<?php $args = array(
								'sort_order' => 'asc',
								'sort_column' => 'post_title',
								'hierarchical' => 1,
								'exclude' => '',
								'include' => '',
								'meta_key' => '',
								'meta_value' => '',
								'authors' => '',
								'child_of' => 0,
								'parent' => -1,
								'exclude_tree' => '',
								'number' => '',
								'offset' => 0,
								'post_type' => 'page',
								'post_status' => 'publish'
							); 
							$pages = get_pages($args); 
							
							$pages = get_pages(); 
							foreach ( $pages as $page ) {
								if(get_the_title( $page->ID ) == "Listings") {
								?>
									<p class="title-homea"><a href="<?php echo get_page_link( $page->ID );  ?>"><?php echo of_get_option( 'bottom_sub', 'See All Listings Here' ); ?></a></p>
								<?php
								}
							}
							?>
							
							
						</div>					
					</header>
						
						<section class="row post_content">
							<div class="col-sm-12">
							<?php
							global $query_string;
							query_posts('order=ASC&showposts=3&post_type=listing');
							
							$i = 0;
							
							if ( have_posts() ) : while ( have_posts() ) : the_post();
								 $i = $i + 1;
							endwhile; else: 
							endif; 
							// Reset Query
							wp_reset_query();
							
							query_posts('order=ASC&showposts=3&post_type=listing');
							
							// The Loop
							if ( have_posts() ) : while ( have_posts() ) : the_post();
								if($i ==  1) {

									?>
									<div class="col-sm-4" style="float:none; margin:0 auto;"><a style="color:#565a5c;" href="<?php  the_permalink(); ?>"><?php	echo '<p style="text-align:center;"><strong>';
										the_title();
									echo '</strong></p></a>';
									if ( has_post_thumbnail() ) {
										?><a href="<?php  the_permalink(); ?>"> <?php	the_post_thumbnail('thumbnail'); ?> </a> <?php
									} else {
										?>
										<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/9-rs31-150x150.jpg" alt="" title="" />
										
										<?php
									} 
									?> 		
									</div>
									<?php									
								}
								else {
								?> 
									<div class="col-sm-4"><a style="color:#565a5c;" href="<?php  the_permalink(); ?>"><?php	echo '<p style="text-align:center;"><strong>';
										the_title();
										echo '</strong></p></a>';
										if ( has_post_thumbnail() ) {
											
												?><a href="<?php  the_permalink(); ?>"> <?php	the_post_thumbnail('thumbnail'); ?> </a> <?php
											
										} 	else {
											if(get_the_title() == "Amazing 2 Bed in Waikiki") {
												?>
												<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/9-rs31-150x150.jpg" alt="" title="" />			
												<?php
											} if (get_the_title() == "Great Cabin in the Woods") {
												?>
												<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/enlighted-65961_400-1-150x150.jpg" alt="" title="" />			
												<?php
											} if (get_the_title() == "Modern Lakefront Home") {
												?>
												<img class="attachment-thumbnail wp-post-image" src="<?php echo get_template_directory_uri(); ?>/images/beach-house-349670_400-1-150x150.jpg" alt="" title="" />			
												<?php
											}
										} 
									?> 			
									</div> 							
								<?php } endwhile; else: ?>
								<p>Sorry, no listing posts matched your criteria.</p>
							 <?php endif; 
							// Reset Query
							wp_reset_query();
							
							?>
						
							</div>	
							<br style="clear:both;" />
							
							
							
						</section> 
			

					
					</article> <!-- end article -->
					
					<?php 
						// No comments on homepage
						//comments_template();
					?>
					
					
					
				
				</div> <!-- end #main -->
    
				<?php //get_sidebar(); // sidebar 1 ?>

			</div> <!-- end #content -->

	</div> <!-- end #main -->

<div class="clearfix"></div>
<?php get_footer(); ?>