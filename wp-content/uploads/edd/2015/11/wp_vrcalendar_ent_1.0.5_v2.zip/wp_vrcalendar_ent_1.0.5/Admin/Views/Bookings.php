<?php
$calendar_id = @$_GET['cal_id'];
if(empty($calendar_id)){
    echo 'Missing calendar id';
    return;
}
/* Display booking table here */
$VRCalendarEntity = VRCalendarEntity::getInstance();
$booking_data = $VRCalendarEntity->getCalendar( $calendar_id );
?>
<h2>
Bookings for Calendar "<?php echo $booking_data->calendar_name ?>"
</h2>
<form id="my-calendars" name=my-calendars" method="post" action="">
<?php
    $VRBookingsTable = new VRBookingsTable();
    $VRBookingsTable->prepare_items();
    $VRBookingsTable->display();
    $VRBookingsTable->process_bulk_action();
?>
</form>
<?php
class VRBookingsTable extends WP_List_Table {
    function __construct() {
        parent::__construct();
    }
    /**
     * @Method name  column_default
     * @Params       $booking,$column_name
     * @description  display static column name and corrosponding value
     */
    function column_default($booking, $column_name)
    {
        /* display all dynamic data from database  */
        switch ($column_name)
        {
            case 'booking_created_on':
            case 'booking_date_from':
            case 'booking_date_to':
                return  date('Y-m-d', strtotime($booking[$column_name]));
            case 'booking_user_name':
                return $booking['booking_user_fname'].' '.$booking['booking_user_lname'];
            default:
                return $booking[$column_name];
        }
    }
    /**
     * @Method name  column_name
     * @Params       $booking
     * @description  display static column name and corrosponding value
     */
    function column_booking_user_name($booking)
    {
        $actions = array(
            'delete' => '<a href="' .admin_url('admin.php?page='.VRCALENDAR_PLUGIN_SLUG.'-dashboard&view=bookings&vrc_cmd=VRCalendarAdmin:deleteBooking&bid='.$booking['booking_id'].'&cal_id='.$_GET['cal_id']). '">Delete</a>'
        );

        if($booking['booking_admin_approved'] == 'no') {
            $actions['approve_booking'] = '<a href="' .admin_url('admin.php?page='.VRCALENDAR_PLUGIN_SLUG.'-dashboard&view=bookings&vrc_cmd=VRCalendarAdmin:approveBooking&bid='.$booking['booking_id'].'&cal_id='.$_GET['cal_id']). '">Approve</a>';
        }
        return $booking['booking_user_fname'].' '.$booking['booking_user_lname'].$this->row_actions($actions) ;
    }

    /**
     * @Method name  column_cb
     * @Params       $booking
     * @description  display check box for all Calendar data value
     */
    function column_cb($booking)
    {
        return '<input type="checkbox" name="check[]" value="'.$booking['calendar_id'].'" />';
    }

    /**
     * @Method name  get_columns
     * @description  display head tr for table
     */
    function get_columns()
    {
        $columns = array(
            'cb' => '<input type="checkbox"/>',
            'booking_user_name' => 'Name',
            'booking_user_email' => 'Email',
            'booking_date_from' =>'Booking From',
            'booking_date_to' =>'Booking To',
            'booking_guests'=> 'Guests',
            'booking_status'=> 'Status',
            'booking_payment_status'=>'Payment Status',
            'booking_admin_approved'=>'Booking Approved',
            'booking_total_price'=>'Booking Price ($)',
            'booking_created_on' =>'Booking Date',
            'booking_summary' => 'Summary',
        );
        return $columns;
    }

    function process_bulk_action()
    {
        extract($_REQUEST);
        if(isset($check))
        {
            if( 'trash'===$this->current_action() )
            {
                $msg = 'delete';
                global $wpdb;
                $booking_table = $wpdb->prefix."vrcalandar_bookings";
                foreach($check as $booking_id)
                {
                    $booking_query = "delete  FROM ".$booking_table." where booking_id='".$booking_id."' ";
                    $wpdb->query($booking_query);
                }
                //$redirectTo = admin_url().'admin.php?page=vr-calendar/includes/controller.php&msg='.$msg;
                //wp_redirect($redirectTo);
                exit;
            }
        }
    }

    /**
     * @Method name  get_sortable_columns
     * @description  implement sorting on elments included in $sortable_columns array
     */
    function get_sortable_columns()
    {
        //return;
        $sortable_columns = array(
            'booking_date_from' => array(
                'booking_date_from',
                false
            ),
            'booking_date_to' => array(
                'booking_date_to',
                false
            ),
            'booking_guests' => array(
                'booking_guests',
                false
            ),
            'booking_status' => array(
                'booking_status',
                false
            ),
            'booking_payment_status' => array(
                'booking_payment_status',
                false
            ),
            'booking_created_on' => array(
                'booking_created_on',
                false
            ),

        );
        return $sortable_columns;
    }
    /**
     * @Method name  get_bulk_actions
     * @description  implement bulk action included in $actions array
     */
    function get_bulk_actions()
    {
        return array();
        $actions = array(
            'trash' => 'Trash'
        );
        return $actions;
    }

    /**
     * @Method name  prepare_items
     * @description  ready data to display
     */
    function prepare_items()
    {
        global $wpdb;
        $booking_table = $wpdb->prefix."vrcalandar_bookings";
        $booking_per_page   = 20;
        //retrive all calendar  from database

        $booking_query = "SELECT * FROM {$booking_table} where booking_source='website' and booking_calendar_id='{$_GET['cal_id']}'";
        $booking_data = $wpdb->get_results($booking_query, ARRAY_A);
        usort($booking_data, array( &$this, 'sort_data' ) );
        $columns   = $this->get_columns();
        $sortable  = $this->get_sortable_columns();
        $this->process_bulk_action();
        $this->_column_headers = array(
            $columns,
            array(),
            $sortable
        );

        //pagging code starts from here
        $current_page = $this->get_pagenum();
        $total_cal = count($booking_data);
        $booking_data = array_slice(
            $booking_data,(
            ($current_page-1)*$booking_per_page
        ),$booking_per_page
        );
        $this->items = $booking_data;

        $this->set_pagination_args(
            array(
                'total_items'=>$total_cal,
                'per_page'=> $booking_per_page,
                'total_pages'=>ceil($total_cal/$booking_per_page)
            )
        );
        //pagging code ends from here
    }

    /**
     * @Method name  sort_data
     * @params $a $b
     * @description  sort product member data
     */
    public function sort_data($a, $b)
    {
        // Set defaults
        $orderby = 'booking_created_on';
        $order   = 'asc';
        // If orderby is set, use this as the sort column
        if (!empty($_GET['orderby']))
        {
            $orderby = $_GET['orderby'];
        }
        // If order is set use this as the order
        if (!empty($_GET['order']))
        {
            $order = $_GET['order'];
        }
        $result = strnatcmp($a[$orderby], $b[$orderby]);
        if ($order =='asc')
        {
            return $result;
        }
        return -$result;
    }
}