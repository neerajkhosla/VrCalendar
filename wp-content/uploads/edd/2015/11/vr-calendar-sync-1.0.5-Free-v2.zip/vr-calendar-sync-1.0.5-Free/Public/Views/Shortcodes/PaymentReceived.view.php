<div class="vrc" id="vrc-payment-form-wrapper">
    <?php echo $data['payment_received']; ?>
</div>