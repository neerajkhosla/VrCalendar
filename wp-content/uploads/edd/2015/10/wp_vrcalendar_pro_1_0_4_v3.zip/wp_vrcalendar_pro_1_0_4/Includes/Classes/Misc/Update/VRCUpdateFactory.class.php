<?php
/**
 * A factory that builds instances of other classes.
 */
class VRCUpdateFactory {
    protected static $classVersions = array();
    protected static $sorted = false;

    /**
     * Create a new instance of VRCUpdateChecker.
     *
     * @see VRCUpdateChecker::__construct()
     *
     * @param $metadataUrl
     * @param $pluginFile
     * @param string $slug
     * @param int $checkPeriod
     * @param string $optionName
     * @param string $muPluginFile
     * @return VRCUpdateChecker
     */
    public static function buildUpdateChecker($metadataUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '', $muPluginFile = '') {
        $class = self::getLatestClassVersion('VRCUpdateChecker');
        return new $class($metadataUrl, $pluginFile, $slug, $checkPeriod, $optionName, $muPluginFile);
    }

    /**
     * Get the specific class name for the latest available version of a class.
     *
     * @param string $class
     * @return string|null
     */
    public static function getLatestClassVersion($class) {
        if ( !self::$sorted ) {
            self::sortVersions();
        }

        if ( isset(self::$classVersions[$class]) ) {
            return reset(self::$classVersions[$class]);
        } else {
            return null;
        }
    }

    /**
     * Sort available class versions in descending order (i.e. newest first).
     */
    protected static function sortVersions() {
        foreach ( self::$classVersions as $class => $versions ) {
            uksort($versions, array(__CLASS__, 'compareVersions'));
            self::$classVersions[$class] = $versions;
        }
        self::$sorted = true;
    }

    protected static function compareVersions($a, $b) {
        return -version_compare($a, $b);
    }

    /**
     * Register a version of a class.
     *
     * @access private This method is only for internal use by the library.
     *
     * @param string $generalClass Class name without version numbers, e.g. 'VRCUpdateChecker'.
     * @param string $versionedClass Actual class name, e.g. 'VRCUpdateChecker_1_2'.
     * @param string $version Version number, e.g. '1.2'.
     */
    public static function addVersion($generalClass, $versionedClass, $version) {
        if ( !isset(self::$classVersions[$generalClass]) ) {
            self::$classVersions[$generalClass] = array();
        }
        self::$classVersions[$generalClass][$version] = $versionedClass;
        self::$sorted = false;
    }
}