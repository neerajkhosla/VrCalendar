<div class="wrap">
    <h2><?php echo VRCALENDAR_PLUGIN_NAME; ?></h2>
    <iframe src="http://www.vrcalendarsync.com/" id="infoframe" class="vc-full-iframe" height="1910" />
</div>