<?php
/*
Plugin Name: Sample Plugin
Plugin URI: http://pippinsplugins.com/
Description: Illustrates how to include an updater in your plugin for EDD Software Licensing
Author: Pippin Williamson
Author URI: http://pippinsplugins.com
Version: 1.0.2
*/
// this is the URL our updater / license checker pings. This should be the URL of the site with EDD installed
define( 'EDD_SL_STORE_URL', 'http://vrcalendarsync.com' );
// the name of your product. This should match the download name in EDD exactly
define( 'EDD_SL_ITEM_NAME', 'Sample Plugin' );
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	// load our custom updater
	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}
// retrieve our license key from the DB
$license_key = trim( get_option( 'edd_sample_license_key' ) );
// setup the updater
$edd_updater = new EDD_SL_Plugin_Updater( EDD_SL_STORE_URL, __FILE__, array( 
		'version' 	=> '1.0.2', 		// current version number
		'license' 	=> $license_key, 	// license key (used get_option above to retrieve from DB)
		'item_name'     => EDD_SL_ITEM_NAME, 	// name of this plugin
		'author' 	=> 'Pippin Williamson',  // author of this plugin
		'url'           => home_url()
	)
);
