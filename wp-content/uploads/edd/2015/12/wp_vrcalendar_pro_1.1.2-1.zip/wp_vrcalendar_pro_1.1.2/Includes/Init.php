<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die();
}
/* Load required files */
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Misc/Update/VRCUpdateChecker.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Misc/Update/VRCUpdateInfo.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Misc/Update/VRCUpdate.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Misc/Update/VRCUpdateFactory.class.php' );

require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Vendor/Stripe/init.php' );

require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Abstract/Singleton/VRCSingleton.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Abstract/Shortcode/VRCShortcode.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Settings/VRCalendarSettings.class.php' );

require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Email/VRCEmail.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Email/Transactional/VRCTransactionalEmail.class.php' );

require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Entity/VRCalendarEntity.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/Entity/Booking/VRCalendarBooking.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Classes/ICal/VRCICal.class.php' );

require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/Shortcode/VRCalendarShortcode.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/Shortcode/VRCalendarBookingBtnShortcode.class.php' );
// ..................add searchbars...................................start..........................
global $gbversiontype;
    if (($gbversiontype == "enterprisepaid") or ($gbversiontype == "enterprise500"))  {
        require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/Shortcode/VRCalendarSearchbarShortcode.class.php' );
    }
// ..................add searchbars...................................start..........................
require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/Shortcode/VRBookingShortcode.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/Shortcode/VRPaymentShortcode.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/Shortcode/VRThankyouShortcode.class.php' );

require_once( VRCALENDAR_PLUGIN_DIR . '/Public/Classes/VRCalendar.class.php' );
require_once( VRCALENDAR_PLUGIN_DIR . '/Admin/Classes/VRCalendarAdmin.class.php' );

//Register classes with the factory.
VRCUpdateFactory::addVersion('VRCUpdateChecker', 'VRCUpdateChecker', '1.0');
VRCUpdateFactory::addVersion('VRCUpdate', 'VRCUpdate', '1.0');
VRCUpdateFactory::addVersion('VRCUpdateInfo', 'VRCUpdateInfo', '1.0');
/* Add update check */
$VRCUpdateChecker = VRCUpdateFactory::buildUpdateChecker(
    'http://vrcalendarsync.com/updates/ent/info.json',
    VRCALENDAR_PLUGIN_FILE
);

$load_admin = false;
if( is_admin() ) {
    $load_admin = true;
}
/*----------------------------------------------------------------------------*
 * Public-Facing Functionality
 *----------------------------------------------------------------------------*/


/*
 * Register hooks that are fired when the plugin is activated or deactivated.
 * When the plugin is deleted, the uninstall.php file is loaded.
 */
register_activation_hook( VRCALENDAR_PLUGIN_FILE, array( 'VRCalendar', 'activate' ) );
register_deactivation_hook( VRCALENDAR_PLUGIN_FILE, array( 'VRCalendar', 'deactivate' ) );


add_action( 'plugins_loaded', array( 'VRCalendar', 'getInstance' ) );

/*----------------------------------------------------------------------------*
 * Dashboard and Administrative Functionality
 *----------------------------------------------------------------------------*/

if ( $load_admin ) {
    add_action( 'plugins_loaded', array( 'VRCalendarAdmin', 'getInstance' ) );
}
//Global Variables for License Checking
$license_checked = false;
$license_valid = false;
