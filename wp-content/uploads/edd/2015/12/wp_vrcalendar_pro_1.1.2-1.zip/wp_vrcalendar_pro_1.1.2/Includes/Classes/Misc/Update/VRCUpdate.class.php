<?php
/**
 * A simple container class for holding information about an available update.
 *
 * @author Innate Images, LLC
 * @copyright 2015
 * @version 1.0
 * @access public
 */
class VRCUpdate {
    public $id = 0;
    public $slug;
    public $version;
    public $homepage;
    public $download_url;
    public $upgrade_notice;
    public $filename; //Plugin filename relative to the plugins directory.

    private static $fields = array('id', 'slug', 'version', 'homepage', 'download_url', 'upgrade_notice', 'filename');

    /**
     * Create a new instance of VRCUpdate from its JSON-encoded representation.
     *
     * @param string $json
     * @param bool $triggerErrors
     * @return VRCUpdate|null
     */
    public static function fromJson($json, $triggerErrors = false){
        //Since update-related information is simply a subset of the full plugin info,
        //we can parse the update JSON as if it was a plugin info string, then copy over
        //the parts that we care about.
        $VRCUpdateInfo = VRCUpdateInfo::fromJson($json, $triggerErrors);
        if ( $VRCUpdateInfo != null ) {
            return self::fromVRCUpdateInfo($VRCUpdateInfo);
        } else {
            return null;
        }
    }

    /**
     * Create a new instance of VRCUpdate based on an instance of VRCUpdateInfo.
     * Basically, this just copies a subset of fields from one object to another.
     *
     * @param VRCUpdateInfo $info
     * @return VRCUpdate
     */
    public static function fromVRCUpdateInfo($info){
        return self::fromObject($info);
    }

    /**
     * Create a new instance of VRCUpdate by copying the necessary fields from
     * another object.
     *
     * @param StdClass|VRCUpdateInfo|VRCUpdate $object The source object.
     * @return VRCUpdate The new copy.
     */
    public static function fromObject($object) {
        $update = new self();
        $fields = self::$fields;
        if (!empty($object->slug)) $fields = apply_filters('vrc_retain_fields-'.$object->slug, $fields);
        foreach($fields as $field){
            if (property_exists($object, $field)) {
                $update->$field = $object->$field;
            }
        }
        return $update;
    }

    /**
     * Create an instance of StdClass that can later be converted back to
     * a VRCUpdate. Useful for serialization and caching, as it avoids
     * the "incomplete object" problem if the cached value is loaded before
     * this class.
     *
     * @return StdClass
     */
    public function toStdClass() {
        $object = new StdClass();
        $fields = self::$fields;
        if (!empty($this->slug)) $fields = apply_filters('vrc_retain_fields-'.$this->slug, $fields);
        foreach($fields as $field){
            if (property_exists($this, $field)) {
                $object->$field = $this->$field;
            }
        }
        return $object;
    }


    /**
     * Transform the update into the format used by WordPress native plugin API.
     *
     * @return object
     */
    public function toWpFormat(){
        $update = new StdClass;

        $update->id = $this->id;
        $update->slug = $this->slug;
        $update->new_version = $this->version;
        $update->url = $this->homepage;
        $update->package = $this->download_url;
        $update->plugin = $this->filename;

        if ( !empty($this->upgrade_notice) ){
            $update->upgrade_notice = $this->upgrade_notice;
        }

        return $update;
    }
}