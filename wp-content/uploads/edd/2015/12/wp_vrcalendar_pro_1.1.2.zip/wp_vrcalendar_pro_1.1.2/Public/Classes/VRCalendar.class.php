<?php
class VRCalendar extends VRCSingleton {
    /**
     * Plugin version, used for cache-busting of style and script file references.
     *
     * @since   1.0.0
     *
     * @var     string
     */
    const VERSION = '1.0.0';


    protected function __construct(){
        // Load plugin text domain
        add_action( 'init', array( $this, 'loadPluginTextdomain' ) );
        add_action( 'init', array( $this, 'initShortcodes' ) );
        add_action('init', array($this, 'handleCommands'));

        // Load public-facing style sheet and JavaScript.
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueueStyles' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueueScripts' ) );

        add_action( 'wp_ajax_get_updated_price', array($this, 'getUpdatedPrice') );
        add_action( 'wp_ajax_nopriv_get_updated_price', array($this, 'getUpdatedPrice') );

        add_action( 'wp_ajax_get_available_range_end', array($this, 'getAvailableRangeEnd') );
        add_action( 'wp_ajax_nopriv_get_available_range_end', array($this, 'getAvailableRangeEnd') );

        add_action( 'wp_ajax_vrc_paypal_return', array($this, 'paypalReturn') );
        add_action( 'wp_ajax_nopriv_vrc_paypal_return', array($this, 'paypalReturn') );

        add_action( 'wp_ajax_vrc_paypal_cancel', array($this, 'paypalCancel') );
        add_action( 'wp_ajax_nopriv_vrc_paypal_cancel', array($this, 'paypalCancel') );

        add_action( 'wp_ajax_vrc_paypal_notify', array($this, 'paypalNotify') );
        add_action( 'wp_ajax_nopriv_vrc_paypal_notify', array($this, 'paypalNotify') );

        add_action( 'wp_ajax_vrc_stripe_payment', array($this, 'stripePayment') );
        add_action( 'wp_ajax_nopriv_vrc_stripe_payment', array($this, 'stripePayment') );

        add_action( 'vrc_cal_sync_hook', array($this, 'syncAllCalendars') );

    }

    function syncAllCalendars() {
        $VRCalendarAdmin = VRCalendarAdmin::getInstance();
        $VRCalendarAdmin->syncAllCalendars();
    }

    function stripePayment() {
        $VRCalendarSettings = VRCalendarSettings::getInstance();
        $VRCalendarBooking = VRCalendarBooking::getInstance();
        $booking_id = $_REQUEST['bid'];
        $booking_data = $VRCalendarBooking->getBookingByID( $booking_id );
		$VRCalendarSettings = VRCalendarSettings::getInstance();
	    $sel_currency = $VRCalendarSettings->getSettings('attr_currency');
        $card = array(
            'name'  => $_POST['strip_name_on_card'],
            'number' => $_POST['strip_card_number'],
            'cvv' => $_POST['strip_cvv'],
            'exp_month' => $_POST['strip_expiration_month'],
            'exp_year' => $_POST['strip_expiration_year'],
            'address_line1' => $_POST['strip_address_line_1'],
            'address_line2' => $_POST['strip_address_line_2'],
            'address_city' => $_POST['strip_address_city'],
            'address_state' => $_POST['strip_address_state'],
            'address_zip' => $_POST['strip_address_zip'],
            'address_country' => $_POST['strip_address_country'],
        );
        $charge_data = array(
            'card' => $card,
            'amount' => floatval($booking_data->booking_total_price)*100,
            'currency' => $sel_currency
        );
        try {
            \Stripe\Stripe::setApiKey($VRCalendarSettings->getSettings('stripe_api_key'));
            $charge = \Stripe\Charge::create($charge_data);
            $charge_obj = json_decode(json_encode($charge));
            if($charge->paid) {
                /* Update this booking */
                $booking_data =  json_decode(json_encode($booking_data), true);
                $booking_data['booking_status'] = 'confirmed';
                $booking_data['booking_payment_status'] = 'confirmed';
                $booking_data['booking_payment_data'] = array(
                    'txn_id'=>$charge->id,
                    'raw_data'=> base64_encode(json_encode($charge_obj)),
                    'payment_method'=>'stripe'
                );
                $data = array(
                    'bid'=>$booking_id
                );
                $VRCalendarBooking->saveBooking( $booking_data );
                echo json_encode(array('result'=>'success', 'txn_id'=>$charge->id, 'bid'=>$booking_id));
            }
        }
        catch(Exception $e) {
            echo json_encode(array('result'=>'error', 'msg'=>$e->getMessage()));
        }
        exit;
    }

    function paypalReturn() {
        $VRCalendarSettings = VRCalendarSettings::getInstance();
        $VRCalendarBooking = VRCalendarBooking::getInstance();

        $booking_id = $_REQUEST['bid'];
        $txn_id = $_POST['txn_id'];
        $payment_status = $_POST['payment_status'];

        $status = 'pending';
        if($payment_status == 'Pending' || $payment_status == 'Completed') {
            $status = 'confirmed';
        }


        $booking_data = $VRCalendarBooking->getBookingByID( $booking_id );
        $booking_data =  json_decode(json_encode($booking_data), true);
        $booking_data['booking_status'] = $status;
        $booking_data['booking_payment_status'] = $status;
        $booking_data['booking_payment_data'] = array(
            'txn_id'=>$_POST['txn_id'],
            'raw_data'=> base64_encode(json_encode($_POST)),
            'payment_method'=>'paypal'
        );
        $data = array(
            'bid'=>$booking_id
        );
        $VRCalendarBooking->saveBooking( $booking_data );
        /* Redirect to thank you page */
        wp_redirect( add_query_arg($data, get_permalink($VRCalendarSettings->getSettings('thank_you_page'))) );
        //echo 'Payment completed..';
        exit;
        //print_r($_REQUEST);die();
    }
    function paypalCancel() {
        $VRCalendarSettings = VRCalendarSettings::getInstance();
        $VRCalendarBooking = VRCalendarBooking::getInstance();
        /* Delete the booking */
        $booking_id = $_REQUEST['bid'];
        $VRCalendarBooking->deleteBooking($booking_id);

        wp_redirect( get_permalink($VRCalendarSettings->getSettings('payment_cancel_page')) );
        exit;
        //print_r($_REQUEST);die();
    }
    function paypalNotify() {
        //print_r($_REQUEST);die();
    }

    function handleCommands() {
        if(isset($_POST['vrc_pcmd'])) {
            switch($_POST['vrc_pcmd']) {
                case 'saveBooking':
                    $this->saveBooking();
                    break;
                case 'paypalPayment':
                    $this->paypalPayment();
                    break;
            }
        }
    }

    function paypalPayment() {
        $VRCalendarSettings = VRCalendarSettings::getInstance();
        $VRCalendarBooking = VRCalendarBooking::getInstance();
		$sel_currency = $VRCalendarSettings->getSettings('attr_currency');

        $booking_id = $_POST['bid'];
        $booking_data = $VRCalendarBooking->getBookingByID( $booking_id );

        $paypal_vars = array();
        $paypal_vars['cmd'] = '_xclick';
        $paypal_vars['currency_code'] = $sel_currency;
        $paypal_vars['cbt'] = 'Click here to complete your order';

        $paypal_vars['business'] = $VRCalendarSettings->getSettings('paypal_email');
        $paypal_vars['item_name'] = 'Booking';
        $paypal_vars['item_number'] = $booking_id;
        $paypal_vars['amount'] = $booking_data->booking_total_price;

        $paypal_vars['return'] = add_query_arg(array('bid'=>$booking_id, 'action'=>'vrc_paypal_return'), admin_url('admin-ajax.php'));
        $paypal_vars['cancel_return'] = add_query_arg(array('bid'=>$booking_id, 'action'=>'vrc_paypal_cancel'), admin_url('admin-ajax.php'));
        $paypal_vars['notify_url'] = add_query_arg(array('bid'=>$booking_id, 'action'=>'vrc_paypal_notify'), admin_url('admin-ajax.php'));

        $paypal_url = 'https://www.paypal.com/cgi-bin/webscr';

        if($VRCalendarSettings->getSettings('payment_mode') == 'sandbox')
            $paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';

        $paypal_url = $paypal_url.'?'.http_build_query($paypal_vars);
        header('location:'.$paypal_url);
        exit;
    }

    function saveBooking() {		
        $VRCalendarSettings = VRCalendarSettings::getInstance();
        $VRCalendarBooking = VRCalendarBooking::getInstance();
        $VRCalendarEntity = VRCalendarEntity::getInstance();

        $cal_data = $VRCalendarEntity->getCalendar( $_POST['cal_id'] );
        $cdate = date('Y-m-d H:i:s');
        $booking_price = $VRCalendarEntity->getBookingPrice($_POST['cal_id'], $_POST['booking_checkin_date'], $_POST['booking_checkout_date']);

        $booking_status = 'pending';
        $booking_payment_status = 'pending';
        /* Check id payment is required */
        $redirect_page =  'payment_page';
        $booking_admin_approved = 'yes';
        if($cal_data->calendar_requires_admin_approval == 'yes') {
            $booking_admin_approved = 'no';
        }
        if($cal_data->calendar_payment_method == 'none') {
            $redirect_page =  'thank_you_page';
            $booking_payment_status = 'not_required';
            if($cal_data->calendar_requires_admin_approval == 'no') {
                $booking_status = 'confirmed';
            }
        } else {
            /* check if admin approval is needed */
            if($cal_data->calendar_requires_admin_approval == 'yes') {
                $redirect_page =  'thank_you_page';
            }
        }       
        $booking_data = array(
            'booking_calendar_id'=>$_POST['cal_id'],
            'booking_source'=>'website',
            'booking_date_from'=>$_POST['booking_checkin_date'],
            'booking_date_to'=>$_POST['booking_checkout_date'],
            'booking_guests'=>$_POST['booking_guests_count'],
            'booking_user_fname'=>$_POST['user_first_name'],
            'booking_user_lname'=>$_POST['user_last_name'],
            'booking_user_email'=>$_POST['user_email'],
            'booking_summary'=>$_POST['booking_note'],
            'booking_status'=>$booking_status,
            'booking_payment_status'=>$booking_payment_status,
            'booking_admin_approved'=>$booking_admin_approved,
            'booking_sub_price'=>$booking_price,
            'booking_total_price'=>$booking_price['booking_price_with_taxes'],
            'booking_created_on'=>$cdate,
            'booking_modified_on'=>$cdate
        );
        $booking_id = $VRCalendarBooking->saveBooking( $booking_data );
        /* Now send user on Next screen with payment Id */
        $payment_page = add_query_arg(array('bid'=>$booking_id), get_permalink($VRCalendarSettings->getSettings($redirect_page)) );
        wp_redirect($payment_page);
        exit;
    }

    function getUpdatedPrice() {
        $VRCalendarEntity = VRCalendarEntity::getInstance();

        $cal_id = $_POST['cal_id'];
        $checkin_date = $_POST['checkin_date'];
        $checkout_date = $_POST['checkout_date'];

        $booking_price = $VRCalendarEntity->getBookingPrice($cal_id, $checkin_date, $checkout_date);

        echo json_encode($booking_price);
        exit;
    }

    function getAvailableRangeEnd() {
        $VRCalendarBooking = VRCalendarBooking::getInstance();
        $start_date = $_POST['start_date'];
        $cal_id = $_POST['cal_id'];
        $available_till = $VRCalendarBooking->availableTill($cal_id, $start_date);
        echo $available_till;
        exit;
    }

    function initShortcodes() {
        VRCalendarShortcode::getInstance();
        VRCalendarBookingBtnShortcode::getInstance();
		// .........add searchbars........................start..........................
        global $gbversiontype;
        if (($gbversiontype == "enterprisepaid") or ($gbversiontype == "enterprise500")){
            VRCalendarSearchbarShortcode::getInstance();
        }
		// .... ....add searchbars.......................end..........................
        VRBookingShortcode::getInstance();
        VRPaymentShortcode::getInstance();
        VRThankyouShortcode::getInstance();
    }

    /**
     * Load the plugin text domain for translation.
     *
     * @since    1.0.0
     */
    function loadPluginTextdomain() {
        $domain = VRCALENDAR_PLUGIN_SLUG;
        $locale = apply_filters( 'plugin_locale', get_locale(), $domain );

        load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' );
        load_plugin_textdomain( $domain, FALSE, basename( plugin_dir_path( dirname( __FILE__ ) ) ) . '/Languages/' );
    }

    /**
     * Register and enqueue public-facing style sheet.
     *
     * @since    1.0.0
     */
    public function enqueueStyles()
    {
        wp_enqueue_style( VRCALENDAR_PLUGIN_SLUG . '-bootstrap-styles', VRCALENDAR_PLUGIN_URL.'assets/css/bootstrap.css', array(), self::VERSION );
        wp_enqueue_style( VRCALENDAR_PLUGIN_SLUG . '-owl-carousel-main', VRCALENDAR_PLUGIN_URL.'assets/plugins/owl-carousel/owl.carousel.css', array(), self::VERSION );
        wp_enqueue_style( VRCALENDAR_PLUGIN_SLUG . '-owl-carousel-theme', VRCALENDAR_PLUGIN_URL.'assets/plugins/owl-carousel/owl.theme.css', array(), self::VERSION );
        wp_enqueue_style( VRCALENDAR_PLUGIN_SLUG . '-owl-carousel-transitions', VRCALENDAR_PLUGIN_URL.'assets/plugins/owl-carousel/owl.transitions.css', array(), self::VERSION );
        wp_enqueue_style( VRCALENDAR_PLUGIN_SLUG . '-calendar-styles', VRCALENDAR_PLUGIN_URL.'assets/css/calendar.css', array(), self::VERSION );
        wp_enqueue_style('jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');
        wp_enqueue_style( VRCALENDAR_PLUGIN_SLUG . '-plugin-styles', VRCALENDAR_PLUGIN_URL.'assets/css/public.css', array(), self::VERSION );
    }

    /**
     * Register and enqueues public-facing JavaScript files.
     *
     * @since    1.0.0
     */
    public function enqueueScripts()
    {
        $VRCalendarSettings = VRCalendarSettings::getInstance();
        wp_enqueue_script( VRCALENDAR_PLUGIN_SLUG . '-form-script', VRCALENDAR_PLUGIN_URL.'assets/plugins/jquery.form.min.js', array( 'jquery' ), self::VERSION );
        wp_enqueue_script( VRCALENDAR_PLUGIN_SLUG . '-bootstrap-script', VRCALENDAR_PLUGIN_URL.'assets/js/bootstrap.js', array( 'jquery' ), self::VERSION );
        wp_enqueue_script( VRCALENDAR_PLUGIN_SLUG . '-owl-carousel-script', VRCALENDAR_PLUGIN_URL.'assets/plugins/owl-carousel/owl.carousel.js', array( 'jquery' ), self::VERSION );
        wp_enqueue_script( VRCALENDAR_PLUGIN_SLUG . '-validation-script', VRCALENDAR_PLUGIN_URL.'assets/plugins/validation/jquery.validate.min.js', array( 'jquery' ), self::VERSION );
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script( VRCALENDAR_PLUGIN_SLUG . '-plugin-script', VRCALENDAR_PLUGIN_URL.'assets/js/public.js', array( 'jquery', 'jquery-ui-datepicker' ), self::VERSION );       
        $vrc_data = array(
            'ajax_url'=>admin_url('admin-ajax.php'),
            'booking_url' => add_query_arg(array('cid'=>'{cid}', 'bdate'=>'{bdate}'), get_permalink($VRCalendarSettings->getSettings('booking_page')) ),
            'thankyou_url' => add_query_arg(array('bid'=>'{bid}'), get_permalink($VRCalendarSettings->getSettings('thank_you_page')) )
        );
        wp_localize_script( VRCALENDAR_PLUGIN_SLUG . '-plugin-script', 'vrc_data', $vrc_data );
    }

    static function activate() {
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $VRCalendarEntity = VRCalendarEntity::getInstance();
        $VRCalendarBooking = VRCalendarBooking::getInstance();
        $VRCalendarSettings = VRCalendarSettings::getInstance();

        $VRCalendarEntity->createTable();
        $VRCalendarBooking->createTable();

        $VRCalendarSettings = VRCalendarSettings::getInstance();
        /* Setup Cal Sync Task */
        wp_schedule_event( time(), $VRCalendarSettings->getSettings('auto_sync', 'daily'), 'vrc_cal_sync_hook' );
        /* Create all required pages */
        $pages = array(
            'booking_page' => array('title'=>'Booking Page', 'content'=>'[vrc_booking /]'),
            'payment_page' => array('title'=>'Payment Page', 'content'=>'[vrc_payment /]'),
            'thank_you_page' => array('title'=>'Thank you', 'content'=>'[vrc_thankyou /]'),
            'payment_cancel_page' => array('title'=>'Payment Cancel', 'content'=>'Your Order is Canceled'),
        );
        foreach($pages as $setting=>$data) {
            $the_page = get_page_by_title( $data['title'] );
            if ( ! $the_page ) {
                $_p = array();
                $_p['post_title'] = $data['title'];
                $_p['post_content'] = $data['content'];
                $_p['post_status'] = 'publish';
                $_p['post_type'] = 'page';
                $_p['comment_status'] = 'closed';
                $_p['ping_status'] = 'closed';
                // Insert the post into the database
                $the_page_id = wp_insert_post( $_p );
            }
            else {
                $the_page_id = $the_page->ID;
                //make sure the page is not trashed...
                $the_page->post_status = 'publish';
                $the_page->post_content = $data['content'];
                $the_page_id = wp_update_post( $the_page );
            }
            $VRCalendarSettings->setSettings($setting, $the_page_id);
        }
    }

    static function deactivate() {
        wp_clear_scheduled_hook( 'vrc_cal_sync_hook' );
    }

}