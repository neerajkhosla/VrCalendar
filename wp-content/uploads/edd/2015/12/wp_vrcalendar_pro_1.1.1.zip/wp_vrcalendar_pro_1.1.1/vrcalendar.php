<?php
/**
 * @package   VR Calendar
 * @author    Author <author@example.com>
 * @license   GPL-2.0+
 * @link      http://example.com
 * @copyright Innate Images LLC
 *
 * @wordpress-plugin
 * Plugin Name:		  VR Calendar Pro
 * Plugin URI:        http://www.vrcalendarsync.com/
 * Description:       VR Calendar plugin
 * Version:           1.1.1
 * Author:            Innate Images, LLC
 * Author URI:
 * Text Domain:       vr-calendar-locale
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

define("VRCALENDAR_PLUGIN_DIR",addslashes(dirname(__FILE__)));
$pinfo = pathinfo(VRCALENDAR_PLUGIN_DIR);
define("VRCALENDAR_PLUGIN_FILE",addslashes(__FILE__));
define("VRCALENDAR_PLUGIN_URL",plugins_url().'/'.$pinfo['basename'].'/');

define("VRCALENDAR_PLUGIN_NAME",'VR Calendar');
define("VRCALENDAR_PLUGIN_SLUG",'vr-calendar');

require_once( VRCALENDAR_PLUGIN_DIR . '/Includes/Init.php' );

if(!function_exists('renderCurrency')) {
	function renderCurrency(){
		$VRCalendarSettings = VRCalendarSettings::getInstance();
		$currency = $VRCalendarSettings->getSettings('attr_currency');
		switch($currency){
			//case 'CAD':
			case 'USD':
			//case 'AUD':
				return '$';
			break;

			//case 'GBP':
			//	return '�';
			//break;
			//case 'EUR':
			//	return '�';
			//break;
			default:
				return $currency.' ';
				break;
		}
	}
}