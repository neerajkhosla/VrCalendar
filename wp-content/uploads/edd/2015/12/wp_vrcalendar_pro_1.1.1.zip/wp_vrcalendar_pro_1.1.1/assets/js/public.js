jQuery(document).ready(function ($){
    $.validator.setDefaults({
        highlight: function(element) {
            $(element).closest('.form-group').addClass('has-error');
        },
        unhighlight: function(element) {
            $(element).closest('.form-group').removeClass('has-error');
        },
        errorElement: 'span',
        errorClass: 'help-block',
        errorPlacement: function(error, element) {
            if(element.parent('.input-group').length) {
                error.insertAfter(element.parent());
            } else {
                error.insertAfter(element);
            }
        }
    });
    $('.vrc-validate').each(function (e){
        $(this).validate({

        });
    });
    $('#vrc-stripe-payment-form').ajaxForm({
        url: vrc_data.ajax_url,
        beforeSubmit: function (formData, jqForm, options) {
            //console.log(formData);
        },
        success: function (responseText, statusText, xhr, $form){
            var response = JSON.parse(responseText);
            if(response.result == 'success'){
                var thankyou_url = vrc_data.thankyou_url;
                var redirect_url = thankyou_url.replace('{bid}', response.bid);
                window.location = redirect_url;
            }
            else {
                $('#vrc-payment-error').html(response.msg);
                $('#vrc-payment-error').removeClass('hidden');
            }
        }
    });
    $(".vrc-calendar .calendar-slides").owlCarousel({
        singleItem:true,
        navigation:false,
        pagination:false,
        autoHeight:true
    });
    $(".vrc-calendar .btn-prev").click(function(){
        var parent = $(this).parent().parent().parent().parent().parent().parent();
        $(".calendar-slides", parent).trigger('owl.prev');
    });
    $(".vrc-calendar .btn-next").click(function(){
        var parent = $(this).parent().parent().parent().parent().parent().parent();
        $(".calendar-slides", parent).trigger('owl.next');
    });
    $(".vrc.vrc-calendar.vrc-calendar-booking-yes .day-number.no-event-day").click(function (e){
        var booking_url = vrc_data.booking_url;
        var cid = jQuery(this).attr('data-calendar-id');
        var bdate = jQuery(this).attr('data-booking-date');		
        var redirect_url = booking_url.replace('{cid}', cid);
        redirect_url = redirect_url.replace('{bdate}', bdate);		
        window.location = redirect_url;
    });
    $('#booking_checkin_date').datepicker({
        dateFormat : 'yy-mm-dd',
        minDate: -0,
        maxDate: "+3Y",
        beforeShowDay: function(date){
            /* disable unavailable dates */
            var booked_dates = jQuery('#booked_dates').val();
            booked_dates = JSON.parse(booked_dates);
            //console.log(booked_dates);
            var string = jQuery.datepicker.formatDate('yy-mm-dd', date);
            return [$.inArray(string, booked_dates) == -1];
        },
        onClose: function( selectedDate, inst ) {
            /* Make ajax call for get max selectable date */
            var data = {
                'action': 'get_available_range_end',
                'cal_id': $('#cal_id').val(),
                'start_date': selectedDate
            };
            //$( "#booking_checkout_date" ).datepicker( "option", "minDate", selectedDate );
            var minDate = new Date(selectedDate);
            minDate.setDate(minDate.getDate() + 1);
            var minDateStr = $.datepicker.formatDate('yy-mm-dd', minDate);
            $( "#booking_checkout_date" ).datepicker( "option", "minDate", minDateStr );
            $.post(vrc_data.ajax_url, data, function(response) {
                //console.log(response);
                $( "#booking_checkout_date" ).datepicker( "option", "maxDate", response );
            });
            updatePrice();
        }
    });
    $('#booking_checkout_date').datepicker({
        dateFormat : 'yy-mm-dd',
        minDate: -0,
        maxDate: "+3Y",
        onClose: function( selectedDate ) {
            //$( "#booking_checkin_date" ).datepicker( "option", "maxDate", selectedDate );
            updatePrice();
        }
    });
    var selectedDate = $('#booking_checkin_date').val();
    var minDate = new Date(selectedDate);
    minDate.setDate(minDate.getDate() + 1);
    var minDateStr = $.datepicker.formatDate('yy-mm-dd', minDate);
    $( "#booking_checkout_date" ).datepicker( "option", "minDate", minDateStr );
    var data = {
        'action': 'get_available_range_end',
        'cal_id': $('#cal_id').val(),
        'start_date': selectedDate
    };
    $.post(vrc_data.ajax_url, data, function(response) {
        console.log(response);
        $( "#booking_checkout_date" ).datepicker( "option", "maxDate", response );
    });
	// .................added searchbars..............................start...........................
   /* jQuery('.vrc-calendar-searchbar').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: -0,
        maxDate: "+3Y"
    });*/
	jQuery('#searchbar_checkindate').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: -0,
        maxDate: "+3Y",    
		onClose: function( selectedDate ) {
            var minDate = new Date(selectedDate);
			minDate.setDate(minDate.getDate() + 1);
			var minDateStr = $.datepicker.formatDate('yy-mm-dd', minDate);
			$( "#searchbar_checkoutdate" ).datepicker( "option", "minDate", minDateStr );
        }	
	});
	jQuery('#searchbar_checkoutdate').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: -0,
        maxDate: "+3Y",
		onClose: function( selectedDate ) {
		$( "#searchbar_checkindate" ).datepicker( "option", "maxDate", selectedDate );
		}
	});
    // .................added searchbars..............................end...........................
});
function updatePrice() {
    var data = {
        'action': 'get_updated_price',
        'cal_id': jQuery('#cal_id').val(),
        'checkin_date': jQuery('#booking_checkin_date').val(),
        'checkout_date': jQuery('#booking_checkout_date').val()
    };
    jQuery.post(vrc_data.ajax_url, data, function(response) {
        var price_data = JSON.parse(response);
        //console.log(price_data);
        jQuery('#price-per-night').html(price_data.price_per_night);
        jQuery('#table-price-per-night').html(price_data.price_per_night);
        jQuery('#table-booking-days').html(price_data.booking_days);
        jQuery('#table-base-booking-price').html(price_data.base_booking_price);
        jQuery('#table-cleaning-fee').html(price_data.cleaning_fee);
        jQuery('#table-tax-amt').html(price_data.tax_amt);
        jQuery('#table-booking-price-with-taxes').html(price_data.booking_price_with_taxes);
    });
}