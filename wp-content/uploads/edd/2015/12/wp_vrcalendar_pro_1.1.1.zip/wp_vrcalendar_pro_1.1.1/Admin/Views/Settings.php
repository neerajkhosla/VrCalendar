<?php
$VRCalendarSettings = VRCalendarSettings::getInstance();
$availablePages = get_pages();
$payment_mode = array(
    'live'=>'Live',
    'sandbox'=>'Sandbox'
);
$auto_sync = array(
    'none'=>'Disable',
    'hourly'=>'Hourly',
    'twicedaily'=>'Twice Daily',
    'daily'=>'Daily'
);
$attribution = array(
    'yes'=>'Yes',
    'no'=>'No'
);
$language = array(
    'english'=>'English',
    'french'=>'French',
    'spanish'=>'Spanish'
);
$attr_currency = array(
	'AUD'=>'Australian Dollar',
	'AED'=> 'United Arab Emirates Dirham',
	'ANG'=> 'Netherlands Antillean Gulden',
	'ALL'=> 'Albanian Lek',
	'ARS'=>'Argentine Peso',
	'AWG'=> 'Aruban Florin',
	'BBD'=>'Barbadian Dollar',
	'BIF'=> 'Burundian Franc',
	'BND'=> 'Brunei Dollar',
	'BRL'=> 'Brazilian Real',
	'BWP'=> 'Botswana Pula',
	'BDT'=> 'Bangladeshi Taka',
	'BMD'=>'Bermudian Dollar',
	'BOB'=> 'Bolivian Boliviano',
	'BSD'=> 'Bahamian Dollar',
	'BZD'=> 'Belize Dollar',
	'CAD'=>'Canadian Dollar',
	'CLP'=>'Chilean Peso',
	'COP'=> 'Colombian Peso',
	'CVE'=> 'Cape Verdean Escudo',
	'CHF'=> 'Swiss Franc',
	'CNY'=> 'Chinese Renminbi Yuan',
	'CRC'=> 'Costa Rican Colon',
	'CZK'=> 'Czech Koruna',
	'DJF'=> 'Djiboutian Franc',
	'DOP'=> 'Dominican Peso',	
	'DKK'=> 'Danish Krone',
	'DZD'=> 'Algerian Dinar',
	'EGP'=> 'Egyptian Pound',
	'EUR'=>'Euros',
	'ETB'=>'Ethiopian Birr',
	'FKP'=> 'Falkland Islands Pound',
	'FJD'=> 'Fijian Dollar',
	'GBP'=> 'British Pound',
	'GIP'=> 'Gibraltar Pound',
	'GNF'=> 'Guinean Franc',
	'GYD'=> 'Guyanese Dollar',
	'GMD'=> 'Gambian Dalasi',
	'GTQ'=> 'Guatemalan Quetzal',
	'HNL'=> 'Honduran Lempira',
	'HTG'=> 'Haitian Gourde',
	'HKD'=> 'Hong Kong Dollar',
	'HRK'=> 'Croatian Kuna',
    'HUF'=> 'Hungarian Forint',
	'IDR'=> 'Indonesian Rupiah',
	'INR'=> 'Indian Rupee',		
	'ILS'=> 'Israeli New Sheqel',
	'ISK'=> 'Icelandic Krona',
	'JMD'=> 'Jamaican Dollar',
	'JPY'=> 'Japanese Yen',
	'KES'=> 'Kenyan Shilling',
	'KMF'=> 'Comorian Franc',
	'KYD'=> 'Cayman Islands Dollar',
	'KHR'=> 'Cambodian Riel',
	'KRW'=> 'South Korean Won',
	'KZT'=> 'Kazakhstani Tenge',
	'LAK'=> 'Lao Kip',
	'LKR'=> 'Sri Lankan Rupee',
	'LBP'=> 'Lebanese Pound',
	'LRD'=> 'Liberian Dollar',
	'MAD'=> 'Moroccan Dirham',
	'MNT'=> 'Mongolian Togrog',
	'MRO'=> 'Mauritanian Ouguiya',
	'MVR'=> 'Maldivian Rufiyaa',
	'MXN'=> 'Mexican Peso',	
	'MDL'=> 'Moldovan Leu',
	'MOP'=> 'Macanese Pataca',
	'MUR'=> 'Mauritian Rupee',
	'MWK'=> 'Malawian Kwacha',
	'MYR'=> 'Malaysian Ringgit',
	'NAD'=> 'Namibian Dollar',
	'NIO'=> 'Nicaraguan Cordoba',
	'NPR'=> 'Nepalese Rupee',
	'NGN'=> 'Nigerian Naira',
	'NOK'=> 'Norwegian Krone',
	'NZD'=> 'New Zealand Dollar',
	'PAB'=> 'Panamanian Balboa',
	'PGK'=> 'Papua New Guinean Kina',
	'PKR'=>'Pakistani Rupee',
	'PYG'=> 'Paraguayan Guarani',
	'PEN'=> 'Peruvian Nuevo Sol',
	'PHP'=> 'Philippine Peso',
	'PLN'=> 'Polish Zloty',
	'QAR'=> 'Qatari Riyal',
	'RUB'=> 'Russian Ruble',
	'SBD'=> 'Solomon Islands Dollar',
	'SEK'=> 'Swedish Krona',
	'SHP'=>'Saint Helenian Pound',
	'SOS'=> 'Somali Shilling',
	'SVC'=> 'Salvadoran Colon',
	'SAR'=> 'Saudi Riyal',
	'SCR'=> 'Seychellois Rupee',
	'SGD'=> 'Singapore Dollar',
	'SLL'=> 'Sierra Leonean Leone',
	'STD'=> 'Sao Tome and Principe Dobra',
	'SZL'=> 'Swazi Lilangeni',
	'THB'=> 'Thai Baht',
	'TTD'=> 'Trinidad and Tobago Dollar',
	'TZS'=> 'Tanzanian Shilling',	
	'TOP'=> 'Tongan Paanga',
	'TWD'=> 'New Taiwan Dollar',
	'UGX'=> 'Ugandan Shilling',
	'UYU'=> 'Uruguayan Peso',
	'UAH'=> 'Ukrainian Hryvnia',
	'USD'=> 'United States Dollar',
	'UZS'=> 'Uzbekistani Som',
	'VND'=> 'Vietnamese Dong',
	'VUV'=> 'Vanuatu Vatu',
	'WST'=> 'Samoan Tala',
	'XOF'=> 'West African Cfa Franc',	
	'XAF'=> 'Central African Cfa Franc',
	'XPF'=> 'Cfp Franc',
	'YER'=> 'Yemeni Rial',
	'ZAR'=> 'South African Rand'
);    
?>
<div class="wrap">
    <h2>Settings</h2>
    <div class="tabs-wrapper">
        <h2 class="nav-tab-wrapper">
            <a class='nav-tab nav-tab-active' href='#general-options'>General</a>
        </h2>
        <div class="tabs-content-wrapper">
            <form method="post" action="" >
                <div id="general-options" class="tab-content tab-content-active">
                    <?php require(VRCALENDAR_PLUGIN_DIR.'/Admin/Views/Part/Settings/General.php'); ?>
                </div>
                <div>
                    <input type="hidden" name="vrc_cmd" id="vrc_cmd" value="VRCalendarAdmin:saveSettings" />
                    <input type="submit" value="Save" class="button button-primary">
                </div>
            </form>
        </div>
    </div>
</div>