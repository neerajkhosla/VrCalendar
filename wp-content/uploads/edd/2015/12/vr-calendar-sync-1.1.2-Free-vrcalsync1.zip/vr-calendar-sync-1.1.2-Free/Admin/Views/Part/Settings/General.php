<table class="form-table">
    <tbody>
    <tr valign="top">
        <th>
            Auto Sync
        </th>
        <td>
            <select id="auto_sync" name="auto_sync" class="large-text">
                <?php foreach($auto_sync as $val=>$text):
                    $selected = '';
                    if( $val == $VRCalendarSettings->getSettings('auto_sync', 'daily') )
                        $selected = 'selected="selected"';
                    ?>
                    <option value="<?php echo $val; ?>" <?php echo $selected; ?>><?php echo $text; ?></option>
                <?php endforeach; ?>
            </select>
        </td>
    </tr>
<?php if ($gbversiontype != "freevrcalsync"){ ?>
    <tr valign="top">
        <th>
            Show Attribution Link Below Calendar?
        </th>
        <td>
            <select id="attribution" name="attribution" class="large-text">
                <?php foreach($attribution as $val=>$text):
                    $selected = '';
                    if( $val == $VRCalendarSettings->getSettings('attribution') )
                        $selected = 'selected="selected"';
                    ?>
                <option value="<?php echo $val; ?>" <?php echo $selected; ?>><?php echo $text; ?></option>
                <?php endforeach; ?>
            </select>
        </td>
    </tr>
<?php
//end if !$gbversiontype == "freevrcalsync"
 } ?>

    <tr valign="top">
    <th>
        Select a Language
    </th>
    <td>
        <select id="language" name="language" class="large-text">
            <?php foreach($language as $val=>$text):
                $selected = '';
                if( $val == $VRCalendarSettings->getSettings('language') )
                    $selected = 'selected="selected"';
            ?>
            <option value="<?php echo $val; ?>" <?php echo $selected; ?>><?php echo $text; ?></option>
            <?php endforeach; ?>
        </select>
    </td>
    </tr>
    </tbody>
</table>