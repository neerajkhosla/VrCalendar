<?php
class VRCalendarSearchbarResultShortcode extends VRCShortcode {

    protected $slug = 'vrcalendar_searchbar_result';

    function shortcode_handler($atts, $content = "") {        
		global $wpdb;
        $this->atts = shortcode_atts(array(
                'id'=>false,                
            ),
           $atts, 'vrcalendar_searchbar_result');		
        if(isset($_POST['submit_searchbar'])){
            $VRCalendarEntity = VRCalendarEntity::getInstance();
			$searchbar_id =$_POST['searchbar_id'];
			$data = $VRCalendarEntity->getSearchbar($searchbar_id); 

			$checkindate   = $_POST['checkindate'];
			$checkoutdate  = $_POST['checkoutdate'];
			$guest         = ($_POST['totalguests'])?$_POST['totalguests']:0;
			$bpricemin     = (isset($_POST['searchbar_booking_price_min']))? $_POST['searchbar_booking_price_min']:10;
			$bpricemax     = (isset($_POST['searchbar_booking_price_max']))? $_POST['searchbar_booking_price_max']:500;
			
			$precals=array();
			foreach($data->calendars as $k=>$v){
				$precals[]= $k;
			}
			$resultoutput = '<table class="table table-hover booking-list">
					<thead>
						<tr><th>Calendar Name</th><th>Listing Detail</th><th>Booking Price</th><th>Booking Link</th>	</tr>
					</thead>
					<tbody>	';				
			$count =0;
			foreach($precals as $v){
				$cal_data = $VRCalendarEntity->getCalendar( $v );
				
				$guest_no = $cal_data->calendar_max_guest_no;
				if($guest <= $guest_no){					
					$booking_price = $cal_data ->calendar_price_per_night;
					$tax = $cal_data->calendar_tax_per_stay;
					$tax_type = $cal_data->calendar_tax_type;
					$tax_amt = $tax;
					if($data->use_price_filter == 'yes'){
						if($booking_price >= $_POST['searchbar_booking_price_min'] && $booking_price <= $_POST['searchbar_booking_price_max']){ 
							$VRCalendarBooking = VRCalendarBooking::getInstance();
                            $item = $VRCalendarBooking->isDateRangeAvailableNew($cal_data, $_POST['checkindate'], $_POST['checkoutdate'], $_POST['checkindate']);
							if($item == 'T'){
								$calname = ($cal_data->calendar_name !='')?$cal_data->calendar_name:'No Name';
								$isbookingenable = $cal_data->calendar_enable_booking;
								$bookingdata = 'Booking is disabled ';
								if($isbookingenable == 'yes'){
								    $totaladditionalcharge = 0;
									$max_guest_no     = $cal_data->calendar_max_guest_no;
									$guest_limit      = $cal_data->calendar_extracharge_after_guest_no;
									$additionalcharge = $cal_data->calendar_extracharge_after_limited_guests;
									if($guest > $guest_limit){
									   $increasedguests = $guest - $guest_limit;
									   $totaladditionalcharge = $increasedguests * $additionalcharge;
									}
								    $bookingdata ="Default Price Per Night : ".renderCurrency()." $cal_data->calendar_price_per_night <br/> "; 

                                    if($totaladditionalcharge > 0)
									$bookingdata .=	 "Extra Guest Fees Per Night : ".renderCurrency(). number_format($totaladditionalcharge, 2)." <br/>";

									$bookingdata .=	 "Cleaning Fee Per Stay  : ".renderCurrency()." $cal_data->calendar_cfee_per_stay <br/>Extra Fees : ".renderCurrency()." $cal_data->calendar_extra_fees";
								}
								$VRCalendarSettings = VRCalendarSettings::getInstance();
								$bdate = date('Y-m-d');
								$booking_url = add_query_arg(array('cid'=>$v, 'sbcindate'=>$checkindate, 'sbcoutdate'=>$checkoutdate, 'gno'=>$guest), get_permalink($VRCalendarSettings->getSettings('booking_page')) );
								
								$bookinglink = "<a href='{$booking_url}'>Book Now</a>";
								$resultoutput.= "<tr><td>$calname</td><td>";
								$calendar_booking_url = $cal_data->calendar_booking_url;
								if($calendar_booking_url){
									$resultoutput.= "<a href='".$calendar_booking_url."'>Listing Detail</a>";
								}else{
									$resultoutput.= "N/A";
								}
								$resultoutput.= "</td><td>$bookingdata</td><td>";
								if($isbookingenable == 'yes'){ $resultoutput.= $bookinglink;}else{
									$resultoutput.= "Booking is disabled";
								}
								$resultoutput.= "</td></tr>";
							$count++;}
						}
				    }else{
						$VRCalendarBooking = VRCalendarBooking::getInstance();					
						$item = $VRCalendarBooking->isDateRangeAvailableNew($cal_data, $_POST['checkindate'], $_POST['checkoutdate'], $_POST['checkindate']);	

						if($item == 'T'){						          
							$calname = ($cal_data->calendar_name !='')?$cal_data->calendar_name:'No Name';
							$isbookingenable = $cal_data->calendar_enable_booking;
							$bookingdata = 'Booking is disabled ';
							if($isbookingenable == 'yes'){
							        $totaladditionalcharge = 0;
									$max_guest_no     = $cal_data->calendar_max_guest_no;
									$guest_limit      = $cal_data->calendar_extracharge_after_guest_no;
									$additionalcharge = $cal_data->calendar_extracharge_after_limited_guests;
									if($guest > $guest_limit){
									   $increasedguests = $guest - $guest_limit;
									   $totaladditionalcharge = $increasedguests * $additionalcharge;
									}
								    $bookingdata ="Default Price Per Night : ".renderCurrency()." $cal_data->calendar_price_per_night <br/> "; 

                                    if($totaladditionalcharge > 0)
									$bookingdata .=	 "Extra Guest Fees Per Night : ".renderCurrency(). number_format($totaladditionalcharge, 2)." <br/>";

									$bookingdata .=	 "Cleaning Fee Per Stay  : ".renderCurrency()." $cal_data->calendar_cfee_per_stay <br/>Extra Fees : ".renderCurrency()." $cal_data->calendar_extra_fees";
							}
							$VRCalendarSettings = VRCalendarSettings::getInstance();
							$bdate = date('Y-m-d');
							$booking_url = add_query_arg(array('cid'=>$v, 'sbcindate'=>$checkindate, 'sbcoutdate'=>$checkoutdate, 'gno'=>$guest), get_permalink($VRCalendarSettings->getSettings('booking_page')) );
							
							$bookinglink = "<a href='{$booking_url}'>Book Now</a>";
							$resultoutput.= "<tr><td>$calname</td><td>";
							$calendar_booking_url = $cal_data->calendar_booking_url;
							if($calendar_booking_url){
								$resultoutput.= "<a href='".$calendar_booking_url."'>Listing Detail</a>";
							}else{
								$resultoutput.= "N/A";
							}
							$resultoutput.= "</td><td>$bookingdata</td><td>";
							if($isbookingenable == 'yes'){ $resultoutput.= $bookinglink;}else{
								$resultoutput.= "Booking is disabled";
							}
							$resultoutput.= "</td></tr>";
						$count++;}
					}
			   }
			}
			if($count < 1){
                $resultoutput.= "<tr><td colspan ='4'>Sorry! No results found. Please search again.</td></tr>";
			}
			$resultoutput.= "</tbody></table>";
			return "<div class='vrc row' style='width:100%;float:left;'>".$resultoutput."</div>";
		}
		return '';
    }    
}