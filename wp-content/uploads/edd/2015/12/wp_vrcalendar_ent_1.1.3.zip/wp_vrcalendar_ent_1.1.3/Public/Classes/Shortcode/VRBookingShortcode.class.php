<?php
class VRBookingShortcode extends VRCShortcode {

    protected $slug = 'vrc_booking';

    function shortcode_handler($atts, $content = "") {

        if(!$_GET['cid'])
            return 'Calendar id is missing';

        $VRCalendarBooking = VRCalendarBooking::getInstance();
        $VRCalendarEntity = VRCalendarEntity::getInstance();

        $cal_id = $_GET['cid'];
        $checkin = (isset($_GET['bdate'])) ? $_GET['bdate'] : date('Y-m-d');

        $cal_data = $VRCalendarEntity->getCalendar( $cal_id );

        if($cal_data->calendar_enable_booking != 'yes')
            return 'Bookings are disabled.';

        while(!$VRCalendarBooking->isDateAvailable($cal_data, $checkin)) {
            $checkin = date('Y-m-d', strtotime("+1 day", strtotime($checkin)));
        }
        $checkout = date('Y-m-d', strtotime("+1 day", strtotime($checkin)));

        if(isset($_GET['sbcindate']) && isset($_GET['sbcoutdate'])){
            $checkin  = $_GET['sbcindate'];
            $checkout = $_GET['sbcoutdate'];			
		}
        $total_guest_no = 1;
		if(isset($_GET['gno']))
		$total_guest_no = $_GET['gno'];
        $booking_price = $VRCalendarEntity->getBookingPrice($cal_id, $checkin, $checkout, $total_guest_no);

        $tax_type = $cal_data->calendar_tax_type;
        $tax = $cal_data->calendar_tax_per_stay;
        if($tax_type == "percentage") {
            $tax = ($cal_data->calendar_price_per_night * $tax)/100;
        }
        $booked_dates = $VRCalendarBooking->getBookedDates($cal_data);      
        $data = array(
            'calendar_data'=>$cal_data,
            'booking_price'=>$booking_price,
            'check_in_date'=>$checkin,
            'check_out_date'=>$checkout,
            'booked_dates'=>$booked_dates,
			'total_guest_no'=> $total_guest_no
        );
        return $this->renderView('Booking', $data);

    }
}