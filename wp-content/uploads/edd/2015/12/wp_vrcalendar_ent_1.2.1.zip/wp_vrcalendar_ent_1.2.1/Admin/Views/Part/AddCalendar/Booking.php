<table class="form-table">
    <tbody>
        <tr valign="top">
            <th>
                Enable Booking?
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($enable_booking as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_enable_booking)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_enable_booking" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>
		<tr valign="top">
            <th>
                Booking URL
            </th>
            <td>
                <input type="text" id="calendar_booking_url" name="calendar_booking_url" value="<?php echo $cdata->calendar_booking_url; ?>" class="large-text" placeholder="Booking Url">
            </td>
        </tr>
		<tr valign="top">
            <th> 
                Listing Image
            </th>
            <td> <button class="button" type="button" onclick="open_media_uploader_image()"> Add/Edit Image</button>
			<?php if($cdata->calendar_listing_image !=''){ ?>
			    <img style= "width:200px;height:auto;" id="calendar_listingimage" src="<?php echo $cdata->calendar_listing_image; ?>">
			<?php }else{ ?>
			     <img style= "width:200px;height:auto;display:none;" id="calendar_listingimage" src="<?php echo $cdata->calendar_listing_image; ?>">
			<?php } ?>
                <input type="hidden" id="calendar_listing_image" name="calendar_listing_image" value="<?php echo $cdata->calendar_listing_image; ?>" >
            </td>
        </tr>
		<tr valign="top">
            <th> Listing Address
            </th>
            <td>
                <input type="text" id="calendar_listing_address" name="calendar_listing_address" value="<?php echo $cdata->calendar_listing_address; ?>" class="large-text" placeholder="Listing Address">
            </td>
        </tr>
		<tr valign="top">
            <th>
               Summary
            </th>
            <td><?php wp_editor( $cdata->calendar_summary, 'calendar_summary', $settings = array('textarea_name' => 'calendar_summary') ); ?>               
            </td>
        </tr>
        <tr valign="top">
            <th>
                Default Price Per Night
            </th>
            <td>
                <input type="text" id="calendar_price_per_night" name="calendar_price_per_night" value="<?php echo $cdata->calendar_price_per_night; ?>" class="large-text" placeholder="Price Per Night">
            </td>
        </tr>
		<tr valign="top">
            <th>
                Offer Weekly Price?
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($offer_weekly as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_offer_weekly)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_offer_weekly" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>
		<tr valign="top"  id="weekly_row">
            <th>
                Weekly Price
            </th>
            <td>
                 <input type="text" id="calendar_price_weekly" name="calendar_price_weekly" value="<?php echo $cdata->calendar_price_weekly; ?>" class="large-text" placeholder="Weekly Price">
            </td>
        </tr>
		<tr valign="top">
            <th>
                Offer Monthly Price?
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($offer_monthly as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_offer_monthly)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_offer_monthly" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>
		<tr valign="top" id="monthly_row">
            <th>
                Monthly Price
            </th>
            <td>
                 <input type="text" id="calendar_price_monthly" name="calendar_price_monthly" value="<?php echo $cdata->calendar_price_monthly; ?>" class="large-text" placeholder="Monthly Price">
            </td>
        </tr>
        <tr valign="top">
            <th>
                Cleaning Fee Per Stay
            </th>
            <td>
                <input type="text" id="calendar_cfee_per_stay" name="calendar_cfee_per_stay" value="<?php echo $cdata->calendar_cfee_per_stay; ?>" class="large-text" placeholder="Cleaning Fee Per Stay">
            </td>
        </tr>
        <tr valign="top">
            <th>
                Taxes Per Stay
            </th>
            <td>
                <input type="text" id="calendar_tax_per_stay" name="calendar_tax_per_stay" value="<?php echo $cdata->calendar_tax_per_stay; ?>" class="large-text" placeholder="Taxes Per Stay">
            </td>
        </tr>
		<tr valign="top">
            <th>
                Max Guests No.
            </th>
            <td>
                <input type="text" id="calendar_max_guest_no" name="calendar_max_guest_no" value="<?php echo $cdata->calendar_max_guest_no; ?>" class="large-text" placeholder="Maximum No. of Guests">
            </td>
        </tr>
		<tr valign="top">
            <th>
                Charge Extra after Guests No.
            </th>
            <td>
                <input type="text" id="calendar_extracharge_after_guest_no" name="calendar_extracharge_after_guest_no" value="<?php echo $cdata->calendar_extracharge_after_guest_no; ?>" class="large-text" placeholder="Charge Extra after X guests">
            </td>
        </tr>		
		<tr valign="top">
            <th>
                 Extra Charge Price
            </th>
            <td>
                <input type="text" id="calendar_extracharge_after_limited_guests" name="calendar_extracharge_after_limited_guests" value="<?php echo $cdata->calendar_extracharge_after_limited_guests; ?>" class="large-text" placeholder="Extra Charge Price">
            </td>
        </tr>
		<tr valign="top">
            <th>
                Extra Fees
            </th>
            <td>
                <input type="text" id="calendar_extra_fees" name="calendar_extra_fees" value="<?php echo $cdata->calendar_extra_fees; ?>" class="large-text" placeholder=" Extra Fees">
            </td>
        </tr>
        <tr valign="top">
            <th>
               Seasonal Pricing
            </th>
            <td>
                <a href="javascript:void(0)" class="add-new-h2" id="add-more-price-exception">Add More</a>
            </td>
        </tr>
        <tr valign="top">
            <td colspan="2" style="padding:0">
                <table class="form-table" id="custom-price">
                    <thead>
                        <tr>
                            <th>
                                Start Date
                            </th>
                            <th>
                                End Date
                            </th>
                            <th>
                                Price per night
                            </th>
							 <th>
                                Price per week
                            </th>
							 <th>
                                Price per month
                            </th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php					
                    if(count($cdata->calendar_price_exception)>0){
                        foreach($cdata->calendar_price_exception as $pException) {
                            ?>
                            <tr>
                                <td>
                                    <input type="text" name="calendar_price_exception[start_date][]" value="<?php echo $pException->start_date; ?>" class="vrc-calendar large-text" placeholder="Start Date" />
                                </td>
                                <td>
                                    <input type="text" name="calendar_price_exception[end_date][]" value="<?php echo $pException->end_date; ?>" class="vrc-calendar large-text" placeholder="End Date" />
                                </td>
                                <td>
                                    <input type="text" name="calendar_price_exception[price_per_night][]" value="<?php echo $pException->price_per_night; ?>" class="large-text" placeholder="Price per night" />
                                </td>
								<td>
                                    <input type="text" name="calendar_price_exception[price_per_week][]" value="<?php echo $pException->price_per_week; ?>" class="large-text" placeholder="Price per week" />
                                </td>
								<td>
                                    <input type="text" name="calendar_price_exception[price_per_month][]" value="<?php echo $pException->price_per_month; ?>" class="large-text" placeholder="Price per month" />
                                </td>
                                <td>
                                    <a href="javascript:void(0)" class="vrc-remove-link">Remove</a>
                                </td>
                            </tr>
                        <?php
                        }
                    }
                    ?>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr valign="top">
            <th>
                Taxes Type
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($tax_type as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_tax_type)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_tax_type" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>
        <tr valign="top">
            <th>
                Payment Method
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($payment_method as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_payment_method)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_payment_method" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>
        <tr valign="top">
            <th>
                Alert to Double Booking?
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($alert_double_booking as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_alert_double_booking)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_alert_double_booking" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>
        <tr valign="top">
            <th>
                Requires Admin Approval?
            </th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text"><span>input type="radio"</span></legend>
                    <?php foreach($requires_admin_approval as $k=>$v):
                        $checked = '';
                        if($k == $cdata->calendar_requires_admin_approval)
                            $checked = 'checked="checked"';
                        ?>
                        <label title='<?php echo $v; ?>'><input type="radio" name="calendar_requires_admin_approval" value="<?php echo $k; ?>" <?php echo $checked; ?> /> <span><?php echo $v; ?></span></label> &nbsp;
                    <?php endforeach; ?>
                </fieldset>
            </td>
        </tr>

    </tbody>
</table>
<table class="form-table" id="price-exception-clone">
    <tbody>
    <tr>
        <td>
            <input type="text" name="calendar_price_exception[start_date][]" value="" class="vrc-calendar large-text" placeholder="Start Date" />
        </td>
        <td>
            <input type="text" name="calendar_price_exception[end_date][]" value="" class="vrc-calendar large-text" placeholder="End Date" />
        </td>
        <td>
            <input type="text" name="calendar_price_exception[price_per_night][]" value="" class="large-text" placeholder="Price per night" />
        </td>
		<td>
            <input type="text" name="calendar_price_exception[price_per_week][]" value="" class="large-text" placeholder="Price per week" />
        </td>
		<td>
            <input type="text" name="calendar_price_exception[price_per_month][]" value="" class="large-text" placeholder="Price per month" />
        </td>
        <td>
            <a href="javascript:void(0)" class="vrc-remove-link">Remove</a>
        </td>
    </tr>
    </tbody>
</table>