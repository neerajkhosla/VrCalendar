jQuery(document).ready( function ($){
    if($('#custom-price tbody tr').length <=0 ) {
        $('#custom-price').hide();
    }
    $('.nav-tab-wrapper .nav-tab').bind('click', function(e){
        e.preventDefault();
        var tabs_parent = $(this).parent().parent('.tabs-wrapper');
        jQuery('.nav-tab-wrapper .nav-tab', tabs_parent).removeClass('nav-tab-active');
        jQuery('.tabs-content-wrapper .tab-content', tabs_parent).removeClass('tab-content-active');

        jQuery(jQuery(this).attr('href')).addClass('tab-content-active');
        jQuery(this).addClass('nav-tab-active');
    });
    $(document).on('click', '.vrc-remove-link', function(e){
        e.preventDefault();
        if(confirm('Are you sure?'))
            $(this).parent().parent().remove();
        if($('#custom-price tbody tr').length <=0 ) {
            $('#custom-price').hide();
        }
    });
    $('#add-more-calendar-links').bind('click', function (e){
        e.preventDefault();
        if($('#calendar-links .calendar_link_row').length>=10) {
            alert('Max 10 links are allowed');
            return;
        }
        var cloned_row = $('#calendar-links-cloner tr').clone( true );
        $('#calendar-links').append(cloned_row);
    });
    $('#add-more-price-exception').bind('click', function (e){
        e.preventDefault();
        $(".vrc-calendar").datepicker("destroy");
        var cloned_row = $('#price-exception-clone tr').clone( true );
        cloned_row.find('.vrc-calendar').each(function() {
            $(this).removeAttr('id').removeClass('hasDatepicker'); // added the removeClass part.
        });
        $('#custom-price').append(cloned_row);
        $('#custom-price').show();
        initDatePicker();
    });
    try {
        initDatePicker();
        $('.vrc-color-picker').wpColorPicker();
    } catch(e){

    }
	// .................added searchbars..............................start...........................
	$('#allcal').click(function(){
        if($(this).is(':checked'))
            $('.searchbar_cals input[type="checkbox"]') .prop('checked', true);
		else
            $('.searchbar_cals input[type="checkbox"]') .prop('checked', false);
	});// .................added searchbars..............................end...........................
});
function initDatePicker() {
    jQuery('.vrc-calendar').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: -0,
        maxDate: "+3Y"
    });
}