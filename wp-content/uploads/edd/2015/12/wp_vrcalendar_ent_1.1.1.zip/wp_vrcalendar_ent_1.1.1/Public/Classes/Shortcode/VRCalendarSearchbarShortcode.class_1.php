<?php
class VRCalendarSearchbarShortcode extends VRCShortcode {

    protected $slug = 'vrcalendar_searchbar';

    function shortcode_handler($atts, $content = "") {
		global $wpdb;
        $this->atts = shortcode_atts(
            array(
                'id'=>false,                
            ),$atts, 'vrcalendar_searchbar');

        if(!$this->atts['id'])
            return 'Searchbar id is missing';		
        $text = (trim(($content))!='')? $content:'Search Properties';
        $VRCalendarEntity = VRCalendarEntity::getInstance();
		$data = $VRCalendarEntity->getSearchbar($this->atts['id']); 
		$precals=array();
		foreach($data->calendars as $k=>$v){
			$precals[]= $k;
		}
	
        if(!empty($data)){
			$checkindate ='';
			$checkoutdate ='';  
			if(isset($_POST['submit_searchbar_'.$this->atts['id']])){
				$checkindate =$_POST['checkindate'];
				$checkoutdate =$_POST['checkoutdate'];
			}
            $output  = '<form method = "POST"><div class ="col-sm-12"style="background-color:'.$data->color_options['search_box_background_color'].';color:'.$data->color_options['search_font_color'].';padding-top:2%;padding-bottom:2%;"><div class="col-sm-2" style="font-size:large">'.$text.' </div><div class="col-sm-3"><input type="text" placeholder = "Check in Date" name="checkindate" id="searchbar_checkindate" value= "'.$checkindate.'" class ="vrc-calendar-searchbar"></div><div class="col-sm-3"><input type="text"  placeholder = "Check Out Date" name="checkoutdate" id="searchbar_checkoutdate" value= "'.$checkoutdate.'" class="vrc-calendar-searchbar"></div>';
			$output .= '<div class="col-sm-2"><select name="totalguests"><option value=""># of Guests</option>';
			foreach(range(1,15) as $v){
                $output .=  '<option value="'.$v.'">'.$v.'</option>';
			}
			$output .=	'</select></div><div class="col-sm-2"><input type="submit" name="submit_searchbar_'.$this->atts['id'].'" value="search" class="submit-search"style="background-color:'.$data->color_options['search_button_color'].' !important;color:'.$data->color_options['search_button_font_color'].' !important;"></div></div></form>';
		}
        echo $output;
		if(isset($_POST['submit_searchbar_'.$this->atts['id']])){?>
		<table class="table table-hover  ">
		<thead>
		<tr><th>Calendar Name</th><th>Listing Detail</th><th>Booking Price</th><th>Booking Link</th>	</tr>
		</thead>
		<tbody>						
			<?php $count =0;
			foreach($precals as $v){
				$cal_data = $VRCalendarEntity->getCalendar( $v );
				$VRCalendarBooking = VRCalendarBooking::getInstance();
				$item =$VRCalendarBooking->isDateRangeAvailable($cal_data, $_POST['checkindate'], $_POST['checkoutdate']);
				if($item){
					$calname = ($cal_data->calendar_name !='')?$cal_data->calendar_name:'No Name';
					$isbookingenable = $cal_data->calendar_enable_booking;
					$bookingdata = 'Booking is disabled ';
					if($isbookingenable == 'yes'){
                    $bookingdata ="Default Price Per Night : $cal_data->calendar_price_per_night <br/> Cleaning Fee Per Stay  : $cal_data->calendar_cfee_per_stay <br/> Taxes Per Stay : $cal_data->calendar_tax_per_stay";
					}
					$VRCalendarSettings = VRCalendarSettings::getInstance();
					$bdate = date('Y-m-d');
					$booking_url = add_query_arg(array('cid'=>$v, 'sbcindate'=>$checkindate, 'sbcoutdate'=>$checkoutdate), get_permalink($VRCalendarSettings->getSettings('booking_page')) );
					$bookinglink = "<a href='{$booking_url}' class='{$this->atts['class']}'>Book Now</a>";
					echo "<tr><td>$calname</td><td>listing url</td><td>$bookingdata</td><td>";
					if($isbookingenable == 'yes'){ echo $bookinglink;}else{
                        echo "Booking is disabled";
					}
					echo "</td></tr>";
				$count++;}
			}
			if($count < 1){
                echo "<tr><td colspan ='4'>Sorry! No results found. Please search again.</td></tr>";
			}
			echo "</tbody></table>";
		}
		
    }

}