<?php
class VRCalendarSearchbarShortcode extends VRCShortcode {

    protected $slug = 'vrcalendar_searchbar';

    function shortcode_handler($atts, $content = "") {
		global $wpdb;
        $this->atts = shortcode_atts(
            array(
                'id'=>false,                
            ),$atts, 'vrcalendar_searchbar');

        if(!$this->atts['id'])
            return 'Searchbar id is missing';	
	
        $text = (trim(($content))!='')? $content:'Search Properties';
        $VRCalendarEntity = VRCalendarEntity::getInstance();
		$data = $VRCalendarEntity->getSearchbar($this->atts['id']); 
		

		$precals=array();
		foreach($data->calendars as $k=>$v){
			$precals[]= $k;
		}
	//	if(is_single()){
			$outputstyle =  '<style>
					.vrc .searchbar input {
						font-size:13px;
					}
					.vrc .searchbar .col-sm-2, .vrc .searchbar .col-sm-3 {
						padding-right:0px;
		            }
					.vrc .searchbar select {
						padding:6px 2px;
						font-size:13px;
						width:100%;
					}
					.vrc .searchbar input[type="submit"] {
						font-size:14px;
						padding:6px 15px;
					}
					.vrc .search-hdr {
						font-size:15px !important;
						padding:0px;
						margin-bottom:10px !important;
					}
					.searchbar {
						margin:10px 0px;
						padding: 0;
					}
					.searchbar .col-sm-3:first-child {
						padding-left:0px !important;
					}
					.vrc .table.booking-list > thead > tr > th {
						font-size:14px;
						vertical-align:top;
					}
					.vrc .booking-list td {
						font-size:14px;
					}
				</style>';
		//} 
        if(!empty($data)){
			$checkindate ='';
			$checkoutdate ='';  
			if(isset($_POST['submit_searchbar_'.$this->atts['id']])){
				$checkindate =$_POST['checkindate'];
				$checkoutdate =$_POST['checkoutdate'];
				$guest = ($_POST['totalguests'])?$_POST['totalguests']:0;
			}
            $output  = '<form method = "POST"><div class ="col-sm-12 searchbar" style="background-color:'.$data->color_options['search_box_background_color'].';color:'.$data->color_options['search_font_color'].';"><div class="col-sm-12 search-hdr" style="font-size:large;margin-bottom:20px;">'.$text.' </div><div class="col-sm-3"><input type="text" placeholder = "Check in Date" name="checkindate" id="searchbar_checkindate" value= "'.$checkindate.'" class ="vrc-calendar-searchbar"></div><div class="col-sm-3"><input type="text"  placeholder = "Check Out Date" name="checkoutdate" id="searchbar_checkoutdate" value= "'.$checkoutdate.'" class="vrc-calendar-searchbar"></div>';
			$output .= '<div class="col-sm-3"><select name="totalguests"><option value=""># of Guests</option>';
			foreach(range(1,15) as $v){
				if($guest == $v) {
					$output .=  '<option value="'.$v.'" selected>'.$v.'</option>';
				} else {
					$output .=  '<option value="'.$v.'" >'.$v.'</option>';
				}
			}
			$output .=	'</select></div><div class="col-sm-3"><input type="submit" name="submit_searchbar_'.$this->atts['id'].'" value="search" class="submit-search"style="background-color:'.$data->color_options['search_button_color'].' !important;color:'.$data->color_options['search_button_font_color'].' !important;"></div></div></form>';
		}
        $formoutput = $output.$outputstyle;
		$resultoutput ="";
		if(isset($_POST['submit_searchbar_'.$this->atts['id']])){
		$resultoutput .= '<table class="table table-hover booking-list">
					<thead>
						<tr><th>Calendar Name</th><th>Listing Detail</th><th>Booking Price</th><th>Booking Link</th>	</tr>
					</thead>
					<tbody>	';				
			$count =0;
			foreach($precals as $v){
				$cal_data = $VRCalendarEntity->getCalendar( $v );
				
				$guest_no = $cal_data->calendar_max_guest_no;
				if($guest <= $guest_no){
				$VRCalendarBooking = VRCalendarBooking::getInstance();
				
				$item = $VRCalendarBooking->isDateRangeAvailable($cal_data, $_POST['checkindate'], $_POST['checkoutdate']);	

				if($item){

					$calname = ($cal_data->calendar_name !='')?$cal_data->calendar_name:'No Name';
					$isbookingenable = $cal_data->calendar_enable_booking;
					$bookingdata = 'Booking is disabled ';
					if($isbookingenable == 'yes'){
                    $bookingdata ="Default Price Per Night : $cal_data->calendar_price_per_night <br/> Cleaning Fee Per Stay  : $cal_data->calendar_cfee_per_stay <br/> Taxes Per Stay : $cal_data->calendar_tax_per_stay";
					}
					$VRCalendarSettings = VRCalendarSettings::getInstance();
					$bdate = date('Y-m-d');
					$booking_url = add_query_arg(array('cid'=>$v, 'sbcindate'=>$checkindate, 'sbcoutdate'=>$checkoutdate), get_permalink($VRCalendarSettings->getSettings('booking_page')) );
					
					$bookinglink = "<a href='{$booking_url}' class='{$this->atts['class']}'>Book Now</a>";
					$resultoutput.= "<tr><td>$calname</td><td>";
					$calendar_booking_url = $cal_data->calendar_booking_url;
					if($calendar_booking_url){
						$resultoutput.= "<a href='".$calendar_booking_url."'>Listing Detail</a>";
					}else{
						$resultoutput.= "N/A";
					}
					$resultoutput.= "</td><td>$bookingdata</td><td>";
					if($isbookingenable == 'yes'){ $resultoutput.= $bookinglink;}else{
                        $resultoutput.= "Booking is disabled";
					}
					$resultoutput.= "</td></tr>";
				$count++;}
			}
			}
			if($count < 1){
                $resultoutput.= "<tr><td colspan ='4'>Sorry! No results found. Please search again.</td></tr>";
			}
			$resultoutput.= "</tbody></table>";
		}
		return "<div class='vrc row' style='width:100%;float:left;'>".$formoutput.$resultoutput."</div>";
    }

}

