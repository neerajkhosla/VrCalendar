<div class="wrap">
    <h2>Add Search Bar</h2>
    <div class="tabs-wrapper">
        <h2 class="nav-tab-wrapper">
            <a class='nav-tab nav-tab-active' href='#general-options'>General</a>            
            <a class='nav-tab' href='#color-options'>Color Options</a>
        </h2>
        <div class="tabs-content-wrapper">
            <form method="post" action="" >
                <div id="general-options" class="tab-content tab-content-active">
				    <table class="form-table">
					<tbody>
						<tr valign="top">
							<th>
								Search Bar Name
							</th>
							<td>
								<input type="text" class="regular-text" value="<?php echo $searchbardata->name;?>" id="searchbarname" name="searchbarname">
							</td>
						</tr>
					</tbody>
				    </table>          
					<table class="form-table">	
                    <?php if(count($cals) > 0){ ?>
                        <tbody>
						<tr valign="top">
							<th colspan ="2">
								Search should reference which calendars?
								</th>
							
						</tr>
						<tr valign="top">
							<th colspan ="2">
								All <input type = "checkbox" id="allcal" name ="allcal">
								</th>
							
						</tr>
					</tbody>
				    </table> 
					<div class ="searchbar_cals" style="margin-left:10px;">
					<table class="form-table">
					<tbody>
					   <?php foreach($cals as $cal){                            
							$calname =($cal->calendar_name != '') ? $cal->calendar_name : "No Name"; ?>
						<tr valign="top">
							<th>
							<?php echo $calname; ?>
							</th>
							<td>
								<?php $precals=array();
							    foreach($searchbardata->calendars as $k=>$v){
                                    $precals[]= $k;
								}							
                                $checked =(in_array($cal->calendar_id, $precals))?'checked="checked"':'';
							 
								echo '<input type = "checkbox" id= "'.$cal->calendar_id.'" name ="calendars['.$cal->calendar_id.']" '. $checked.'>';
							   ?>
							</td>
						</tr>
						<?php }?>
					</tbody>
				    </table> 
					</div>
					<?php }?>
                </div>
                <div id="color-options" class="tab-content">
                    <table class="form-table">
					<tbody>
						<tr valign="top">
							<th>
								Search Button Color
							</th>
							<td>
								<input type="text" name="searchbar_color_options[search_button_color]" value="<?php echo $searchbardata->color_options['search_button_color']; ?>" class="vrc-color-picker" data-default-color="<?php echo $searchbardata->color_options['search_button_color']; ?>">
							</td>
						</tr>
						<tr valign="top">
							<th>
								Search Button Font Color
							</th>
							<td>
								<input type="text" name="searchbar_color_options[search_button_font_color]" value="<?php echo $searchbardata->color_options['search_button_font_color']; ?>" class="vrc-color-picker" data-default-color="<?php echo $searchbardata->color_options['search_button_font_color']; ?>">
							</td>
						</tr>
						<tr valign="top">
							<th>
							   Search Font Color
							</th>
							<td>
								<input type="text" name="searchbar_color_options[search_font_color]" value="<?php echo $searchbardata->color_options['search_font_color']; ?>" class="vrc-color-picker" data-default-color="<?php echo $searchbardata->color_options['search_font_color']; ?>">
							</td>
						</tr>
						<tr valign="top">
							<th>
								Search Box Background Color
							</th>
							<td>
								<input type="text" name="searchbar_color_options[search_box_background_color]" value="<?php echo $searchbardata->color_options['search_box_background_color']; ?>" class="vrc-color-picker" data-default-color="<?php echo $searchbardata->color_options['search_box_background_color']; ?>">
							</td>
						</tr>
						
					</tbody>
				</table> 
                </div>
                <div> 
				    <input type="hidden" name="created_on" value="<?php echo $searchbardata->created_on; ?>" />
					<input type="hidden" name="author" value="<?php echo $searchbardata->author; ?>" />
					<input type="hidden" name="searchbar_id" id="searchbar_id" value="<?php echo $searchbardata->id; ?>" />
                    <input type="submit" value="Update" name = "search_bar_save" class="button button-primary">
                </div>
            </form>
        </div>
    </div>
</div>