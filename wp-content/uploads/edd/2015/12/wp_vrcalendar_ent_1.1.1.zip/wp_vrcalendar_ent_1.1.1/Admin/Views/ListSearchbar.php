<?php
	$allsearchbars = $VRCalendarEntity->getAllSearchbar();
 ?>
<div class="wrap">
    <h2>
    My Search Bars <a href="<?php echo admin_url('admin.php?page='.VRCALENDAR_PLUGIN_SLUG.'-add-search-bar&action=add') ?>" class="add-new-h2">Add new</a>
    </h2>
	<?php if(!empty($allsearchbars)){ ?>
	<table class="wp-list-table widefat fixed striped ">
	<thead>
	<tr><th>Title</th><th>Shortcode</th><th>Author</th><th>Date added</th><th>Action</th>	</tr>
	</thead>
	<tbody id="the-list">
        <?php foreach($allsearchbars as $searchbar){ 
		$name ="No Name";
		if($searchbar->name !='')
        $name= $searchbar->name;
		$namewithlink= $name;
		if($searchbar->page_id > 0){$link =get_permalink($searchbar->page_id);$namewithlink="<a target=\"_blank\" href=\"$link\">$name</a>"; }?>
		<tr><td><?php echo $namewithlink; ?></td><td><?php echo '[vrcalendar_searchbar id="'.$searchbar->id.'" /]'; ?></td><td><?php echo get_the_author_meta( 'display_name', $searchbar->author); ?></td><td><?php echo date('m/d/Y',strtotime($searchbar->created_on)); ?></td><td><a href="<?php echo admin_url("admin.php?page=".VRCALENDAR_PLUGIN_SLUG."-add-search-bar&action=edit&searchbar_id=".$searchbar->id); ?>">Edit</a> | <a href="<?php echo  admin_url("admin.php?page=".VRCALENDAR_PLUGIN_SLUG."-add-search-bar&action=del&searchbar_id=".$searchbar->id); ?>">Delete</a> </td></tr> 
		<?php }  ?>
    </tbody>
    </table>
	<?php }else{ ?>
	Sorry! No Searchbar exist. Please <a href="<?php echo admin_url('admin.php?page='.VRCALENDAR_PLUGIN_SLUG.'-add-search-bar&action=add') ?>" >Add new</a>
	<?php } ?>
</div>