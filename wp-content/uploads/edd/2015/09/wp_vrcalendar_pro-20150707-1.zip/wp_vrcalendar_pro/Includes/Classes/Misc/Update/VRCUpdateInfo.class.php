<?php
/**
 * A container class for holding and transforming plugin metadata.
 *
 * @author Innate Images, LLC
 * @copyright 2015
 * @version 1.0
 * @access public
 */
class VRCUpdateInfo {
    //Most fields map directly to the contents of the plugin's info.json file.
    //See the relevant docs for a description of their meaning.
    public $name;
    public $slug;
    public $version;
    public $homepage;
    public $sections;
    public $banners;
    public $download_url;

    public $author;
    public $author_homepage;

    public $requires;
    public $tested;
    public $upgrade_notice;

    public $rating;
    public $num_ratings;
    public $downloaded;
    public $active_installs;
    public $last_updated;

    public $id = 0; //The native WP.org API returns numeric plugin IDs, but they're not used for anything.

    public $filename; //Plugin filename relative to the plugins directory.

    /**
     * Create a new instance of VRCUpdateInfo from JSON-encoded plugin info
     * returned by an external update API.
     *
     * @param string $json Valid JSON string representing plugin info.
     * @param bool $triggerErrors
     * @return VRCUpdateInfo|null New instance of VRCUpdateInfo, or NULL on error.
     */
    public static function fromJson($json, $triggerErrors = false){
        /** @var StdClass $apiResponse */
        $apiResponse = json_decode($json);
        if ( empty($apiResponse) || !is_object($apiResponse) ){
            if ( $triggerErrors ) {
                trigger_error(
                    "Failed to parse plugin metadata. Try validating your .json file with http://jsonlint.com/",
                    E_USER_NOTICE
                );
            }
            return null;
        }

        //Very, very basic validation.
        $valid = isset($apiResponse->name) && !empty($apiResponse->name) && isset($apiResponse->version) && !empty($apiResponse->version);
        if ( !$valid ){
            if ( $triggerErrors ) {
                trigger_error(
                    "The plugin metadata file does not contain the required 'name' and/or 'version' keys.",
                    E_USER_NOTICE
                );
            }
            return null;
        }

        $info = new self();
        foreach(get_object_vars($apiResponse) as $key => $value){
            $info->$key = $value;
        }

        return $info;
    }

    /**
     * Transform plugin info into the format used by the native WordPress.org API
     *
     * @return object
     */
    public function toWpFormat(){
        $info = new StdClass;

        //The custom update API is built so that many fields have the same name and format
        //as those returned by the native WordPress.org API. These can be assigned directly.
        $sameFormat = array(
            'name', 'slug', 'version', 'requires', 'tested', 'rating', 'upgrade_notice',
            'num_ratings', 'downloaded', 'active_installs', 'homepage', 'last_updated',
        );
        foreach($sameFormat as $field){
            if ( isset($this->$field) ) {
                $info->$field = $this->$field;
            } else {
                $info->$field = null;
            }
        }

        //Other fields need to be renamed and/or transformed.
        $info->download_link = $this->download_url;

        if ( !empty($this->author_homepage) ){
            $info->author = sprintf('<a href="%s">%s</a>', $this->author_homepage, $this->author);
        } else {
            $info->author = $this->author;
        }

        if ( is_object($this->sections) ){
            $info->sections = get_object_vars($this->sections);
        } elseif ( is_array($this->sections) ) {
            $info->sections = $this->sections;
        } else {
            $info->sections = array('description' => '');
        }

        if ( !empty($this->banners) ) {
            //WP expects an array with two keys: "high" and "low". Both are optional.
            //Docs: https://wordpress.org/plugins/about/faq/#banners
            $info->banners = is_object($this->banners) ? get_object_vars($this->banners) : $this->banners;
            $info->banners = array_intersect_key($info->banners, array('high' => true, 'low' => true));
        }

        return $info;
    }
}