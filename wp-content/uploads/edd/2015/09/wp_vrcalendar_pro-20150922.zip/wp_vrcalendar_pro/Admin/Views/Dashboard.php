<div class="wrap">
    <h2><?php echo VRCALENDAR_PLUGIN_NAME; ?></h2>
    <p class="vc-dash-banner">
        <a href="http://vrcalendarsync.com/" target="_blank"><img src="<?php echo VRCALENDAR_PLUGIN_URL ?>/assets/images/dashboard-banner.png" /></a>
    </p>
    <?php require(VRCALENDAR_PLUGIN_DIR.'/Admin/Views/Part/Dashboard/MyCalendars.php'); ?>
</div>