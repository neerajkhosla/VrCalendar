<div class="wrap">
    <h2><?php echo VRCALENDAR_PLUGIN_NAME; ?></h2>
    <?php require(VRCALENDAR_PLUGIN_DIR.'/Admin/Views/Part/Dashboard/MyCalendars.php'); ?>
</div>