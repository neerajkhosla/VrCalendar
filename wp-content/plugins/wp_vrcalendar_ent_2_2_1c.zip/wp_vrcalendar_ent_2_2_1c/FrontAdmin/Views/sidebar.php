<div class="menu-list">
			<ul>
				<li><a href="<?php global $post;  echo site_url($post->post_name."?page=vr-calendar-dashboard"); ?>">Dashboard</a></li>
				<li><a href="<?php global $post;  echo site_url($post->post_name."?page=vr-calendar-add-calendar"); ?>">Add Calendar</a></li>
				<li><a href="#">Add Search Bar</a></li>
				<li><a href="#">Setting</a></li>
			</ul>
		</div>