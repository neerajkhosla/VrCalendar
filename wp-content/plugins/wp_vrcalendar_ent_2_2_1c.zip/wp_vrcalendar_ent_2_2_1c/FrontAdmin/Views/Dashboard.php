<div class="wrap vrcal-content-wrapper">

<?php
/* We'll do this later
if (!edd_sample_re_check_license()){
    echo "Please note your license has expired and you are no longer eligible for upgrades. Renew your license today at www.vrcalendarsync.com";
}
 */

require(VRCALENDAR_PLUGIN_DIR.'/FrontAdmin/Views/Part/Dashboard/MyCalendars.php');

?>
</div>